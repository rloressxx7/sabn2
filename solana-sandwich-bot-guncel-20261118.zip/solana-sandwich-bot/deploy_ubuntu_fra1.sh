#!/usr/bin/env bash
# ==============================================================================
# Ubuntu 24.04 LTS (DigitalOcean FRA1 — 2 vCPU / 2 GB RAM) Otomatik Kurulum Betiği
# ==============================================================================
set -euo pipefail

echo "=== [1/6] 2 GB RAM Sunucu İçin Güvenli Swap (Takas Alanı) Kontrolü ==="
if [ "$(swapon --show | wc -l)" -eq 0 ]; then
    echo "Swap bulunamadı -> Rust LTO derlemesinde OOM olmaması için 2 GB /swapfile oluşturuluyor..."
    sudo fallocate -l 2G /swapfile || sudo dd if=/dev/zero of=/swapfile bs=1M count=2048
    sudo chmod 600 /swapfile
    sudo mkswap /swapfile
    sudo swapon /swapfile
    if ! grep -q '/swapfile' /etc/fstab; then
        echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab >/dev/null
    fi
    echo "2 GB Swap başarıyla aktif edildi."
else
    echo "Swap zaten aktif."
fi

echo "=== [2/6] Linux Çekirdeği HFT Düşük Gecikme (TCP BBR + Low-Latency) Ayarları ==="
sudo tee /etc/sysctl.d/99-solana-hft.conf >/dev/null <<'EOF'
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_slow_start_after_idle = 0
net.core.rmem_max = 67108864
net.core.wmem_max = 67108864
EOF
sudo sysctl --system >/dev/null || true

echo "=== [3/6] Derleme Paketleri ve Rust Kurulumu ==="
sudo apt-get update -qq
sudo apt-get install -y -qq build-essential pkg-config curl git unzip ca-certificates

if ! command -v cargo >/dev/null 2>&1; then
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal
fi
# shellcheck disable=SC1091
source "$HOME/.cargo/env"

echo "=== [4/6] İşlemciye Özel (target-cpu=native) Release Derlemesi ==="
# 2 GB RAM sunucuda paralel iş parçacığını 2 ile sınırlayarak güvenli LTO derlemesi yapıyoruz
RUSTFLAGS="-C target-cpu=native" cargo build --release -j 2

echo "=== [5/6] İşlem Cüzdanı ve AllenHark Auth Keypair Kontrolü ==="
chmod 600 keys/allenhark-auth-keypair.json 2>/dev/null || true
if [ ! -f "$HOME/.config/solana/id.json" ]; then
    echo "Sunucunuzda yeni ve size özel işlem cüzdanı oluşturuluyor (~/.config/solana/id.json)..."
    ./target/release/solana-sandwich-bot --gen-keypair "$HOME/.config/solana/id.json"
    echo "ÖNEMLİ: Yukarıdaki Public Key sizin GERÇEK İŞLEM CÜZDANINIZDIR. Test için bu adrese ~0.01 - 0.02 SOL gönderebilirsiniz."
else
    echo "Mevcut işlem cüzdanı bulundu: $HOME/.config/solana/id.json"
fi

echo "=== [6/6] Canlı Solana Mainnet Self-Test ==="
./target/release/solana-sandwich-bot --self-test

echo ""
echo "========================================================================"
echo "KURULUM TAMAMLANDI!"
echo "1) 'nano config.toml' ile rpc_http alanına Helius/RPC adresinizi yazın."
echo "2) Botu başlatmak için: ./target/release/solana-sandwich-bot"
echo "========================================================================"
