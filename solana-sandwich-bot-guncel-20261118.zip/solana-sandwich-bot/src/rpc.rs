use anyhow::{bail, Context, Result};
use base64::Engine;
use parking_lot::RwLock;
use serde::Deserialize;
use serde_json::{json, Value};
use solana_commitment_config::{CommitmentConfig, CommitmentLevel};
use solana_hash::Hash;
use solana_pubkey::Pubkey;
use solana_signature::Signature;
use solana_transaction::versioned::VersionedTransaction;
use std::str::FromStr;
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};
use tracing::{debug, warn};

#[derive(Debug, Clone)]
pub struct RawAccount {
    pub lamports: u64,
    pub data: Vec<u8>,
    pub owner: Pubkey,
}

#[derive(Debug, Clone)]
pub struct RpcSimResult {
    pub success: bool,
    pub error: Option<String>,
    pub units_consumed: u64,
    pub logs: Vec<String>,
}

#[derive(Debug, Clone)]
pub struct FetchedTransaction {
    pub transaction: Option<VersionedTransaction>,
    pub log_messages: Vec<String>,
}

/// Çoklu RPC endpoint ile round-robin ve failover desteği.
/// 429 / bağlantı hatasında bir sonraki uç noktaya geçilir; başarılı olunca ilkinden devam edilir.
#[derive(Clone)]
pub struct SolanaRpcClient {
    http: reqwest::Client,
    urls: Vec<Arc<String>>,
    current: Arc<AtomicUsize>,
    commitment: CommitmentConfig,
    next_id: Arc<AtomicU64>,
}

#[derive(Debug, Deserialize)]
struct JsonRpcEnvelope<T> {
    result: Option<T>,
    error: Option<JsonRpcError>,
}

#[derive(Debug, Deserialize)]
struct JsonRpcError {
    code: i64,
    message: String,
    #[serde(default)]
    data: Option<Value>,
}

#[derive(Debug, Deserialize)]
struct RpcAccountValue {
    lamports: u64,
    data: (String, String),
    owner: String,
}

#[derive(Debug, Deserialize)]
struct ValueWrapper<T> {
    value: T,
}

impl SolanaRpcClient {
    /// Tek veya birden çok RPC endpoint ile istemci oluşturur.
    /// Hata (429, bağlantı, timeout) oluştuğunda bir sonraki uç noktaya döner.
    pub fn new(urls: impl IntoIterator<Item = impl Into<String>>, commitment: CommitmentConfig) -> Self {
        let http = reqwest::Client::builder()
            .timeout(Duration::from_secs(12))
            .pool_idle_timeout(Duration::from_secs(60))
            .tcp_nodelay(true)
            .build()
            .expect("valid reqwest client");

        let urls: Vec<Arc<String>> = urls.into_iter().map(|u| Arc::new(u.into())).collect();
        if urls.is_empty() {
            panic!("en az bir RPC endpoint gerekli");
        }

        Self {
            http,
            urls,
            current: Arc::new(AtomicUsize::new(0)),
            commitment,
            next_id: Arc::new(AtomicU64::new(1)),
        }
    }

    /// Mevcut endpoint'i döndürür (round-robin).
    fn current_url(&self) -> Arc<String> {
        let idx = self.current.load(Ordering::Relaxed) % self.urls.len();
        self.urls[idx].clone()
    }

    /// Bir sonraki uç noktaya geçer.
    fn rotate(&self) {
        let n = self.urls.len();
        self.current.fetch_add(1, Ordering::Relaxed);
        let _ = n; // tek uç noktada döngü zaten sıfırdan devam eder
    }

    /// Tüm uç noktaları deneyerek ilk başarılı cevabı döndürür.
    async fn call_with_failover<T: for<'de> Deserialize<'de>>(&self, method: &str, params: Value) -> Result<T> {
        let mut last_err: Option<anyhow::Error> = None;
        for _ in 0..self.urls.len() {
            let url = self.current_url();
            match self.call_one(url.as_str(), method, params.clone()).await {
                Ok(v) => {
                    // Başarılıysa ilk uç noktaya dön (azaltılmış rotasyon)
                    self.current.store(0, Ordering::Relaxed);
                    return Ok(v);
                }
                Err(e) => {
                    last_err = Some(e);
                    self.rotate();
                    debug!("RPC failover: '{}' -> bir sonraki uç noktaya geçiliyor", method);
                }
            }
        }
        Err(last_err.unwrap_or_else(|| anyhow::anyhow!("RPC '{}' tüm uç noktalarda başarısız oldu", method)))
    }

    /// Tek bir URL üzerinden RPC çağrısı (dönüş türü Result ile, failover dışarı yönetir).
    async fn call_one<T: for<'de> Deserialize<'de>>(&self, url: &str, method: &str, params: Value) -> Result<T> {
        let id = self.next_id.fetch_add(1, Ordering::Relaxed);
        let payload = json!({
            "jsonrpc": "2.0",
            "id": id,
            "method": method,
            "params": params,
        });

        let resp = self
            .http
            .post(url)
            .json(&payload)
            .send()
            .await
            .with_context(|| format!("RPC '{}' isteği başarısız oldu ({})", method, url))?;

        let status = resp.status();
        let text = resp
            .text()
            .await
            .with_context(|| format!("RPC '{}' yanıt gövdesi okunamadı ({})", method, url))?;

        if !status.is_success() {
            bail!("RPC HTTP hatası {} ({} @ {}): {}", status, method, url, text);
        }

        let env: JsonRpcEnvelope<T> = serde_json::from_str(&text)
            .with_context(|| format!("RPC '{}' JSON yanıtı çözümlenemedi ({})", method, url))?;

        if let Some(err) = env.error {
            bail!(
                "RPC '{}' hatası ({} @ {}): {} {:?}",
                method, err.code, url, err.message, err.data
            );
        }

        env.result
            .ok_or_else(|| anyhow::anyhow!("RPC '{}' boş sonuç döndürdü ({})", method, url))
    }

    pub fn commitment_str(&self) -> &'static str {
        match self.commitment.commitment {
            CommitmentLevel::Processed => "processed",
            CommitmentLevel::Confirmed => "confirmed",
            CommitmentLevel::Finalized => "finalized",
        }
    }

    async fn call<T: for<'de> Deserialize<'de>>(&self, method: &str, params: Value) -> Result<T> {
        let id = self.next_id.fetch_add(1, Ordering::Relaxed);
        let payload = json!({
            "jsonrpc": "2.0",
            "id": id,
            "method": method,
            "params": params,
        });

        let resp = self
            .http
            .post(self.current_url().as_str())
            .json(&payload)
            .send()
            .await
            .with_context(|| format!("RPC '{}' isteği başarısız oldu", method))?;

        let status = resp.status();
        let text = resp
            .text()
            .await
            .with_context(|| format!("RPC '{}' yanıt gövdesi okunamadı", method))?;

        if !status.is_success() {
            bail!("RPC HTTP hatası {} ({}): {}", status, method, text);
        }

        let env: JsonRpcEnvelope<T> = serde_json::from_str(&text)
            .with_context(|| format!("RPC '{}' JSON yanıtı çözümlenemedi", method))?;

        if let Some(err) = env.error {
            bail!(
                "RPC '{}' hatası ({}): {} {:?}",
                method,
                err.code,
                err.message,
                err.data
            );
        }

        env.result
            .ok_or_else(|| anyhow::anyhow!("RPC '{}' boş sonuç döndürdü", method))
    }

    pub async fn get_slot(&self) -> Result<u64> {
        self.call_with_failover("getSlot", json!([{ "commitment": self.commitment_str() }]))
            .await
    }

    pub async fn get_balance(&self, pubkey: &Pubkey) -> Result<u64> {
        let res: ValueWrapper<u64> = self
            .call_with_failover(
                "getBalance",
                json!([pubkey.to_string(), { "commitment": self.commitment_str() }]),
            )
            .await?;
        Ok(res.value)
    }

    pub async fn get_latest_blockhash(&self) -> Result<Hash> {
        #[derive(Deserialize)]
        struct BlockhashVal {
            blockhash: String,
        }
        let res: ValueWrapper<BlockhashVal> = self
            .call_with_failover(
                "getLatestBlockhash",
                json!([{ "commitment": self.commitment_str() }]),
            )
            .await?;
        Hash::from_str(&res.value.blockhash).context("RPC geçersiz blockhash döndürdü")
    }

    pub async fn get_account_info(&self, pubkey: &Pubkey) -> Result<Option<RawAccount>> {
        let res: ValueWrapper<Option<RpcAccountValue>> = self
            .call_with_failover(
                "getAccountInfo",
                json!([
                    pubkey.to_string(),
                    {
                        "encoding": "base64",
                        "commitment": self.commitment_str()
                    }
                ]),
            )
            .await?;

        res.value.map(Self::convert_account).transpose()
    }

    /// Tek bir HTTP isteğiyle birden fazla hesabı (örn. `[mint, bonding_curve]`) aynı anda çeker.
    pub async fn get_multiple_accounts(&self, pubkeys: &[Pubkey]) -> Result<Vec<Option<RawAccount>>> {
        let keys: Vec<String> = pubkeys.iter().map(|k| k.to_string()).collect();
        let res: ValueWrapper<Vec<Option<RpcAccountValue>>> = self
            .call_with_failover(
                "getMultipleAccounts",
                json!([
                    keys,
                    {
                        "encoding": "base64",
                        "commitment": self.commitment_str()
                    }
                ]),
            )
            .await?;

        res.value
            .into_iter()
            .map(|opt| opt.map(Self::convert_account).transpose())
            .collect()
    }

    /// SPL / Token-2022 ATA bakiyesini ham birim (base units) olarak okur.
    pub async fn get_token_account_balance(&self, ata: &Pubkey) -> Result<u64> {
        #[derive(Deserialize)]
        struct TokenAmount {
            amount: String,
        }
        let res: ValueWrapper<TokenAmount> = self
            .call_with_failover(
                "getTokenAccountBalance",
                json!([ata.to_string(), { "commitment": self.commitment_str() }]),
            )
            .await?;
        res.value
            .amount
            .parse::<u64>()
            .context("Token bakiyesi u64'e çevrilemedi")
    }

    /// İşlem detaylarını (`VersionedTransaction` + `logMessages`) çeker.
    pub async fn get_transaction(&self, sig: &Signature) -> Result<Option<FetchedTransaction>> {
        let raw_val: Value = self
            .call_with_failover(
                "getTransaction",
                json!([
                    sig.to_string(),
                    {
                        "encoding": "base64",
                        "commitment": "confirmed",
                        "maxSupportedTransactionVersion": 0
                    }
                ]),
            )
            .await?;

        if raw_val.is_null() {
            return Ok(None);
        }

        let log_messages = raw_val
            .get("meta")
            .and_then(|m| m.get("logMessages"))
            .and_then(|l| l.as_array())
            .map(|arr| {
                arr.iter()
                    .filter_map(|v| v.as_str().map(|s| s.to_string()))
                    .collect::<Vec<_>>()
            })
            .unwrap_or_default();

        let tx_decoded = raw_val
            .get("transaction")
            .and_then(|t| t.as_array())
            .and_then(|arr| arr.first())
            .and_then(|b64| b64.as_str())
            .and_then(|b64_str| {
                let bytes = base64::engine::general_purpose::STANDARD
                    .decode(b64_str)
                    .ok()?;
                bincode::deserialize::<VersionedTransaction>(&bytes).ok()
            });

        Ok(Some(FetchedTransaction {
            transaction: tx_decoded,
            log_messages,
        }))
    }

    /// Gerçek RPC `simulateTransaction` çağrısı ile işlemi zincir üstü durumuna karşı test eder.
    pub async fn simulate_transaction(&self, tx: &VersionedTransaction) -> Result<RpcSimResult> {
        let serialized = bincode::serialize(tx).context("VersionedTransaction bincode hatası")?;
        let encoded = base64::engine::general_purpose::STANDARD.encode(serialized);

        #[derive(Deserialize)]
        #[serde(rename_all = "camelCase")]
        struct SimValue {
            err: Option<Value>,
            #[serde(default)]
            logs: Option<Vec<String>>,
            #[serde(default)]
            units_consumed: Option<u64>,
        }

        let res: ValueWrapper<SimValue> = self
            .call_with_failover(
                "simulateTransaction",
                json!([
                    encoded,
                    {
                        "encoding": "base64",
                        "commitment": self.commitment_str(),
                        "sigVerify": false,
                        "replaceRecentBlockhash": true
                    }
                ]),
            )
            .await?;

        let err_str = res.value.err.map(|e| e.to_string());
        Ok(RpcSimResult {
            success: err_str.is_none(),
            error: err_str,
            units_consumed: res.value.units_consumed.unwrap_or(0),
            logs: res.value.logs.unwrap_or_default(),
        })
    }

    /// Düşük gecikmeli doğrudan RPC gönderimi (`skipPreflight: true`, base64).
    pub async fn send_transaction_fast(&self, tx: &VersionedTransaction) -> Result<Signature> {
        let serialized = bincode::serialize(tx).context("VersionedTransaction bincode hatası")?;
        let encoded = base64::engine::general_purpose::STANDARD.encode(serialized);

        let sig_str: String = self
            .call_with_failover(
                "sendTransaction",
                json!([
                    encoded,
                    {
                        "encoding": "base64",
                        "skipPreflight": true,
                        "preflightCommitment": self.commitment_str(),
                        "maxRetries": 2
                    }
                ]),
            )
            .await?;

        Signature::from_str(&sig_str).context("sendTransaction geçersiz signature döndürdü")
    }

    /// İşlemin zincirde onaylanıp onaylanmadığını (`getSignatureStatuses`) tek çağrıyla kontrol eder.
    pub async fn is_signature_confirmed(&self, sig: &Signature) -> Result<bool> {
        #[derive(Deserialize)]
        struct SigStatus {
            err: Option<Value>,
        }
        let res: ValueWrapper<Vec<Option<SigStatus>>> = self
            .call_with_failover(
                "getSignatureStatuses",
                json!([[sig.to_string()], { "searchTransactionHistory": false }]),
            )
            .await?;
        if let Some(Some(status)) = res.value.into_iter().next() {
            return Ok(status.err.is_none());
        }
        Ok(false)
    }

    fn convert_account(acc: RpcAccountValue) -> Result<RawAccount> {
        let data = base64::engine::general_purpose::STANDARD
            .decode(acc.data.0.as_bytes())
            .context("Hesap verisi base64 çözümlenemedi")?;
        let owner = Pubkey::from_str(&acc.owner).context("Geçersiz hesap owner pubkey")?;
        Ok(RawAccount {
            lamports: acc.lamports,
            data,
            owner,
        })
    }
}

/// Arka planda her 2 saniyede bir `recent_blockhash` yenileyen sıfır gecikmeli önbellek.
/// Sıcak işlem anında 100-200ms fazladan RPC beklemeyi tamamen ortadan kaldırır.
#[derive(Clone)]
pub struct BlockhashCache {
    inner: Arc<RwLock<Option<(Hash, Instant)>>>,
    rpc: SolanaRpcClient,
}

impl BlockhashCache {
    pub fn new(rpc: SolanaRpcClient) -> Self {
        Self {
            inner: Arc::new(RwLock::new(None)),
            rpc,
        }
    }

    pub async fn warm_up(&self) -> Result<Hash> {
        let bh = self.rpc.get_latest_blockhash().await?;
        *self.inner.write() = Some((bh, Instant::now()));
        Ok(bh)
    }

    /// Yellowstone Geyser `BlockMeta` akışından gelen taze slot blockhash'ini 0-ms ile önbelleğe yazar.
    pub fn update_from_stream(&self, bh: Hash) {
        *self.inner.write() = Some((bh, Instant::now()));
    }

    pub fn spawn_refresher(&self) -> tokio::task::JoinHandle<()> {
        let cache = self.clone();
        tokio::spawn(async move {
            let mut ticker = tokio::time::interval(Duration::from_secs(2));
            loop {
                ticker.tick().await;
                match cache.rpc.get_latest_blockhash().await {
                    Ok(bh) => {
                        *cache.inner.write() = Some((bh, Instant::now()));
                        debug!("Blockhash önbelleği güncellendi: {}", bh);
                    }
                    Err(e) => {
                        warn!("Blockhash yenileme uyarısı: {}", e);
                    }
                }
            }
        })
    }

    pub async fn get(&self) -> Result<Hash> {
        if let Some((bh, ts)) = *self.inner.read() {
            if ts.elapsed() < Duration::from_secs(12) {
                return Ok(bh);
            }
        }
        self.warm_up().await
    }
}
