use anyhow::{bail, Result};
use base64::Engine;
use solana_instruction::{AccountMeta, Instruction};
use solana_message::VersionedMessage;
use solana_pubkey::Pubkey;
use solana_transaction::versioned::VersionedTransaction;
use std::str::FromStr;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::LazyLock;

// ============================================================================
// Resmi Program ID ve Sabitler (Kasım 2026 Pump.fun Mayhem + Cashback + Buyback Uyumlu)
// ============================================================================

pub const PUMP_PROGRAM_ID_STR: &str = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P";
pub const PUMP_FEE_PROGRAM_ID_STR: &str = "pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ";
pub const MAYHEM_PROGRAM_ID_STR: &str = "MAyhSmzXzV1pTf7LsNkrNwkWKTo4ougAJ1PPg47MD4e";
/// Pump.fun Resmi Mayhem Mode AI Trading Bot Cüzdanı (`sol-vault` PDA — ~71,000+ SOL bakiyeli)
pub const MAYHEM_AGENT_WALLET_STR: &str = "BwWK17cbHxwWBKZkUYvzxLcNQ1YVyaFezduWbtm2de6s";
/// Mayhem Mode (`is_mayhem_mode == true`) coin'lerde ZORUNLU protokol komisyon alıcısı (`Custom(6000)` önleyici)
pub const MAYHEM_RESERVED_FEE_RECIPIENT_STR: &str = "GesfTA3X2arioaHp8bbKdjG9vJtskViWACZoYvxp4twS";
/// Kasım 2026 `Global.buyback_fee_recipients` varsayılan geri-alım havuzu (`Custom(6062)` önleyici)
pub const DEFAULT_BUYBACK_FEE_RECIPIENT_STR: &str = "A7hAgCzFw14fejgCp387JUJRMNyz4j89JKnhtKU8piqW";

pub const SPL_TOKEN_PROGRAM_ID_STR: &str = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA";
pub const TOKEN_2022_PROGRAM_ID_STR: &str = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb";
pub const ASSOCIATED_TOKEN_PROGRAM_ID_STR: &str = "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL";
pub const WSOL_MINT_STR: &str = "So11111111111111111111111111111111111111112";
pub const DEFAULT_FEE_RECIPIENT_STR: &str = "62qc2CNXwrYqQScmEdiZFFAnJR262PxWEuNQtxfafNgV";
pub const JITODONTFRONT_PUBKEY_STR: &str = "jitodontfront111111111111111111111111111111";

/// Pump.fun standart başlangıç real token rezervi (~793.1M token, 6 ondalık)
pub const INITIAL_REAL_TOKEN_RESERVES: u64 = 793_100_000_000_000;

/// Anchor Komut ve Hesap Discriminator Sabitleri (8 Byte)
/// Kaynak: resmi `pump.json` IDL (Kasım 2026, pump-fun/pump-public-docs)
pub const BUY_DISCRIMINATOR: [u8; 8] = [102, 6, 61, 18, 1, 218, 235, 234];
pub const BUY_EXACT_SOL_IN_DISCRIMINATOR: [u8; 8] = [56, 252, 116, 8, 158, 223, 205, 95];
pub const SELL_DISCRIMINATOR: [u8; 8] = [51, 230, 133, 164, 1, 127, 131, 173];

/// `buy_v2` / `buy_exact_quote_in_v2` / `sell_v2` (Pump.fun Kasım 2026 güncellemesi)
pub const BUY_V2_DISCRIMINATOR: [u8; 8] = [184, 23, 238, 97, 103, 197, 211, 61];
pub const BUY_EXACT_QUOTE_IN_V2_DISCRIMINATOR: [u8; 8] = [194, 171, 28, 70, 104, 77, 91, 47];
pub const SELL_V2_DISCRIMINATOR: [u8; 8] = [93, 246, 130, 60, 231, 233, 64, 178];

/// `buy_v3` / `buy_exact_quote_in_v3` / `sell_v3` (Pump.fun Kasım 2026 güncellemesi)
pub const BUY_V3_DISCRIMINATOR: [u8; 8] = [7, 5, 29, 196, 245, 23, 101, 80];
pub const BUY_EXACT_QUOTE_IN_V3_DISCRIMINATOR: [u8; 8] = [225, 247, 80, 30, 213, 179, 132, 136];
pub const SELL_V3_DISCRIMINATOR: [u8; 8] = [28, 146, 222, 119, 38, 196, 105, 213];

/// `partial_fill: OptionBool` ek işletme bayrağı (`buy_exact_sol_in` / `buy_v3` / `buy_exact_quote_in_v3`)
pub const PARTIAL_FILL_FALSE: u8 = 0;
pub const PARTIAL_FILL_TRUE: u8 = 1;

pub const BONDING_CURVE_ACCOUNT_DISCRIMINATOR: [u8; 8] = [23, 183, 248, 55, 96, 216, 172, 96];
pub const GLOBAL_ACCOUNT_DISCRIMINATOR: [u8; 8] = [167, 232, 232, 177, 200, 108, 114, 127];
pub const TRADE_EVENT_DISCRIMINATOR: [u8; 8] = [189, 219, 127, 211, 78, 230, 97, 238];
pub const ANCHOR_CPI_EVENT_TAG: [u8; 8] = [228, 69, 165, 46, 81, 203, 154, 29];

/// Pump.fun program ID'sinin 32-byte ham dizisi (`fee_config` PDA seed'i olarak da kullanılır)
pub const PUMP_FEE_CONFIG_SEED_KEY: [u8; 32] = [
    1, 86, 224, 246, 147, 102, 90, 207, 68, 219, 21, 104, 191, 23, 91, 170, 81, 137, 203, 151,
    245, 210, 255, 59, 101, 93, 43, 182, 253, 109, 24, 176,
];

static PUMP_FEE_PROGRAM_PK: LazyLock<Pubkey> =
    LazyLock::new(|| Pubkey::from_str(PUMP_FEE_PROGRAM_ID_STR).expect("valid pump fee program id"));
static MAYHEM_PROGRAM_PK: LazyLock<Pubkey> =
    LazyLock::new(|| Pubkey::from_str(MAYHEM_PROGRAM_ID_STR).expect("valid mayhem program id"));
static MAYHEM_AGENT_WALLET_PK: LazyLock<Pubkey> =
    LazyLock::new(|| Pubkey::from_str(MAYHEM_AGENT_WALLET_STR).expect("valid mayhem agent wallet"));
static MAYHEM_RESERVED_FEE_RECIPIENT_PK: LazyLock<Pubkey> = LazyLock::new(|| {
    Pubkey::from_str(MAYHEM_RESERVED_FEE_RECIPIENT_STR).expect("valid mayhem fee recipient")
});
static DEFAULT_BUYBACK_FEE_RECIPIENT_PK: LazyLock<Pubkey> = LazyLock::new(|| {
    Pubkey::from_str(DEFAULT_BUYBACK_FEE_RECIPIENT_STR).expect("valid buyback fee recipient")
});
static SPL_TOKEN_PROGRAM_PK: LazyLock<Pubkey> =
    LazyLock::new(|| Pubkey::from_str(SPL_TOKEN_PROGRAM_ID_STR).expect("valid spl token id"));
static TOKEN_2022_PROGRAM_PK: LazyLock<Pubkey> =
    LazyLock::new(|| Pubkey::from_str(TOKEN_2022_PROGRAM_ID_STR).expect("valid token-2022 id"));
static ASSOCIATED_TOKEN_PROGRAM_PK: LazyLock<Pubkey> =
    LazyLock::new(|| Pubkey::from_str(ASSOCIATED_TOKEN_PROGRAM_ID_STR).expect("valid ATA id"));
static WSOL_MINT_PK: LazyLock<Pubkey> =
    LazyLock::new(|| Pubkey::from_str(WSOL_MINT_STR).expect("valid wsol mint"));
static DEFAULT_FEE_RECIPIENT_PK: LazyLock<Pubkey> =
    LazyLock::new(|| Pubkey::from_str(DEFAULT_FEE_RECIPIENT_STR).expect("valid fee recipient"));
static JITODONTFRONT_PK: LazyLock<Pubkey> =
    LazyLock::new(|| Pubkey::from_str(JITODONTFRONT_PUBKEY_STR).expect("valid jitodontfront pk"));

static GLOBAL_PDA_PK: LazyLock<Pubkey> =
    LazyLock::new(|| Pubkey::find_program_address(&[b"global"], &pump_program_id()).0);
static EVENT_AUTH_PDA_PK: LazyLock<Pubkey> =
    LazyLock::new(|| Pubkey::find_program_address(&[b"__event_authority"], &pump_program_id()).0);
static GLOBAL_VOL_PDA_PK: LazyLock<Pubkey> = LazyLock::new(|| {
    Pubkey::find_program_address(&[b"global_volume_accumulator"], &pump_program_id()).0
});
static FEE_CONFIG_PDA_PK: LazyLock<Pubkey> = LazyLock::new(|| {
    Pubkey::find_program_address(
        &[b"fee_config", &PUMP_FEE_CONFIG_SEED_KEY],
        &pump_fee_program_id(),
    )
    .0
});

static BUYBACK_ROTATOR: AtomicUsize = AtomicUsize::new(0);

#[inline(always)]
pub fn pump_program_id() -> Pubkey {
    Pubkey::new_from_array(PUMP_FEE_CONFIG_SEED_KEY)
}

#[inline(always)]
pub fn pump_fee_program_id() -> Pubkey {
    *PUMP_FEE_PROGRAM_PK
}

#[inline(always)]
pub fn mayhem_program_id() -> Pubkey {
    *MAYHEM_PROGRAM_PK
}

#[inline(always)]
pub fn mayhem_agent_wallet() -> Pubkey {
    *MAYHEM_AGENT_WALLET_PK
}

#[inline(always)]
pub fn mayhem_reserved_fee_recipient() -> Pubkey {
    *MAYHEM_RESERVED_FEE_RECIPIENT_PK
}

#[inline(always)]
pub fn default_buyback_fee_recipient() -> Pubkey {
    *DEFAULT_BUYBACK_FEE_RECIPIENT_PK
}

#[inline(always)]
pub fn spl_token_program_id() -> Pubkey {
    *SPL_TOKEN_PROGRAM_PK
}

#[inline(always)]
pub fn token_2022_program_id() -> Pubkey {
    *TOKEN_2022_PROGRAM_PK
}

#[inline(always)]
pub fn associated_token_program_id() -> Pubkey {
    *ASSOCIATED_TOKEN_PROGRAM_PK
}

#[inline(always)]
pub fn wsol_mint_id() -> Pubkey {
    *WSOL_MINT_PK
}

#[inline(always)]
pub fn default_fee_recipient() -> Pubkey {
    *DEFAULT_FEE_RECIPIENT_PK
}

#[inline(always)]
pub fn jitodontfront_pubkey() -> Pubkey {
    *JITODONTFRONT_PK
}

/// Kurban işlemin Jito `jitodontfront` koruması taşıyıp taşımadığını kontrol eder.
/// Eğer taşıyorsa Jito Block Engine bu işlemi index 1'de (sandwich ortasında) kesin reddeder;
/// botumuz bunu nanosaniyede tespit edip boşa sandwich denemek yerine 0-Blok Back-Run'a çevirir!
pub fn tx_has_jitodontfront(tx: &VersionedTransaction) -> bool {
    let keys = match &tx.message {
        VersionedMessage::Legacy(m) => &m.account_keys,
        VersionedMessage::V0(m) => &m.account_keys,
    };
    let official = *JITODONTFRONT_PK;
    for k in keys {
        if *k == official {
            return true;
        }
        let b0 = k.to_bytes()[0];
        if (9..=12).contains(&b0) && k.to_string().starts_with("jitodontfront") {
            return true;
        }
    }
    false
}

/// Bir Mint için sıcak yolda tekrar tekrar SHA-256 PDA araması yapmamak üzere önbelleklenen adresler.
#[derive(Debug, Clone, Copy)]
pub struct MintDerivedPdas {
    pub bonding_curve: Pubkey,
    pub associated_bonding_curve: Pubkey,
    pub bonding_curve_v2: Pubkey,
    pub user_ata: Pubkey,
}

impl MintDerivedPdas {
    #[inline]
    pub fn derive(
        mint: &Pubkey,
        bonding_curve_opt: Option<Pubkey>,
        token_program: &Pubkey,
        wallet: &Pubkey,
    ) -> Self {
        let bonding_curve = bonding_curve_opt.unwrap_or_else(|| derive_bonding_curve_pda(mint));
        let associated_bonding_curve = derive_ata(&bonding_curve, mint, token_program);
        let bonding_curve_v2 = derive_bonding_curve_v2_pda(mint);
        let user_ata = derive_ata(wallet, mint, token_program);
        Self {
            bonding_curve,
            associated_bonding_curve,
            bonding_curve_v2,
            user_ata,
        }
    }
}

#[inline]
pub fn is_supported_token_program(owner: &Pubkey) -> bool {
    *owner == *SPL_TOKEN_PROGRAM_PK || *owner == *TOKEN_2022_PROGRAM_PK
}

#[inline]
pub fn is_native_sol_quote(quote_mint: &Pubkey) -> bool {
    *quote_mint == Pubkey::default() || *quote_mint == *WSOL_MINT_PK
}

// ============================================================================
// PDA Türetme Fonksiyonları (Sabit PDA'lar sıfır SHA-256 maliyetiyle önbellekten döner)
// ============================================================================

#[inline(always)]
pub fn derive_global_pda() -> Pubkey {
    *GLOBAL_PDA_PK
}

#[inline]
pub fn derive_bonding_curve_pda(mint: &Pubkey) -> Pubkey {
    Pubkey::find_program_address(&[b"bonding-curve", mint.as_ref()], &pump_program_id()).0
}

/// 2026 Pump.fun güncellemesiyle tüm `buy` ve `sell` komutlarında yer alan `bonding_curve_v2` PDA adresi.
#[inline]
pub fn derive_bonding_curve_v2_pda(mint: &Pubkey) -> Pubkey {
    Pubkey::find_program_address(&[b"bonding-curve-v2", mint.as_ref()], &pump_program_id()).0
}

#[inline]
pub fn derive_creator_vault_pda(creator: &Pubkey) -> Pubkey {
    Pubkey::find_program_address(&[b"creator-vault", creator.as_ref()], &pump_program_id()).0
}

#[inline(always)]
pub fn derive_event_authority_pda() -> Pubkey {
    *EVENT_AUTH_PDA_PK
}

#[inline(always)]
pub fn derive_global_volume_accumulator_pda() -> Pubkey {
    *GLOBAL_VOL_PDA_PK
}

#[inline]
pub fn derive_user_volume_accumulator_pda(user: &Pubkey) -> Pubkey {
    Pubkey::find_program_address(
        &[b"user_volume_accumulator", user.as_ref()],
        &pump_program_id(),
    )
    .0
}

#[inline(always)]
pub fn derive_fee_config_pda() -> Pubkey {
    *FEE_CONFIG_PDA_PK
}

/// Hem klasik SPL Token hem de Token-2022 programları için doğru ATA adresini türetir.
pub fn derive_ata(owner: &Pubkey, mint: &Pubkey, token_program: &Pubkey) -> Pubkey {
    Pubkey::find_program_address(
        &[owner.as_ref(), token_program.as_ref(), mint.as_ref()],
        &associated_token_program_id(),
    )
    .0
}

// ============================================================================
// Zincir Üstü Hesap Yapıları (Global [1096 Byte] & BondingCurve)
// ============================================================================

#[derive(Debug, Clone)]
pub struct GlobalConfigState {
    pub fee_recipient: Pubkey,
    pub fee_basis_points: u64,
    pub creator_fee_basis_points: u64,
    pub mayhem_mode_enabled: bool,
    pub reserved_fee_recipient: Pubkey,
    pub reserved_fee_recipients: Vec<Pubkey>,
    pub buyback_fee_recipients: Vec<Pubkey>,
    pub buyback_basis_points: u64,
}

impl Default for GlobalConfigState {
    fn default() -> Self {
        Self {
            fee_recipient: default_fee_recipient(),
            fee_basis_points: 95,
            creator_fee_basis_points: 30,
            mayhem_mode_enabled: true,
            reserved_fee_recipient: mayhem_reserved_fee_recipient(),
            reserved_fee_recipients: vec![mayhem_reserved_fee_recipient()],
            buyback_fee_recipients: vec![default_buyback_fee_recipient()],
            buyback_basis_points: 5_000,
        }
    }
}

impl GlobalConfigState {
    /// Resmi Pump.fun `Global` (1096 byte, Kasım 2026) hesabını ham byte verisinden çözümler.
    pub fn from_account_data(data: &[u8]) -> Result<Self> {
        // [0..8]     discriminator
        // [8]        initialized: bool (1)
        // [9..41]    authority: Pubkey (32)
        // [41..73]   fee_recipient: Pubkey (32)
        // [105..113] fee_basis_points: u64
        // [154..162] creator_fee_basis_points: u64
        // [162..386] fee_recipients: [Pubkey; 7]
        // [483..515] reserved_fee_recipient: Pubkey (Mayhem ana komisyon alıcısı)
        // [515]      mayhem_mode_enabled: bool
        // [516..740] reserved_fee_recipients: [Pubkey; 7] (Mayhem ek komisyon alıcıları)
        // [740]      is_cashback_enabled: bool
        // [741..997] buyback_fee_recipients: [Pubkey; 8] (Kasım 2026 zorunlu Buyback alıcıları — Custom(6062) önleyici!)
        // [997..1005] buyback_basis_points: u64
        if data.len() < 113 {
            bail!("Global hesap verisi çok kısa: {} byte", data.len());
        }
        if data[0..8] != GLOBAL_ACCOUNT_DISCRIMINATOR {
            bail!("Global hesap discriminator eşleşmedi");
        }

        let fee_recipient = read_pubkey(data, 41)?;
        let fee_basis_points = read_u64(data, 105)?;
        let creator_fee_basis_points = if data.len() >= 162 {
            read_u64(data, 154)?
        } else {
            30
        };

        let reserved_fee_recipient = if data.len() >= 515 {
            let pk = read_pubkey(data, 483)?;
            if pk != Pubkey::default() {
                pk
            } else {
                mayhem_reserved_fee_recipient()
            }
        } else {
            mayhem_reserved_fee_recipient()
        };

        let mayhem_mode_enabled = if data.len() > 515 {
            data[515] != 0
        } else {
            true
        };

        let mut reserved_fee_recipients = Vec::with_capacity(8);
        reserved_fee_recipients.push(reserved_fee_recipient);
        if data.len() >= 740 {
            for i in 0..7 {
                if let Ok(pk) = read_pubkey(data, 516 + i * 32) {
                    if pk != Pubkey::default() && !reserved_fee_recipients.contains(&pk) {
                        reserved_fee_recipients.push(pk);
                    }
                }
            }
        }

        let mut buyback_fee_recipients = Vec::with_capacity(8);
        if data.len() >= 997 {
            for i in 0..8 {
                if let Ok(pk) = read_pubkey(data, 741 + i * 32) {
                    if pk != Pubkey::default() {
                        buyback_fee_recipients.push(pk);
                    }
                }
            }
        }
        if buyback_fee_recipients.is_empty() {
            buyback_fee_recipients.push(default_buyback_fee_recipient());
        }

        let buyback_basis_points = if data.len() >= 1005 {
            read_u64(data, 997)?
        } else {
            5_000
        };

        Ok(Self {
            fee_recipient,
            fee_basis_points,
            creator_fee_basis_points,
            mayhem_mode_enabled,
            reserved_fee_recipient,
            reserved_fee_recipients,
            buyback_fee_recipients,
            buyback_basis_points,
        })
    }

    #[inline]
    pub fn is_mayhem_fee_recipient(&self, candidate: &Pubkey) -> bool {
        *candidate == self.reserved_fee_recipient || self.reserved_fee_recipients.contains(candidate)
    }

    /// `is_mayhem_mode == true` ise kesinlikle `reserved_fee_recipient` (`GesfTA3X...`) seçer;
    /// aksi halde normal `fee_recipient` seçerek `Custom(6000)` hatasını %100 ortadan kaldırır!
    #[inline]
    pub fn effective_fee_recipient(&self, is_mayhem_mode: bool) -> Pubkey {
        if is_mayhem_mode {
            self.reserved_fee_recipient
        } else {
            self.fee_recipient
        }
    }

    /// İpucu (`hint`) varsa bile Mayhem / Standart uyumunu denetleyerek yanlış fee_recipient geçişini imkânsız kılar.
    #[inline]
    pub fn effective_fee_recipient_checked(
        &self,
        is_mayhem_mode: bool,
        hint: Option<Pubkey>,
    ) -> Pubkey {
        if is_mayhem_mode {
            if let Some(h) = hint {
                if self.is_mayhem_fee_recipient(&h) {
                    return h;
                }
            }
            self.reserved_fee_recipient
        } else {
            if let Some(h) = hint {
                if h != Pubkey::default() && !self.is_mayhem_fee_recipient(&h) {
                    return h;
                }
            }
            self.fee_recipient
        }
    }

    /// Kasım 2026 `BuybackFeeRecipientMissing (Custom 6062)` hatasını önlemek için
    /// `buyback_basis_points > 0` olduğunda geçerli bir `buyback_fee_recipient` döndürür.
    #[inline]
    pub fn effective_buyback_recipient(&self, hint: Option<Pubkey>) -> Option<Pubkey> {
        if self.buyback_basis_points == 0 {
            return None;
        }
        if let Some(h) = hint {
            if self.buyback_fee_recipients.contains(&h) {
                return Some(h);
            }
        }
        if self.buyback_fee_recipients.is_empty() {
            Some(default_buyback_fee_recipient())
        } else {
            let idx = BUYBACK_ROTATOR.fetch_add(1, Ordering::Relaxed)
                % self.buyback_fee_recipients.len();
            Some(self.buyback_fee_recipients[idx])
        }
    }
}

#[derive(Debug, Clone)]
pub struct BondingCurveState {
    pub mint: Pubkey,
    pub bonding_curve: Pubkey,
    pub virtual_token_reserves: u64,
    pub virtual_sol_reserves: u64,
    pub real_token_reserves: u64,
    pub real_sol_reserves: u64,
    pub token_total_supply: u64,
    pub complete: bool,
    pub creator: Pubkey,
    pub is_mayhem_mode: bool,
    /// Cashback bayrağı (`byte[82] != 0`) — `sell` komutunda `user_volume_accumulator` eklenip eklenmeyeceğini belirler!
    pub is_cashback_coin: bool,
    pub quote_mint: Pubkey,
    /// Yeni 166-byte BondingCurve alanları (Kasım 2026):
    pub creator_fee_bps: u64,
    pub is_holder_reward: bool,
    pub depth: u64,
    pub protocol_fees: u64,
    pub initial_virtual_quote_reserves: u64,
    pub post_complete_base_out: u64,
    pub post_complete_quote_in: u64,
    pub creator_fee_bps_override: Option<u64>,
}

impl BondingCurveState {
    pub fn from_account_data(mint: Pubkey, bonding_curve: Pubkey, data: &[u8]) -> Result<Self> {
        if data.len() < 49 {
            bail!("BondingCurve hesap verisi çok kısa: {} byte", data.len());
        }
        if data[0..8] != BONDING_CURVE_ACCOUNT_DISCRIMINATOR {
            bail!("BondingCurve discriminator eşleşmedi");
        }

        let virtual_token_reserves = read_u64(data, 8)?;
        let virtual_sol_reserves = read_u64(data, 16)?;
        let real_token_reserves = read_u64(data, 24)?;
        let real_sol_reserves = read_u64(data, 32)?;
        let token_total_supply = read_u64(data, 40)?;
        let complete = data[48] != 0;

        let creator = if data.len() >= 81 {
            read_pubkey(data, 49)?
        } else {
            Pubkey::default()
        };
        let is_mayhem_mode = data.len() > 81 && data[81] != 0;
        let is_cashback_coin = data.len() > 82 && data[82] != 0;
        let quote_mint = if data.len() >= 115 {
            read_pubkey(data, 83)?
        } else {
            Pubkey::default()
        };

        // Yeni 166-byte BondingCurve alanları (Kasım 2026):
        let creator_fee_bps = if data.len() >= 123 {
            read_u64(data, 115)?
        } else {
            0
        };
        let is_holder_reward = data.len() > 124 && data[124] != 0;
        let depth = if data.len() >= 133 {
            read_u64(data, 125)?
        } else {
            0
        };
        let protocol_fees = if data.len() >= 141 {
            read_u64(data, 133)?
        } else {
            0
        };
        let initial_virtual_quote_reserves = if data.len() >= 149 {
            read_u64(data, 141)?
        } else {
            0
        };
        let post_complete_base_out = if data.len() >= 157 {
            read_u64(data, 149)?
        } else {
            0
        };
        let post_complete_quote_in = if data.len() >= 165 {
            read_u64(data, 157)?
        } else {
            0
        };
        let creator_fee_bps_override = if data.len() >= 123 && creator_fee_bps > 0 {
            Some(creator_fee_bps)
        } else {
            None
        };

        Ok(Self {
            mint,
            bonding_curve,
            virtual_token_reserves,
            virtual_sol_reserves,
            real_token_reserves,
            real_sol_reserves,
            token_total_supply,
            complete,
            creator,
            is_mayhem_mode,
            is_cashback_coin,
            quote_mint,
            creator_fee_bps,
            is_holder_reward,
            depth,
            protocol_fees,
            initial_virtual_quote_reserves,
            post_complete_base_out,
            post_complete_quote_in,
            creator_fee_bps_override,
        })
    }

    /// Bonding curve mezuniyet (doluluk) yüzdesi (0.0 - 100.0)
    pub fn fill_percentage(&self) -> f64 {
        if self.real_token_reserves >= INITIAL_REAL_TOKEN_RESERVES {
            return 0.0;
        }
        let sold = INITIAL_REAL_TOKEN_RESERVES.saturating_sub(self.real_token_reserves);
        (sold as f64 / INITIAL_REAL_TOKEN_RESERVES as f64) * 100.0
    }

    /// 1 tam token başına SOL fiyatı (6 ondalık token / 9 ondalık lamports uyarlamalı)
    pub fn spot_price_sol(&self) -> f64 {
        if self.virtual_token_reserves == 0 {
            return 0.0;
        }
        (self.virtual_sol_reserves as f64 / 1e9) / (self.virtual_token_reserves as f64 / 1e6)
    }

    /// Coin'in anlık Market Cap (Piyasa Değeri) tutarını **lamport** cinsinden (0 kayan nokta hatasıyla) hesaplar.
    /// - `use_2b_mayhem_fdv == false` (Varsayılan — Pump.fun standart 1 Milyar eğri arzı):
    ///   `mcap_lamports = virtual_sol_reserves * 1_000_000_000_000_000 / virtual_token_reserves`
    /// - `use_2b_mayhem_fdv == true` (Mayhem Token-2022 2 Milyar toplam arz / FDV):
    ///   Mayhem coin'lerde `2_000_000_000_000_000`, standart coin'lerde `1_000_000_000_000_000` baz alınır.
    #[inline]
    pub fn market_cap_lamports(&self, use_2b_mayhem_fdv: bool) -> u64 {
        if self.virtual_token_reserves == 0 {
            return 0;
        }
        let base_supply: u128 = if self.token_total_supply > 0 {
            self.token_total_supply as u128
        } else {
            1_000_000_000_000_000u128
        };
        let effective_supply = if use_2b_mayhem_fdv && self.is_mayhem_mode {
            base_supply.saturating_mul(2)
        } else {
            base_supply
        };
        ((self.virtual_sol_reserves as u128).saturating_mul(effective_supply)
            / (self.virtual_token_reserves as u128)) as u64
    }

    /// Coin'in anlık Market Cap değerini SOL cinsinden döndürür (örn. `0.35` SOL).
    #[inline]
    pub fn market_cap_sol(&self, use_2b_mayhem_fdv: bool) -> f64 {
        self.market_cap_lamports(use_2b_mayhem_fdv) as f64 / 1_000_000_000.0
    }

    pub fn effective_creator_fee_bps(&self, default_creator_bps: u64) -> u64 {
        if self.creator == Pubkey::default() {
            0
        } else {
            self.creator_fee_bps_override.unwrap_or(default_creator_bps)
        }
    }
}

// ============================================================================
// Gerçek Zamanlı TradeEvent Çözümleyici (`Program data: <base64>`)
// ============================================================================

#[derive(Debug, Clone)]
pub struct ParsedTradeEvent {
    pub mint: Pubkey,
    pub sol_amount: u64,
    pub token_amount: u64,
    pub is_buy: bool,
    pub user: Pubkey,
    pub timestamp: i64,
    pub virtual_sol_reserves: u64,
    pub virtual_token_reserves: u64,
    pub real_sol_reserves: u64,
    pub real_token_reserves: u64,
    pub fee_recipient: Pubkey,
    pub fee_basis_points: u64,
    pub fee: u64,
    pub creator: Pubkey,
    pub creator_fee_basis_points: u64,
    pub creator_fee: u64,
    pub mayhem_mode: bool,
    pub cashback_enabled: bool,
    pub quote_mint: Pubkey,
}

impl ParsedTradeEvent {
    pub fn from_program_data_b64(b64: &str) -> Option<Self> {
        let bytes = base64::engine::general_purpose::STANDARD
            .decode(b64.trim())
            .ok()?;
        Self::from_bytes(&bytes)
    }

    pub fn from_bytes(raw: &[u8]) -> Option<Self> {
        let payload = if raw.len() >= 8 && raw[0..8] == TRADE_EVENT_DISCRIMINATOR {
            &raw[8..]
        } else if raw.len() >= 16
            && raw[0..8] == ANCHOR_CPI_EVENT_TAG
            && raw[8..16] == TRADE_EVENT_DISCRIMINATOR
        {
            &raw[16..]
        } else {
            return None;
        };

        if payload.len() < 121 {
            return None;
        }

        let mint = read_pubkey(payload, 0).ok()?;
        let sol_amount = read_u64(payload, 32).ok()?;
        let token_amount = read_u64(payload, 40).ok()?;
        let is_buy = payload[48] != 0;
        let user = read_pubkey(payload, 49).ok()?;
        let timestamp = i64::from_le_bytes(payload.get(81..89)?.try_into().ok()?);
        let virtual_sol_reserves = read_u64(payload, 89).ok()?;
        let virtual_token_reserves = read_u64(payload, 97).ok()?;
        let real_sol_reserves = read_u64(payload, 105).ok()?;
        let real_token_reserves = read_u64(payload, 113).ok()?;

        let fee_recipient = if payload.len() >= 153 {
            read_pubkey(payload, 121).unwrap_or_else(|_| default_fee_recipient())
        } else {
            default_fee_recipient()
        };
        let fee_basis_points = if payload.len() >= 161 {
            read_u64(payload, 153).unwrap_or(95)
        } else {
            95
        };
        let fee = if payload.len() >= 169 {
            read_u64(payload, 161).unwrap_or(0)
        } else {
            0
        };
        let creator = if payload.len() >= 201 {
            read_pubkey(payload, 169).unwrap_or_default()
        } else {
            Pubkey::default()
        };
        let creator_fee_basis_points = if payload.len() >= 209 {
            read_u64(payload, 201).unwrap_or(30)
        } else {
            30
        };
        let creator_fee = if payload.len() >= 217 {
            read_u64(payload, 209).unwrap_or(0)
        } else {
            0
        };

        let mut mayhem_mode = fee_recipient == mayhem_reserved_fee_recipient()
            || user == mayhem_agent_wallet();
        let mut cashback_enabled = false;
        let mut quote_mint = Pubkey::default();

        if payload.len() >= 254 {
            let str_len = u32::from_le_bytes(payload[250..254].try_into().unwrap()) as usize;
            let after_str = 254usize.saturating_add(str_len);
            if str_len <= 64 && payload.len() >= after_str + 9 {
                mayhem_mode = payload[after_str] != 0;
                let cashback_bps = read_u64(payload, after_str + 1).unwrap_or(0);
                cashback_enabled = cashback_bps > 0;

                let vec_offset = after_str + 1 + 8 + 8 + 8 + 8;
                if payload.len() >= vec_offset + 4 {
                    let sh_len =
                        u32::from_le_bytes(payload[vec_offset..vec_offset + 4].try_into().unwrap())
                            as usize;
                    let qm_offset = vec_offset + 4 + sh_len.saturating_mul(34);
                    if sh_len <= 16 && payload.len() >= qm_offset + 32 {
                        if let Ok(qm) = read_pubkey(payload, qm_offset) {
                            quote_mint = qm;
                        }
                    }
                }
            }
        }

        Some(Self {
            mint,
            sol_amount,
            token_amount,
            is_buy,
            user,
            timestamp,
            virtual_sol_reserves,
            virtual_token_reserves,
            real_sol_reserves,
            real_token_reserves,
            fee_recipient,
            fee_basis_points,
            fee,
            creator,
            creator_fee_basis_points,
            creator_fee,
            mayhem_mode,
            cashback_enabled,
            quote_mint,
        })
    }

    pub fn to_curve_state(&self) -> BondingCurveState {
        let bonding_curve = derive_bonding_curve_pda(&self.mint);
        BondingCurveState {
            mint: self.mint,
            bonding_curve,
            virtual_token_reserves: self.virtual_token_reserves,
            virtual_sol_reserves: self.virtual_sol_reserves,
            real_token_reserves: self.real_token_reserves,
            real_sol_reserves: self.real_sol_reserves,
            token_total_supply: 1_000_000_000_000_000,
            complete: self.real_token_reserves == 0,
            creator: self.creator,
            is_mayhem_mode: self.mayhem_mode,
            is_cashback_coin: self.cashback_enabled,
            quote_mint: self.quote_mint,
            creator_fee_bps: 0,
            is_holder_reward: false,
            depth: 0,
            protocol_fees: 0,
            initial_virtual_quote_reserves: 0,
            post_complete_base_out: 0,
            post_complete_quote_in: 0,
            creator_fee_bps_override: None,
        }
    }

    /// İşlem gerçekleşmeden TAM ÖNCEKİ (örneğin Mayhem Bot'un alım emrini vurduğu andaki!)
    /// bonding curve rezervlerini ve tam Market Cap (`mcap`) değerini 0-RPC ile geri hesaplar!
    pub fn pre_trade_curve_state(&self) -> BondingCurveState {
        let mut c = self.to_curve_state();
        if self.is_buy {
            c.virtual_sol_reserves = c.virtual_sol_reserves.saturating_sub(self.sol_amount);
            c.real_sol_reserves = c.real_sol_reserves.saturating_sub(self.sol_amount);
            c.virtual_token_reserves = c.virtual_token_reserves.saturating_add(self.token_amount);
            c.real_token_reserves = c.real_token_reserves.saturating_add(self.token_amount);
        } else {
            c.virtual_sol_reserves = c.virtual_sol_reserves.saturating_add(self.sol_amount);
            c.real_sol_reserves = c.real_sol_reserves.saturating_add(self.sol_amount);
            c.virtual_token_reserves = c.virtual_token_reserves.saturating_sub(self.token_amount);
            c.real_token_reserves = c.real_token_reserves.saturating_sub(self.token_amount);
        }
        c.complete = c.real_token_reserves == 0;
        c
    }
}

// ============================================================================
// Ham VersionedTransaction İçinden Hedef Alım (Pump.fun & MayhemProgram) Çözümleyici
// ============================================================================

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VictimBuyOrder {
    /// Klasik `Pump::buy(amount_tokens, max_sol_cost)`
    ExactTokensOut { tokens_out: u64, max_sol_cost: u64 },
    /// Yeni `Pump::buy_exact_sol_in(spendable_sol_in, min_tokens_out)`
    ExactSolIn {
        spendable_sol_in: u64,
        min_tokens_out: u64,
    },
    /// Resmi `MayhemProgram::buy` (`MAyhSmzXzV1pTf7LsNkrNwkWKTo4ougAJ1PPg47MD4e`) dış komutu.
    /// Not: Harcanacak gerçek SOL tutarı BPF içinde random-walk olarak hesaplandığından, ShredStream
    /// bu paketi gördüğü anda tüm PDA'ları 0-µs önbelleğe ısıtır ve Geyser `0.2..=1.0 SOL` onayıyla ~29 µs'de ateşler!
    MayhemProgramDynamicBuy { raw_seed: u64 },
}

impl VictimBuyOrder {
    pub fn estimated_sol_lamports(
        &self,
        curve: &BondingCurveState,
        fee_bps: u64,
        creator_bps: u64,
    ) -> Option<u64> {
        match *self {
            VictimBuyOrder::ExactSolIn {
                spendable_sol_in, ..
            } => Some(spendable_sol_in),
            VictimBuyOrder::ExactTokensOut {
                tokens_out,
                max_sol_cost,
            } => Some(
                quote_buy_exact_tokens_out(curve, tokens_out, fee_bps, creator_bps)
                    .map(|q| q.total_sol_cost)
                    .unwrap_or(max_sol_cost),
            ),
            VictimBuyOrder::MayhemProgramDynamicBuy { .. } => None,
        }
    }
}

#[derive(Debug, Clone)]
pub struct ParsedVictimBuy {
    pub fee_recipient: Pubkey,
    pub mint: Pubkey,
    pub bonding_curve: Pubkey,
    pub buyer: Pubkey,
    pub token_program: Pubkey,
    pub creator_vault: Pubkey,
    pub buyback_fee_recipient: Option<Pubkey>,
    pub is_mayhem_program_cpi: bool,
    pub order: VictimBuyOrder,
}

impl ParsedVictimBuy {
    /// İmzalı bir `VersionedTransaction` (Legacy veya V0) içindeki hem doğrudan `Pump::buy` / `buy_exact_sol_in`
    /// hem de resmi `MayhemProgram::buy` (`MAyhSmzXzV1pTf7LsNkrNwkWKTo4ougAJ1PPg47MD4e`) komutunu yakalar!
    pub fn from_versioned_tx(tx: &VersionedTransaction) -> Option<Self> {
        let pump_id = pump_program_id();
        let mayhem_id = mayhem_program_id();
        let (static_keys, instructions) = match &tx.message {
            VersionedMessage::Legacy(msg) => (&msg.account_keys, &msg.instructions),
            VersionedMessage::V0(msg) => (&msg.account_keys, &msg.instructions),
        };

        for ix in instructions {
            let prog_id = static_keys.get(ix.program_id_index as usize)?;

            // 1) Resmi Mayhem Programı (`MAyhSmzXzV1pTf7LsNkrNwkWKTo4ougAJ1PPg47MD4e`) Alım Komutu (23 Hesap)
            if *prog_id == mayhem_id {
                if ix.data.len() < 16 || ix.accounts.len() < 21 {
                    continue;
                }
                let disc: [u8; 8] = ix.data[0..8].try_into().ok()?;
                if disc != BUY_DISCRIMINATOR {
                    continue;
                }
                let raw_seed = read_u64(&ix.data, 8).ok()?;
                let get_acc = |pos: usize| -> Option<Pubkey> {
                    let key_idx = *ix.accounts.get(pos)? as usize;
                    static_keys.get(key_idx).copied()
                };

                let mint = get_acc(3)?;
                let buyer = get_acc(5)?;
                let token_program = get_acc(7)?;
                let bonding_curve = get_acc(9)?;
                let fee_recipient = get_acc(10)?;
                let creator_vault = get_acc(12)?;
                let buyback_fee_recipient = if ix.accounts.len() >= 23 {
                    get_acc(22)
                } else {
                    None
                };

                return Some(Self {
                    fee_recipient,
                    mint,
                    bonding_curve,
                    buyer,
                    token_program,
                    creator_vault,
                    buyback_fee_recipient,
                    is_mayhem_program_cpi: true,
                    order: VictimBuyOrder::MayhemProgramDynamicBuy { raw_seed },
                });
            }

            // 2) Doğrudan Pump.fun (`6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P`) Alım Komutu (17 veya 18 Hesap)
            if *prog_id != pump_id {
                continue;
            }
            if ix.data.len() < 24 || ix.accounts.len() < 10 {
                continue;
            }

            let disc: [u8; 8] = ix.data[0..8].try_into().ok()?;
            let arg1 = read_u64(&ix.data, 8).ok()?;
            let arg2 = read_u64(&ix.data, 16).ok()?;

            let order = if disc == BUY_DISCRIMINATOR || disc == BUY_V2_DISCRIMINATOR || disc == BUY_V3_DISCRIMINATOR {
                VictimBuyOrder::ExactTokensOut {
                    tokens_out: arg1,
                    max_sol_cost: arg2,
                }
            } else if disc == BUY_EXACT_SOL_IN_DISCRIMINATOR || disc == BUY_EXACT_QUOTE_IN_V2_DISCRIMINATOR || disc == BUY_EXACT_QUOTE_IN_V3_DISCRIMINATOR {
                VictimBuyOrder::ExactSolIn {
                    spendable_sol_in: arg1,
                    min_tokens_out: arg2,
                }
            } else {
                continue;
            };

            let get_acc = |pos: usize| -> Option<Pubkey> {
                let key_idx = *ix.accounts.get(pos)? as usize;
                static_keys.get(key_idx).copied()
            };

            // v1/v2 hesap düzeni: [1] fee_recipient, [2] mint, [3] curve, [6] buyer, [8] token_prog, [9] creator_vault, [17] buyback
            // v3 hesap düzeni: [1] mint, [2] quote_mint, [3] base_token_prog, [4] quote_token_prog, [5] curve, [8] buyer, [13] buyback
            let is_v3 = disc == BUY_V3_DISCRIMINATOR || disc == BUY_EXACT_QUOTE_IN_V3_DISCRIMINATOR;
            let (fee_recipient, mint, bonding_curve, buyer, token_program, creator_vault, buyback_fee_recipient) =
                if is_v3 {
                    let mint = get_acc(1)?;
                    let bonding_curve = get_acc(5)?;
                    let buyer = get_acc(8)?;
                    let token_program = get_acc(3)?;
                    let buyback = if ix.accounts.len() >= 14 { get_acc(13) } else { None };
                    // v3'de fee_recipient / creator_vault doğrudan hesapta yok; GlobalConfig'tan türetilir.
                    (default_fee_recipient(), mint, bonding_curve, buyer, token_program, default_fee_recipient(), buyback)
                } else {
                    let fee_recipient = get_acc(1)?;
                    let mint = get_acc(2)?;
                    let bonding_curve = get_acc(3)?;
                    let buyer = get_acc(6)?;
                    let token_program = get_acc(8)?;
                    let creator_vault = get_acc(9)?;
                    let buyback = if ix.accounts.len() >= 18 { get_acc(17) } else { None };
                    (fee_recipient, mint, bonding_curve, buyer, token_program, creator_vault, buyback)
                };

            return Some(Self {
                fee_recipient,
                mint,
                bonding_curve,
                buyer,
                token_program,
                creator_vault,
                buyback_fee_recipient,
                is_mayhem_program_cpi: false,
                order,
            });
        }

        None
    }
}

// ============================================================================
// Kasım 2026 Pump.fun Güncel Komut (Instruction) Oluşturucular
// (Mayhem ReservedFeeRecipient + 18-Hesap BuybackFeeRecipient + Token-2022 Tam Uyumlu!)
// ============================================================================

/// SPL Associated Token Account `CreateIdempotent` (`data = [1]`) komutu (SPL Token & Token-2022 uyumlu).
#[inline]
pub fn create_ata_idempotent_ix(
    payer: &Pubkey,
    owner: &Pubkey,
    mint: &Pubkey,
    token_program: &Pubkey,
) -> Instruction {
    let ata = derive_ata(owner, mint, token_program);
    create_ata_idempotent_with_ata_ix(payer, owner, &ata, mint, token_program)
}

/// Önceden hesaplanmış `ata` adresiyle 0-SHA256 maliyetli `CreateIdempotent` komutu.
#[inline(always)]
pub fn create_ata_idempotent_with_ata_ix(
    payer: &Pubkey,
    owner: &Pubkey,
    ata: &Pubkey,
    mint: &Pubkey,
    token_program: &Pubkey,
) -> Instruction {
    let system_prog = solana_system_interface::program::id();
    Instruction {
        program_id: associated_token_program_id(),
        accounts: vec![
            AccountMeta::new(*payer, true),
            AccountMeta::new(*ata, false),
            AccountMeta::new_readonly(*owner, false),
            AccountMeta::new_readonly(*mint, false),
            AccountMeta::new_readonly(system_prog, false),
            AccountMeta::new_readonly(*token_program, false),
        ],
        data: vec![1u8], // 1 = CreateIdempotent
    }
}

/// SPL Token & Token-2022 uyumlu `CloseAccount` (`data = [9]`) komutu.
/// Satış işleminin hemen arkasına eklenerek boşalan ATA hesabını kapatır ve
/// kilitlenen ~0.00204–0.00207 SOL kira bedelini %100 cüzdana geri iade eder!
#[inline(always)]
pub fn build_close_token_account_ix(
    token_program: &Pubkey,
    ata: &Pubkey,
    destination: &Pubkey,
    owner: &Pubkey,
) -> Instruction {
    Instruction {
        program_id: *token_program,
        accounts: vec![
            AccountMeta::new(*ata, false),
            AccountMeta::new(*destination, false),
            AccountMeta::new_readonly(*owner, true),
        ],
        data: vec![9u8], // 9 = TokenInstruction::CloseAccount
    }
}

/// Sıfır-tekrarlı-PDA (`MintDerivedPdas` + `user_vol_pda`) kullanan ultra-hızlı `buy_exact_sol_in`.
/// Kasım 2026 `buyback_fee_recipient` (`Some` -> 18 hesap) ile `Custom(6062)` hatasını %100 engeller!
#[allow(clippy::too_many_arguments)]
#[inline(always)]
pub fn build_buy_exact_sol_in_fast_ix(
    payer: &Pubkey,
    user_vol_pda: &Pubkey,
    mint: &Pubkey,
    pdas: &MintDerivedPdas,
    fee_recipient: &Pubkey,
    creator_vault: &Pubkey,
    token_program: &Pubkey,
    buyback_fee_recipient: Option<&Pubkey>,
    spendable_sol_in: u64,
    min_tokens_out: u64,
    track_volume: bool,
) -> Instruction {
    let program_id = pump_program_id();
    let mut data = Vec::with_capacity(26);
    data.extend_from_slice(&BUY_EXACT_SOL_IN_DISCRIMINATOR);
    data.extend_from_slice(&spendable_sol_in.to_le_bytes());
    data.extend_from_slice(&min_tokens_out.to_le_bytes());
    data.push(u8::from(track_volume));
    data.push(0u8);

    let mut accounts = Vec::with_capacity(18);
    accounts.extend_from_slice(&[
        AccountMeta::new_readonly(derive_global_pda(), false),                    // 0
        AccountMeta::new(*fee_recipient, false),                                  // 1 (Mayhem ise GesfTA3X...)
        AccountMeta::new_readonly(*mint, false),                                  // 2
        AccountMeta::new(pdas.bonding_curve, false),                              // 3
        AccountMeta::new(pdas.associated_bonding_curve, false),                   // 4
        AccountMeta::new(pdas.user_ata, false),                                   // 5
        AccountMeta::new(*payer, true),                                           // 6
        AccountMeta::new_readonly(solana_system_interface::program::id(), false), // 7
        AccountMeta::new_readonly(*token_program, false),                         // 8 (Mayhem ise Token-2022)
        AccountMeta::new(*creator_vault, false),                                  // 9
        AccountMeta::new_readonly(derive_event_authority_pda(), false),           // 10
        AccountMeta::new_readonly(program_id, false),                             // 11
        AccountMeta::new_readonly(derive_global_volume_accumulator_pda(), false), // 12
        AccountMeta::new(*user_vol_pda, false),                                   // 13
        AccountMeta::new_readonly(derive_fee_config_pda(), false),                // 14
        AccountMeta::new_readonly(pump_fee_program_id(), false),                  // 15
        AccountMeta::new_readonly(pdas.bonding_curve_v2, false),                  // 16
    ]);
    if let Some(bb) = buyback_fee_recipient {
        accounts.push(AccountMeta::new(*bb, false)); // 17 (Kasım 2026 zorunlu buyback_fee_recipient)
    }

    Instruction {
        program_id,
        accounts,
        data,
    }
}

/// 3-Tx Atomik Sandwich Front-Run için TAM ADET (`exact_tokens_out`) alan 2026 `buy` komutu (17/18 hesap).
#[allow(clippy::too_many_arguments)]
#[inline(always)]
pub fn build_buy_exact_tokens_out_fast_ix(
    payer: &Pubkey,
    user_vol_pda: &Pubkey,
    mint: &Pubkey,
    pdas: &MintDerivedPdas,
    fee_recipient: &Pubkey,
    creator_vault: &Pubkey,
    token_program: &Pubkey,
    buyback_fee_recipient: Option<&Pubkey>,
    tokens_out: u64,
    max_sol_cost: u64,
    track_volume: bool,
) -> Instruction {
    let program_id = pump_program_id();
    let mut data = Vec::with_capacity(25);
    data.extend_from_slice(&BUY_DISCRIMINATOR);
    data.extend_from_slice(&tokens_out.to_le_bytes());
    data.extend_from_slice(&max_sol_cost.to_le_bytes());
    data.push(u8::from(track_volume));

    let mut accounts = Vec::with_capacity(18);
    accounts.extend_from_slice(&[
        AccountMeta::new_readonly(derive_global_pda(), false),                    // 0
        AccountMeta::new(*fee_recipient, false),                                  // 1
        AccountMeta::new_readonly(*mint, false),                                  // 2
        AccountMeta::new(pdas.bonding_curve, false),                              // 3
        AccountMeta::new(pdas.associated_bonding_curve, false),                   // 4
        AccountMeta::new(pdas.user_ata, false),                                   // 5
        AccountMeta::new(*payer, true),                                           // 6
        AccountMeta::new_readonly(solana_system_interface::program::id(), false), // 7
        AccountMeta::new_readonly(*token_program, false),                         // 8
        AccountMeta::new(*creator_vault, false),                                  // 9
        AccountMeta::new_readonly(derive_event_authority_pda(), false),           // 10
        AccountMeta::new_readonly(program_id, false),                             // 11
        AccountMeta::new_readonly(derive_global_volume_accumulator_pda(), false), // 12
        AccountMeta::new(*user_vol_pda, false),                                   // 13
        AccountMeta::new_readonly(derive_fee_config_pda(), false),                // 14
        AccountMeta::new_readonly(pump_fee_program_id(), false),                  // 15
        AccountMeta::new_readonly(pdas.bonding_curve_v2, false),                  // 16
    ]);
    if let Some(bb) = buyback_fee_recipient {
        accounts.push(AccountMeta::new(*bb, false)); // 17
    }

    Instruction {
        program_id,
        accounts,
        data,
    }
}

/// Sıfır-tekrarlı-PDA (`MintDerivedPdas` + `user_vol_pda`) kullanan ultra-hızlı `sell` (15/16/17 hesap).
#[allow(clippy::too_many_arguments)]
#[inline(always)]
pub fn build_sell_fast_ix(
    payer: &Pubkey,
    user_vol_pda: &Pubkey,
    mint: &Pubkey,
    pdas: &MintDerivedPdas,
    fee_recipient: &Pubkey,
    creator_vault: &Pubkey,
    token_program: &Pubkey,
    buyback_fee_recipient: Option<&Pubkey>,
    cashback_enabled: bool,
    token_amount: u64,
    min_sol_output: u64,
) -> Instruction {
    let program_id = pump_program_id();
    let mut data = Vec::with_capacity(24);
    data.extend_from_slice(&SELL_DISCRIMINATOR);
    data.extend_from_slice(&token_amount.to_le_bytes());
    data.extend_from_slice(&min_sol_output.to_le_bytes());

    let mut accounts = Vec::with_capacity(17);
    accounts.extend_from_slice(&[
        AccountMeta::new_readonly(derive_global_pda(), false),                    // 0
        AccountMeta::new(*fee_recipient, false),                                  // 1
        AccountMeta::new_readonly(*mint, false),                                  // 2
        AccountMeta::new(pdas.bonding_curve, false),                              // 3
        AccountMeta::new(pdas.associated_bonding_curve, false),                   // 4
        AccountMeta::new(pdas.user_ata, false),                                   // 5
        AccountMeta::new(*payer, true),                                           // 6
        AccountMeta::new_readonly(solana_system_interface::program::id(), false), // 7
        AccountMeta::new(*creator_vault, false),                                  // 8
        AccountMeta::new_readonly(*token_program, false),                         // 9
        AccountMeta::new_readonly(derive_event_authority_pda(), false),           // 10
        AccountMeta::new_readonly(program_id, false),                             // 11
        AccountMeta::new_readonly(derive_fee_config_pda(), false),                // 12
        AccountMeta::new_readonly(pump_fee_program_id(), false),                  // 13
    ]);
    if cashback_enabled {
        accounts.push(AccountMeta::new(*user_vol_pda, false)); // 14
    }
    accounts.push(AccountMeta::new_readonly(pdas.bonding_curve_v2, false)); // 14 veya 15
    if let Some(bb) = buyback_fee_recipient {
        accounts.push(AccountMeta::new(*bb, false)); // 15 veya 16
    }

    Instruction {
        program_id,
        accounts,
        data,
    }
}

/// Genel amaçlı 2026 Pump.fun `buy_exact_sol_in` sarmalayıcısı.
#[allow(clippy::too_many_arguments)]
pub fn build_buy_exact_sol_in_ix(
    payer: &Pubkey,
    mint: &Pubkey,
    fee_recipient: &Pubkey,
    creator_vault: &Pubkey,
    token_program: &Pubkey,
    buyback_fee_recipient: Option<&Pubkey>,
    spendable_sol_in: u64,
    min_tokens_out: u64,
    track_volume: bool,
) -> Instruction {
    let pdas = MintDerivedPdas::derive(mint, None, token_program, payer);
    let user_vol = derive_user_volume_accumulator_pda(payer);
    build_buy_exact_sol_in_fast_ix(
        payer,
        &user_vol,
        mint,
        &pdas,
        fee_recipient,
        creator_vault,
        token_program,
        buyback_fee_recipient,
        spendable_sol_in,
        min_tokens_out,
        track_volume,
    )
}

/// Genel amaçlı 2026 Pump.fun `sell` sarmalayıcısı.
#[allow(clippy::too_many_arguments)]
pub fn build_sell_ix(
    payer: &Pubkey,
    mint: &Pubkey,
    fee_recipient: &Pubkey,
    creator_vault: &Pubkey,
    token_program: &Pubkey,
    buyback_fee_recipient: Option<&Pubkey>,
    cashback_enabled: bool,
    token_amount: u64,
    min_sol_output: u64,
) -> Instruction {
    let pdas = MintDerivedPdas::derive(mint, None, token_program, payer);
    let user_vol = derive_user_volume_accumulator_pda(payer);
    build_sell_fast_ix(
        payer,
        &user_vol,
        mint,
        &pdas,
        fee_recipient,
        creator_vault,
        token_program,
        buyback_fee_recipient,
        cashback_enabled,
        token_amount,
        min_sol_output,
    )
}

/// 2026 `buy_v3` (17 hesap) komutu: `buy(amount_tokens, max_quote_in, { 0: partial_fill })`.
/// v3 hesap düzeni: [0] global, [1] mint, [2] quote_mint(WSOL), [3] base_token_prog, [4] quote_token_prog(SPL),
/// [5] bonding_curve, [6] assoc_base_curve, [7] assoc_quote_curve, [8] user, [9] assoc_base_user,
/// [10] assoc_quote_user, [11] user_volume_accumulator, [12] fee_config, [13] buyback_fee_recipient,
/// [14] system_program, [15] event_authority, [16] program.
#[allow(clippy::too_many_arguments)]
#[inline(always)]
pub fn build_buy_v3_fast_ix(
    payer: &Pubkey,
    user_vol_pda: &Pubkey,
    mint: &Pubkey,
    quote_mint: &Pubkey,
    token_program: &Pubkey,
    quote_token_program: &Pubkey,
    bonding_curve: &Pubkey,
    assoc_base_curve: &Pubkey,
    assoc_quote_curve: &Pubkey,
    assoc_base_user: &Pubkey,
    assoc_quote_user: &Pubkey,
    _fee_recipient: &Pubkey,
    _creator_vault: &Pubkey,
    buyback_fee_recipient: &Pubkey,
    amount_tokens: u64,
    max_quote_in: u64,
    partial_fill: bool,
) -> Instruction {
    let program_id = pump_program_id();
    let system_prog = solana_system_interface::program::id();
    let event_auth = derive_event_authority_pda();
    let fee_config = derive_fee_config_pda();

    let mut data = Vec::with_capacity(27);
    data.extend_from_slice(&BUY_V3_DISCRIMINATOR);
    data.extend_from_slice(&amount_tokens.to_le_bytes());
    data.extend_from_slice(&max_quote_in.to_le_bytes());
    data.push(if partial_fill { PARTIAL_FILL_TRUE } else { PARTIAL_FILL_FALSE });

    let accounts = vec![
        AccountMeta::new_readonly(derive_global_pda(), false),          // 0
        AccountMeta::new_readonly(*mint, false),                        // 1
        AccountMeta::new_readonly(*quote_mint, false),                  // 2
        AccountMeta::new_readonly(*token_program, false),               // 3
        AccountMeta::new_readonly(*quote_token_program, false),         // 4
        AccountMeta::new(*bonding_curve, false),                        // 5
        AccountMeta::new(*assoc_base_curve, false),                     // 6
        AccountMeta::new(*assoc_quote_curve, false),                    // 7
        AccountMeta::new(*payer, true),                                 // 8
        AccountMeta::new(*assoc_base_user, false),                      // 9
        AccountMeta::new(*assoc_quote_user, false),                     // 10
        AccountMeta::new(*user_vol_pda, false),                         // 11
        AccountMeta::new_readonly(fee_config, false),                   // 12
        AccountMeta::new(*buyback_fee_recipient, false),                // 13
        AccountMeta::new_readonly(system_prog, false),                  // 14
        AccountMeta::new_readonly(event_auth, false),                   // 15
        AccountMeta::new_readonly(program_id, false),                   // 16
    ];

    Instruction {
        program_id,
        accounts,
        data,
    }
}

/// 2026 `buy_exact_quote_in_v3` (17 hesap) komutu: `buy_exact_quote_in_v3(spendable_quote_in, min_tokens_out, { 0: partial_fill })`.
/// Hesap düzeni aynı `buy_v3` ile.
#[allow(clippy::too_many_arguments)]
#[inline(always)]
pub fn build_buy_exact_quote_in_v3_fast_ix(
    payer: &Pubkey,
    user_vol_pda: &Pubkey,
    mint: &Pubkey,
    quote_mint: &Pubkey,
    token_program: &Pubkey,
    quote_token_program: &Pubkey,
    bonding_curve: &Pubkey,
    assoc_base_curve: &Pubkey,
    assoc_quote_curve: &Pubkey,
    assoc_base_user: &Pubkey,
    assoc_quote_user: &Pubkey,
    _fee_recipient: &Pubkey,
    _creator_vault: &Pubkey,
    buyback_fee_recipient: &Pubkey,
    spendable_quote_in: u64,
    min_tokens_out: u64,
    partial_fill: bool,
) -> Instruction {
    let program_id = pump_program_id();
    let system_prog = solana_system_interface::program::id();
    let event_auth = derive_event_authority_pda();
    let fee_config = derive_fee_config_pda();

    let mut data = Vec::with_capacity(27);
    data.extend_from_slice(&BUY_EXACT_QUOTE_IN_V3_DISCRIMINATOR);
    data.extend_from_slice(&spendable_quote_in.to_le_bytes());
    data.extend_from_slice(&min_tokens_out.to_le_bytes());
    data.push(if partial_fill { PARTIAL_FILL_TRUE } else { PARTIAL_FILL_FALSE });

    let accounts = vec![
        AccountMeta::new_readonly(derive_global_pda(), false),          // 0
        AccountMeta::new_readonly(*mint, false),                        // 1
        AccountMeta::new_readonly(*quote_mint, false),                  // 2
        AccountMeta::new_readonly(*token_program, false),               // 3
        AccountMeta::new_readonly(*quote_token_program, false),         // 4
        AccountMeta::new(*bonding_curve, false),                        // 5
        AccountMeta::new(*assoc_base_curve, false),                     // 6
        AccountMeta::new(*assoc_quote_curve, false),                    // 7
        AccountMeta::new(*payer, true),                                 // 8
        AccountMeta::new(*assoc_base_user, false),                      // 9
        AccountMeta::new(*assoc_quote_user, false),                     // 10
        AccountMeta::new(*user_vol_pda, false),                         // 11
        AccountMeta::new_readonly(fee_config, false),                   // 12
        AccountMeta::new(*buyback_fee_recipient, false),                // 13
        AccountMeta::new_readonly(system_prog, false),                  // 14
        AccountMeta::new_readonly(event_auth, false),                   // 15
        AccountMeta::new_readonly(program_id, false),                   // 16
    ];

    Instruction {
        program_id,
        accounts,
        data,
    }
}

// ============================================================================
// Tam Sayı (u128) Bonding Curve Matematiği (Mayhem Düşük Virtual-SOL Eğrileriyle %100 Uyumlu!)
// ============================================================================

#[derive(Debug, Clone, Copy)]
pub struct BuyExactSolQuote {
    pub tokens_out: u64,
    pub net_sol_to_curve: u64,
    pub total_fee_lamports: u64,
    pub price_impact_pct: f64,
}

#[derive(Debug, Clone, Copy)]
pub struct BuyExactTokensQuote {
    pub tokens_out: u64,
    pub net_sol_to_curve: u64,
    pub total_sol_cost: u64,
}

#[derive(Debug, Clone, Copy)]
pub struct SellTokensQuote {
    pub net_sol_out: u64,
    pub gross_sol_from_curve: u64,
    pub total_fee_lamports: u64,
}

#[inline]
fn ceil_div(a: u128, b: u128) -> u128 {
    if a == 0 {
        0
    } else {
        (a + b - 1) / b
    }
}

/// Resmi Pump.fun BPF `buy_exact_sol_in` formülüyle tek birime kadar (`0` sapma!) örtüşen alım kotasyonu.
/// Not: Kasım 2026 Mayhem eğrilerinde `virtual_sol_reserves` ~0.35 SOL (`350_000_000` lamports) olabildiği için
/// yapay `>= 1 SOL` engeli kaldırılmıştır!
#[inline]
pub fn quote_buy_exact_sol_in(
    curve: &BondingCurveState,
    spendable_sol_in: u64,
    protocol_fee_bps: u64,
    creator_fee_bps: u64,
) -> Option<BuyExactSolQuote> {
    if curve.complete
        || spendable_sol_in < 10
        || curve.virtual_token_reserves == 0
        || curve.virtual_sol_reserves == 0
        || (curve.virtual_sol_reserves as i64) <= 0
    {
        return None;
    }

    let s_in = spendable_sol_in as u128;
    let p_bps = protocol_fee_bps as u128;
    let c_bps = if curve.creator == Pubkey::default() {
        0
    } else {
        creator_fee_bps as u128
    };
    let total_bps = p_bps + c_bps;

    let mut net_sol = (s_in * 10_000) / (10_000 + total_bps);
    let fees = ceil_div(net_sol * p_bps, 10_000) + ceil_div(net_sol * c_bps, 10_000);
    if net_sol + fees > s_in {
        net_sol = net_sol.saturating_sub((net_sol + fees) - s_in);
    }
    if net_sol <= 1 {
        return None;
    }

    let effective_sol = net_sol - 1;
    let v_tok = curve.virtual_token_reserves as u128;
    let v_sol = curve.virtual_sol_reserves as u128;

    let mut tokens_out = (effective_sol * v_tok) / (v_sol + effective_sol);
    if tokens_out as u64 > curve.real_token_reserves {
        tokens_out = curve.real_token_reserves as u128;
    }
    if tokens_out == 0 {
        return None;
    }

    let actual_fees = ceil_div(net_sol * p_bps, 10_000) + ceil_div(net_sol * c_bps, 10_000);
    let spot = v_sol as f64 / v_tok as f64;
    let eff = effective_sol as f64 / tokens_out as f64;
    let impact_pct = if spot > 0.0 {
        ((eff - spot) / spot) * 100.0
    } else {
        0.0
    };

    Some(BuyExactSolQuote {
        tokens_out: tokens_out as u64,
        net_sol_to_curve: net_sol as u64,
        total_fee_lamports: actual_fees as u64,
        price_impact_pct: impact_pct,
    })
}

/// Klasik `buy(tokens_out, max_sol_cost)` komutu için gereken toplam SOL maliyetini hesaplar.
pub fn quote_buy_exact_tokens_out(
    curve: &BondingCurveState,
    tokens_out: u64,
    protocol_fee_bps: u64,
    creator_fee_bps: u64,
) -> Option<BuyExactTokensQuote> {
    if curve.complete
        || tokens_out == 0
        || curve.virtual_sol_reserves == 0
        || tokens_out >= curve.virtual_token_reserves
        || tokens_out > curve.real_token_reserves
    {
        return None;
    }

    let t = tokens_out as u128;
    let v_tok = curve.virtual_token_reserves as u128;
    let v_sol = curve.virtual_sol_reserves as u128;

    let net_sol = ceil_div(t * v_sol, v_tok - t) + 1;
    let p_bps = protocol_fee_bps as u128;
    let c_bps = if curve.creator == Pubkey::default() {
        0
    } else {
        creator_fee_bps as u128
    };
    let fees = ceil_div(net_sol * p_bps, 10_000) + ceil_div(net_sol * c_bps, 10_000);
    let total_sol_cost = net_sol.checked_add(fees)?;

    Some(BuyExactTokensQuote {
        tokens_out,
        net_sol_to_curve: net_sol as u64,
        total_sol_cost: u64::try_from(total_sol_cost).ok()?,
    })
}

/// `sell(token_amount)` komutu için eğriden çıkacak brüt ve komisyon sonrası net SOL çıktısını hesaplar.
#[inline]
pub fn quote_sell_tokens(
    curve: &BondingCurveState,
    token_amount: u64,
    protocol_fee_bps: u64,
    creator_fee_bps: u64,
) -> Option<SellTokensQuote> {
    if curve.complete
        || token_amount == 0
        || curve.virtual_token_reserves == 0
        || curve.virtual_sol_reserves == 0
        || (curve.virtual_sol_reserves as i64) <= 0
    {
        return None;
    }

    let t = token_amount as u128;
    let v_tok = curve.virtual_token_reserves as u128;
    let v_sol = curve.virtual_sol_reserves as u128;

    let gross_sol = (t * v_sol) / (v_tok + t);
    if gross_sol == 0 || (gross_sol as u64) > curve.virtual_sol_reserves {
        return None;
    }

    let p_bps = protocol_fee_bps as u128;
    let c_bps = if curve.creator == Pubkey::default() {
        0
    } else {
        creator_fee_bps as u128
    };
    let fees = ceil_div(gross_sol * p_bps, 10_000) + ceil_div(gross_sol * c_bps, 10_000);
    let net_sol_out = gross_sol.saturating_sub(fees);

    Some(SellTokensQuote {
        net_sol_out: net_sol_out as u64,
        gross_sol_from_curve: gross_sol as u64,
        total_fee_lamports: fees as u64,
    })
}

fn apply_buy_to_curve(
    curve: &BondingCurveState,
    net_sol_in: u64,
    tokens_out: u64,
) -> BondingCurveState {
    let mut next = curve.clone();
    next.virtual_sol_reserves = next.virtual_sol_reserves.saturating_add(net_sol_in);
    next.real_sol_reserves = next.real_sol_reserves.saturating_add(net_sol_in);
    next.virtual_token_reserves = next.virtual_token_reserves.saturating_sub(tokens_out);
    next.real_token_reserves = next.real_token_reserves.saturating_sub(tokens_out);
    if next.real_token_reserves == 0 {
        next.complete = true;
    }
    next
}

#[derive(Debug, Clone, Copy)]
pub struct SandwichSimulationPlan {
    pub front_run_sol_in: u64,
    pub front_run_tokens_out: u64,
    pub back_run_net_sol_out: u64,
    pub gross_profit_lamports: i64,
    pub net_profit_lamports: i64,
    pub front_run_price_impact_pct: f64,
}

/// Belirli bir `front_run_sol_in` tutarı için 3 adımlı `[Bizim Alımımız -> Hedefin Alımı -> Bizim Satışımız]`
/// zincirini tam sayı matematiğiyle simüle eder. Not: Mayhem Agent kendi alımında 0 protokol/creator komisyonu öder;
/// `victim_pays_zero_fees` bayrağı bu durumu dahi sıfır sapmayla modeller!
#[allow(clippy::too_many_arguments)]
pub fn simulate_sandwich_at_size(
    initial_curve: &BondingCurveState,
    victim_order: &VictimBuyOrder,
    front_run_sol_in: u64,
    protocol_fee_bps: u64,
    creator_fee_bps: u64,
    victim_pays_zero_fees: bool,
    jito_tip_lamports: u64,
    tx_overhead_lamports: u64,
) -> Option<SandwichSimulationPlan> {
    let fr_quote = quote_buy_exact_sol_in(
        initial_curve,
        front_run_sol_in,
        protocol_fee_bps,
        creator_fee_bps,
    )?;
    let curve_after_fr = apply_buy_to_curve(
        initial_curve,
        fr_quote.net_sol_to_curve,
        fr_quote.tokens_out,
    );
    if curve_after_fr.complete {
        return None;
    }

    let (v_prot_bps, v_creat_bps) = if victim_pays_zero_fees {
        (0, 0)
    } else {
        (protocol_fee_bps, creator_fee_bps)
    };

    let curve_after_victim = match *victim_order {
        VictimBuyOrder::ExactTokensOut {
            tokens_out,
            max_sol_cost,
        } => {
            let v_quote =
                quote_buy_exact_tokens_out(&curve_after_fr, tokens_out, v_prot_bps, v_creat_bps)?;
            if v_quote.total_sol_cost > max_sol_cost {
                return None;
            }
            apply_buy_to_curve(&curve_after_fr, v_quote.net_sol_to_curve, v_quote.tokens_out)
        }
        VictimBuyOrder::ExactSolIn {
            spendable_sol_in,
            min_tokens_out,
        } => {
            let v_quote =
                quote_buy_exact_sol_in(&curve_after_fr, spendable_sol_in, v_prot_bps, v_creat_bps)?;
            if v_quote.tokens_out < min_tokens_out {
                return None;
            }
            apply_buy_to_curve(&curve_after_fr, v_quote.net_sol_to_curve, v_quote.tokens_out)
        }
        VictimBuyOrder::MayhemProgramDynamicBuy { .. } => {
            return None;
        }
    };

    if curve_after_victim.complete {
        return None;
    }

    let br_quote = quote_sell_tokens(
        &curve_after_victim,
        fr_quote.tokens_out,
        protocol_fee_bps,
        creator_fee_bps,
    )?;

    let gross_profit = br_quote.net_sol_out as i64 - front_run_sol_in as i64;
    let total_fixed_cost = (jito_tip_lamports.saturating_add(tx_overhead_lamports)) as i64;
    let net_profit = gross_profit - total_fixed_cost;

    Some(SandwichSimulationPlan {
        front_run_sol_in,
        front_run_tokens_out: fr_quote.tokens_out,
        back_run_net_sol_out: br_quote.net_sol_out,
        gross_profit_lamports: gross_profit,
        net_profit_lamports: net_profit,
        front_run_price_impact_pct: fr_quote.price_impact_pct,
    })
}

/// İkili arama (binary search) ile hedef işlemin slippage sınırını patlatmayan EN YÜKSEK
/// geçerli front-run büyüklüğünü bulur ve net kârı maksimize eden planı döndürür.
#[allow(clippy::too_many_arguments)]
pub fn optimize_sandwich(
    initial_curve: &BondingCurveState,
    victim_order: &VictimBuyOrder,
    max_position_lamports: u64,
    max_price_impact_pct: f64,
    protocol_fee_bps: u64,
    creator_fee_bps: u64,
    victim_pays_zero_fees: bool,
    jito_tip_lamports: u64,
    tx_overhead_lamports: u64,
) -> Option<SandwichSimulationPlan> {
    let min_lamports: u64 = 500_000; // 0.0005 SOL alt sınır (0.001 SOL canlı test uyumlu)
    if max_position_lamports < min_lamports {
        return None;
    }

    let _ = simulate_sandwich_at_size(
        initial_curve,
        victim_order,
        min_lamports,
        protocol_fee_bps,
        creator_fee_bps,
        victim_pays_zero_fees,
        jito_tip_lamports,
        tx_overhead_lamports,
    )?;

    let mut low = min_lamports;
    let mut high = max_position_lamports;
    let mut feasible_upper = min_lamports;

    for _ in 0..32 {
        if low > high {
            break;
        }
        let mid = low + (high - low) / 2;
        if let Some(plan) = simulate_sandwich_at_size(
            initial_curve,
            victim_order,
            mid,
            protocol_fee_bps,
            creator_fee_bps,
            victim_pays_zero_fees,
            jito_tip_lamports,
            tx_overhead_lamports,
        ) {
            if plan.front_run_price_impact_pct <= max_price_impact_pct {
                feasible_upper = mid;
                low = mid.saturating_add(500_000);
            } else {
                high = mid.saturating_sub(500_000);
            }
        } else {
            high = mid.saturating_sub(500_000);
        }
    }

    let mut best: Option<SandwichSimulationPlan> = None;
    let steps = 24u64;
    for i in 0..=steps {
        let candidate_sol = if feasible_upper == min_lamports {
            min_lamports
        } else {
            min_lamports
                + ((feasible_upper - min_lamports) as u128 * i as u128 / steps as u128) as u64
        };
        if let Some(plan) = simulate_sandwich_at_size(
            initial_curve,
            victim_order,
            candidate_sol,
            protocol_fee_bps,
            creator_fee_bps,
            victim_pays_zero_fees,
            jito_tip_lamports,
            tx_overhead_lamports,
        ) {
            if plan.front_run_price_impact_pct <= max_price_impact_pct
                && best
                    .as_ref()
                    .map(|b| plan.net_profit_lamports > b.net_profit_lamports)
                    .unwrap_or(true)
            {
                best = Some(plan);
            }
        }
    }

    best
}

fn read_u64(data: &[u8], offset: usize) -> Result<u64> {
    let slice = data
        .get(offset..offset + 8)
        .ok_or_else(|| anyhow::anyhow!("u64 okuma taşması: offset={}", offset))?;
    Ok(u64::from_le_bytes(slice.try_into().unwrap()))
}

fn read_pubkey(data: &[u8], offset: usize) -> Result<Pubkey> {
    let slice = data
        .get(offset..offset + 32)
        .ok_or_else(|| anyhow::anyhow!("Pubkey okuma taşması: offset={}", offset))?;
    let arr: [u8; 32] = slice.try_into().unwrap();
    Ok(Pubkey::new_from_array(arr))
}

#[cfg(test)]
mod tests {
    use super::*;
    use solana_hash::Hash;
    use solana_keypair::Keypair;
    use solana_message::{v0, VersionedMessage};
    use solana_signer::Signer;

    fn sample_curve(is_mayhem: bool) -> BondingCurveState {
        let mint = Keypair::new().pubkey();
        let bonding_curve = derive_bonding_curve_pda(&mint);
        BondingCurveState {
            mint,
            bonding_curve,
            virtual_token_reserves: 1_010_803_129_893_973,
            virtual_sol_reserves: if is_mayhem {
                362_770_134 // Canlı Mainnet düşük virtual-SOL Mayhem eğrisi!
            } else {
                30_000_000_000
            },
            real_token_reserves: 730_903_129_893_973,
            real_sol_reserves: 11_059_054,
            token_total_supply: 1_000_000_000_000_000,
            complete: false,
            creator: Keypair::new().pubkey(),
            is_mayhem_mode: is_mayhem,
            is_cashback_coin: false,
            quote_mint: Pubkey::default(),
            creator_fee_bps: 0,
            is_holder_reward: false,
            depth: 0,
            protocol_fees: 0,
            initial_virtual_quote_reserves: 0,
            post_complete_base_out: 0,
            post_complete_quote_in: 0,
            creator_fee_bps_override: None,
        }
    }

    #[test]
    fn test_global_pda_and_mayhem_constants() {
        assert_eq!(
            derive_global_pda().to_string(),
            "4wTV1YmiEkRvAtNtsSGPtUrqRYQMe5SKy2uB4Jjaxnjf"
        );
        assert_eq!(
            mayhem_agent_wallet().to_string(),
            "BwWK17cbHxwWBKZkUYvzxLcNQ1YVyaFezduWbtm2de6s"
        );
        assert_eq!(
            mayhem_program_id().to_string(),
            "MAyhSmzXzV1pTf7LsNkrNwkWKTo4ougAJ1PPg47MD4e"
        );
        assert_eq!(
            mayhem_reserved_fee_recipient().to_string(),
            "GesfTA3X2arioaHp8bbKdjG9vJtskViWACZoYvxp4twS"
        );
    }

    #[test]
    fn test_nov2026_18_account_buy_and_16_17_account_sell_layouts() {
        let payer = Keypair::new().pubkey();
        let mint = Keypair::new().pubkey();
        let fee_rec = mayhem_reserved_fee_recipient();
        let bb_rec = default_buyback_fee_recipient();
        let creator_vault = derive_creator_vault_pda(&payer);
        let token_prog = token_2022_program_id();

        let buy_ix = build_buy_exact_sol_in_ix(
            &payer,
            &mint,
            &fee_rec,
            &creator_vault,
            &token_prog,
            Some(&bb_rec),
            1_000_000,
            100,
            false,
        );
        // Kasım 2026: 18 hesap (index 16 = bonding_curve_v2, index 17 = buyback_fee_recipient)
        assert_eq!(buy_ix.accounts.len(), 18);
        assert_eq!(buy_ix.accounts[1].pubkey, mayhem_reserved_fee_recipient());
        assert_eq!(buy_ix.accounts[8].pubkey, token_2022_program_id());
        assert_eq!(buy_ix.accounts[16].pubkey, derive_bonding_curve_v2_pda(&mint));
        assert_eq!(buy_ix.accounts[17].pubkey, bb_rec);

        // Cashback kapalı + Buyback açık sell -> 16 hesap
        let sell_non_cb = build_sell_ix(
            &payer,
            &mint,
            &fee_rec,
            &creator_vault,
            &token_prog,
            Some(&bb_rec),
            false,
            1_000_000,
            100,
        );
        assert_eq!(sell_non_cb.accounts.len(), 16);
        assert_eq!(
            sell_non_cb.accounts[14].pubkey,
            derive_bonding_curve_v2_pda(&mint)
        );
        assert_eq!(sell_non_cb.accounts[15].pubkey, bb_rec);

        // Cashback açık + Buyback açık sell -> 17 hesap
        let sell_cb = build_sell_ix(
            &payer,
            &mint,
            &fee_rec,
            &creator_vault,
            &token_prog,
            Some(&bb_rec),
            true,
            1_000_000,
            100,
        );
        assert_eq!(sell_cb.accounts.len(), 17);
        assert_eq!(
            sell_cb.accounts[14].pubkey,
            derive_user_volume_accumulator_pda(&payer)
        );
        assert_eq!(
            sell_cb.accounts[15].pubkey,
            derive_bonding_curve_v2_pda(&mint)
        );
        assert_eq!(sell_cb.accounts[16].pubkey, bb_rec);
    }

    #[test]
    fn test_exact_bpf_quote_parity_on_live_mayhem_curve() {
        // Canlı Mainnet SVM simülasyonundan alınan birebir gerçek değerlerle 0-sapma testi!
        let curve = sample_curve(true);
        let q = quote_buy_exact_sol_in(&curve, 1_000_000, 95, 30).expect("mayhem quote must work");
        assert_eq!(q.net_sol_to_curve, 987_654);
        assert_eq!(q.tokens_out, 2_744_471_127_017);

        // Market Cap kontrolü: 1B eğri arzıyla ~0.3589 SOL, 2B Mayhem arzıyla ~0.7178 SOL -> İkisi de [0.20, 1.00] SOL içinde!
        let mcap_1b = curve.market_cap_sol(false);
        let mcap_2b = curve.market_cap_sol(true);
        assert!(mcap_1b > 0.358 && mcap_1b < 0.360, "mcap_1b={}", mcap_1b);
        assert!(mcap_2b > 0.717 && mcap_2b < 0.719, "mcap_2b={}", mcap_2b);
    }

    #[test]
    fn test_mayhem_outer_program_buy_tx_parsing() {
        let keeper = Keypair::new();
        let mint = Keypair::new().pubkey();
        let bc = derive_bonding_curve_pda(&mint);
        let cv = derive_creator_vault_pda(&keeper.pubkey());
        let bb = default_buyback_fee_recipient();

        let mut accs = Vec::new();
        for i in 0..23 {
            let pk = match i {
                0 => keeper.pubkey(),
                3 => mint,
                5 => mayhem_agent_wallet(),
                7 => token_2022_program_id(),
                9 => bc,
                10 => mayhem_reserved_fee_recipient(),
                12 => cv,
                22 => bb,
                _ => Keypair::new().pubkey(),
            };
            accs.push(AccountMeta::new(pk, i == 0));
        }

        let mut data = Vec::new();
        data.extend_from_slice(&BUY_DISCRIMINATOR);
        data.extend_from_slice(&500_000_000u64.to_le_bytes()); // 0.5 SOL seed
        data.extend_from_slice(&0u64.to_le_bytes());
        data.extend_from_slice(&[0x60, 0x09, 0xac, 0x20]);

        let ix = Instruction {
            program_id: mayhem_program_id(),
            accounts: accs,
            data,
        };

        let msg = VersionedMessage::V0(
            v0::Message::try_compile(&keeper.pubkey(), &[ix], &[], Hash::new_unique()).unwrap(),
        );
        let tx = VersionedTransaction::try_new(msg, &[&keeper]).unwrap();

        let parsed = ParsedVictimBuy::from_versioned_tx(&tx).expect("must parse mayhem outer ix");
        assert!(parsed.is_mayhem_program_cpi);
        assert_eq!(parsed.mint, mint);
        assert_eq!(parsed.buyer, mayhem_agent_wallet());
        assert_eq!(parsed.token_program, token_2022_program_id());
        assert_eq!(parsed.fee_recipient, mayhem_reserved_fee_recipient());
        assert_eq!(parsed.buyback_fee_recipient, Some(bb));
    }

    #[test]
    fn test_victim_tx_parsing_and_sandwich_optimizer() {
        let mut curve = sample_curve(false);
        curve.real_token_reserves = INITIAL_REAL_TOKEN_RESERVES;
        curve.virtual_token_reserves = 1_073_000_000_000_000;

        let victim_kp = Keypair::new();
        let fee_rec = default_fee_recipient();
        let bb_rec = default_buyback_fee_recipient();
        let creator_vault = derive_creator_vault_pda(&curve.creator);
        let token_prog = spl_token_program_id();

        // 0.6 SOL Mayhem/hedef alımı (%15 slippage toleransı ile)
        let victim_sol = 600_000_000u64; // 0.6 SOL (0.2..1.0 SOL aralığında!)
        let expected = quote_buy_exact_sol_in(&curve, victim_sol, 95, 30).unwrap();
        let min_tokens_with_slippage = (expected.tokens_out as u128 * 8500 / 10_000) as u64;

        let victim_ix = build_buy_exact_sol_in_ix(
            &victim_kp.pubkey(),
            &curve.mint,
            &fee_rec,
            &creator_vault,
            &token_prog,
            Some(&bb_rec),
            victim_sol,
            min_tokens_with_slippage,
            false,
        );
        let msg = VersionedMessage::V0(
            v0::Message::try_compile(&victim_kp.pubkey(), &[victim_ix], &[], Hash::new_unique())
                .unwrap(),
        );
        let victim_tx = VersionedTransaction::try_new(msg, &[&victim_kp]).unwrap();

        let decoded = ParsedVictimBuy::from_versioned_tx(&victim_tx).expect("should parse victim");
        assert_eq!(decoded.mint, curve.mint);
        assert_eq!(decoded.buyer, victim_kp.pubkey());
        assert_eq!(decoded.buyback_fee_recipient, Some(bb_rec));

        let plan = optimize_sandwich(
            &curve,
            &decoded.order,
            5_000_000_000,
            20.0,
            95,
            30,
            false,
            10_000,
            15_000,
        )
        .expect("should find valid sandwich plan");

        assert!(plan.net_profit_lamports > 0);
    }

    #[test]
    fn test_atomic_jitodontfront_and_close_ata() {
        let kp = Keypair::new();
        let pk = kp.pubkey();
        let mint = Keypair::new().pubkey();
        let tp = token_2022_program_id();
        let pdas = MintDerivedPdas::derive(&mint, None, &tp, &pk);
        let user_vol = derive_user_volume_accumulator_pda(&pk);
        let cv = derive_creator_vault_pda(&pk);
        let bb = default_buyback_fee_recipient();

        let exact_buy = build_buy_exact_tokens_out_fast_ix(
            &pk,
            &user_vol,
            &mint,
            &pdas,
            &mayhem_reserved_fee_recipient(),
            &cv,
            &tp,
            Some(&bb),
            123_456_789,
            1_000_000,
            false,
        );
        assert_eq!(exact_buy.accounts.len(), 18);
        assert_eq!(&exact_buy.data[0..8], &BUY_DISCRIMINATOR);

        let close_ix = build_close_token_account_ix(&tp, &pdas.user_ata, &pk, &pk);
        assert_eq!(close_ix.data, vec![9u8]);
        assert_eq!(close_ix.accounts.len(), 3);

        let msg_plain = VersionedMessage::V0(
            v0::Message::try_compile(&pk, &[close_ix.clone()], &[], Hash::new_unique()).unwrap(),
        );
        let tx_plain = VersionedTransaction::try_new(msg_plain, &[&kp]).unwrap();
        assert!(!tx_has_jitodontfront(&tx_plain));

        let mut protected_ix = close_ix;
        protected_ix
            .accounts
            .push(AccountMeta::new_readonly(jitodontfront_pubkey(), false));
        let msg_prot = VersionedMessage::V0(
            v0::Message::try_compile(&pk, &[protected_ix], &[], Hash::new_unique()).unwrap(),
        );
        let tx_prot = VersionedTransaction::try_new(msg_prot, &[&kp]).unwrap();
        assert!(tx_has_jitodontfront(&tx_prot));
    }
}
