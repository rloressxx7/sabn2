use anyhow::{Context, Result};
use base64::Engine;
use futures_util::{SinkExt, StreamExt};
use serde_json::{json, Value};
use solana_pubkey::Pubkey;
use solana_signature::Signature;
use solana_transaction::versioned::VersionedTransaction;
use std::str::FromStr;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::mpsc;
use tokio_tungstenite::{connect_async, tungstenite::protocol::Message};
use tracing::{debug, error, info, warn};

use crate::pump::{ParsedTradeEvent, ParsedVictimBuy, PUMP_PROGRAM_ID_STR};
use crate::pumpswap::{
    parse_pumpswap_buy_tx, ParsedPumpSwapTrade, ParsedPumpSwapWhaleBuy, PumpSwapTxHints,
};
use crate::rpc::SolanaRpcClient;

/// Geyser / Shred işlem mesajından 0-RPC ile doğrudan çıkarılan hazır hesap ipuçları
#[derive(Debug, Clone, Copy)]
pub struct TxAccountHints {
    pub token_program: Pubkey,
    pub creator_vault: Pubkey,
    pub fee_recipient: Pubkey,
    pub buyback_fee_recipient: Option<Pubkey>,
}

#[derive(Debug, Clone)]
pub enum MarketEvent {
    /// Pump.fun Bonding Curve (`6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P`) onaylı işlem.
    ConfirmedTrade {
        signature: String,
        trade: ParsedTradeEvent,
        hints: Option<TxAccountHints>,
    },
    /// Mezuniyet sonrası PumpSwap AMM (`pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA`) onaylı işlem!
    ConfirmedPumpSwapTrade {
        signature: String,
        trade: ParsedPumpSwapTrade,
        hints: Option<PumpSwapTxHints>,
    },
    /// ShredStream (`SubscribeEntries`) üzerinden yakalanan erken Pump.fun eğri alımı.
    ShredFastBuy {
        slot: u64,
        signature: String,
        victim_tx: VersionedTransaction,
        parsed: ParsedVictimBuy,
    },
    /// ShredStream (`SubscribeEntries`) üzerinden yakalanan erken PumpSwap AMM balina alımı.
    ShredFastPumpSwapBuy {
        slot: u64,
        signature: String,
        victim_tx: VersionedTransaction,
        parsed: ParsedPumpSwapWhaleBuy,
    },
    /// Blok öncesi ham imzalı Pump.fun eğri alımı (`raw_tx_ws` — Sandwich / 2-Tx Front-Run için).
    PreExecutionVictimBuy {
        signature: String,
        victim_tx: VersionedTransaction,
        parsed: ParsedVictimBuy,
    },
    /// Blok öncesi ham imzalı PumpSwap AMM alımı (`raw_tx_ws` — 2-Tx Front-Run için).
    PreExecutionPumpSwapBuy {
        signature: String,
        victim_tx: VersionedTransaction,
        parsed: ParsedPumpSwapWhaleBuy,
    },
}

#[derive(Default)]
pub struct MonitorCounters {
    pub ws_messages: AtomicU64,
    pub grpc_messages: AtomicU64,
    pub shred_batches: AtomicU64,
    pub shred_whale_buys: AtomicU64,
    pub decoded_trades: AtomicU64,
    pub pumpswap_trades: AtomicU64,
    pub whale_10k_50k_signals: AtomicU64,
    pub mayhem_bot_buys: AtomicU64,
    pub raw_victim_buys: AtomicU64,
    pub reverted_skipped: AtomicU64,
}

pub struct HeliusLogMonitor {
    ws_url: String,
    rpc: SolanaRpcClient,
    event_tx: mpsc::Sender<MarketEvent>,
    counters: Arc<MonitorCounters>,
}

impl HeliusLogMonitor {
    pub fn new(
        ws_url: String,
        rpc: SolanaRpcClient,
        event_tx: mpsc::Sender<MarketEvent>,
        counters: Arc<MonitorCounters>,
    ) -> Self {
        Self {
            ws_url,
            rpc,
            event_tx,
            counters,
        }
    }

    pub async fn run_forever(self) {
        let mut backoff_secs = 1u64;
        loop {
            match self.connect_and_stream().await {
                Ok(()) => {
                    warn!("WS bağlantısı kapandı, 1 sn içinde yeniden bağlanılıyor...");
                    backoff_secs = 1;
                }
                Err(e) => {
                    error!(
                        "WS bağlantı hatası: {} — {} sn sonra tekrar denenecek...",
                        e, backoff_secs
                    );
                }
            }
            tokio::time::sleep(Duration::from_secs(backoff_secs)).await;
            backoff_secs = (backoff_secs * 2).min(10);
        }
    }

    async fn connect_and_stream(&self) -> Result<()> {
        let (ws_stream, _) = connect_async(&self.ws_url)
            .await
            .context("WebSocket el sıkışması başarısız")?;
        let (mut write, mut read) = ws_stream.split();

        let sub_msg = json!({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "logsSubscribe",
            "params": [
                { "mentions": [PUMP_PROGRAM_ID_STR] },
                { "commitment": "processed" }
            ]
        });

        write
            .send(Message::Text(sub_msg.to_string()))
            .await
            .context("logsSubscribe isteği gönderilemedi")?;

        info!(
            "WebSocket bağlandı ve Pump.fun ({}) canlı log akışına abone olundu.",
            PUMP_PROGRAM_ID_STR
        );

        let mut ping_interval = tokio::time::interval(Duration::from_secs(20));
        ping_interval.tick().await;

        loop {
            tokio::select! {
                _ = ping_interval.tick() => {
                    if let Err(e) = write.send(Message::Ping(vec![1, 2, 3, 4])).await {
                        warn!("WS Ping gönderilemedi: {}", e);
                        break;
                    }
                }
                maybe_msg = read.next() => {
                    let Some(msg) = maybe_msg else { break; };
                    match msg {
                        Ok(Message::Text(txt)) => {
                            self.counters.ws_messages.fetch_add(1, Ordering::Relaxed);
                            self.handle_log_frame(&txt).await;
                        }
                        Ok(Message::Ping(payload)) => {
                            let _ = write.send(Message::Pong(payload)).await;
                        }
                        Ok(Message::Close(_)) => break,
                        Err(e) => return Err(e).context("WS okuma hatası"),
                        _ => {}
                    }
                }
            }
        }

        Ok(())
    }

    async fn handle_log_frame(&self, text: &str) {
        let Ok(root) = serde_json::from_str::<Value>(text) else {
            return;
        };

        let Some(val) = root
            .get("params")
            .and_then(|p| p.get("result"))
            .and_then(|r| r.get("value"))
        else {
            return;
        };

        if let Some(err_field) = val.get("err") {
            if !err_field.is_null() {
                self.counters
                    .reverted_skipped
                    .fetch_add(1, Ordering::Relaxed);
                return;
            }
        }

        let signature = val
            .get("signature")
            .and_then(|s| s.as_str())
            .unwrap_or_default()
            .to_string();
        if signature.is_empty() {
            return;
        }

        let Some(logs) = val.get("logs").and_then(|l| l.as_array()) else {
            return;
        };

        let mut decoded_any = false;
        let mut saw_buy_ix_log = false;

        for line_val in logs {
            let Some(line) = line_val.as_str() else {
                continue;
            };
            if line.contains("Instruction: Buy") {
                saw_buy_ix_log = true;
            }
            if let Some(b64_data) = line.strip_prefix("Program data: ") {
                if let Some(trade) = ParsedTradeEvent::from_program_data_b64(b64_data) {
                    decoded_any = true;
                    self.counters.decoded_trades.fetch_add(1, Ordering::Relaxed);
                    let _ = self
                        .event_tx
                        .send(MarketEvent::ConfirmedTrade {
                            signature: signature.clone(),
                            trade,
                            hints: None,
                        })
                        .await;
                }
            }
        }

        if !decoded_any && saw_buy_ix_log {
            if let Ok(sig) = Signature::from_str(&signature) {
                let rpc = self.rpc.clone();
                let tx_chan = self.event_tx.clone();
                let counters = self.counters.clone();
                tokio::spawn(async move {
                    if let Ok(Some(fetched)) = rpc.get_transaction(&sig).await {
                        let hints = fetched
                            .transaction
                            .as_ref()
                            .and_then(ParsedVictimBuy::from_versioned_tx)
                            .map(|p| TxAccountHints {
                                token_program: p.token_program,
                                creator_vault: p.creator_vault,
                                fee_recipient: p.fee_recipient,
                                buyback_fee_recipient: p.buyback_fee_recipient,
                            });
                        for line in &fetched.log_messages {
                            if let Some(b64_data) = line.strip_prefix("Program data: ") {
                                if let Some(trade) =
                                    ParsedTradeEvent::from_program_data_b64(b64_data)
                                {
                                    counters.decoded_trades.fetch_add(1, Ordering::Relaxed);
                                    let _ = tx_chan
                                        .send(MarketEvent::ConfirmedTrade {
                                            signature: sig.to_string(),
                                            trade,
                                            hints,
                                        })
                                        .await;
                                }
                            }
                        }
                    }
                });
            }
        }
    }
}

pub struct RawTxStreamMonitor {
    raw_ws_url: String,
    event_tx: mpsc::Sender<MarketEvent>,
    counters: Arc<MonitorCounters>,
}

impl RawTxStreamMonitor {
    pub fn new(
        raw_ws_url: String,
        event_tx: mpsc::Sender<MarketEvent>,
        counters: Arc<MonitorCounters>,
    ) -> Self {
        Self {
            raw_ws_url,
            event_tx,
            counters,
        }
    }

    pub async fn run_forever(self) {
        let mut backoff_secs = 1u64;
        loop {
            match self.connect_and_stream().await {
                Ok(()) => {
                    warn!("Raw Tx WS bağlantısı kapandı, 1 sn sonra yeniden bağlanılıyor...");
                    backoff_secs = 1;
                }
                Err(e) => {
                    error!(
                        "Raw Tx WS hatası: {} — {} sn sonra tekrar denenecek...",
                        e, backoff_secs
                    );
                }
            }
            tokio::time::sleep(Duration::from_secs(backoff_secs)).await;
            backoff_secs = (backoff_secs * 2).min(10);
        }
    }

    async fn connect_and_stream(&self) -> Result<()> {
        let (ws_stream, _) = connect_async(&self.raw_ws_url)
            .await
            .context("Raw Tx WebSocket bağlantısı kurulamadı")?;
        let (mut write, mut read) = ws_stream.split();

        info!(
            "Pre-execution ham işlem akışına bağlanıldı: {}",
            self.raw_ws_url
        );

        let mut ping_interval = tokio::time::interval(Duration::from_secs(15));
        ping_interval.tick().await;

        loop {
            tokio::select! {
                _ = ping_interval.tick() => {
                    if write.send(Message::Ping(vec![9, 9])).await.is_err() {
                        break;
                    }
                }
                maybe_msg = read.next() => {
                    let Some(msg) = maybe_msg else { break; };
                    match msg {
                        Ok(Message::Binary(bytes)) => {
                            self.inspect_raw_tx_bytes(&bytes).await;
                        }
                        Ok(Message::Text(txt)) => {
                            if let Some(bytes) = decode_flexible_tx_frame(&txt) {
                                self.inspect_raw_tx_bytes(&bytes).await;
                            }
                        }
                        Ok(Message::Ping(p)) => {
                            let _ = write.send(Message::Pong(p)).await;
                        }
                        Ok(Message::Close(_)) => break,
                        Err(e) => return Err(e).context("Raw Tx WS okuma hatası"),
                        _ => {}
                    }
                }
            }
        }

        Ok(())
    }

    async fn inspect_raw_tx_bytes(&self, tx_bytes: &[u8]) {
        let Ok(victim_tx) = bincode::deserialize::<VersionedTransaction>(tx_bytes) else {
            debug!("Alınan ham paket VersionedTransaction olarak çözümlenemedi");
            return;
        };

        let sig_str = victim_tx
            .signatures
            .first()
            .map(|s| s.to_string())
            .unwrap_or_default();

        if let Some(parsed) = ParsedVictimBuy::from_versioned_tx(&victim_tx) {
            self.counters
                .raw_victim_buys
                .fetch_add(1, Ordering::Relaxed);
            let _ = self
                .event_tx
                .send(MarketEvent::PreExecutionVictimBuy {
                    signature: sig_str,
                    victim_tx,
                    parsed,
                })
                .await;
        } else if let Some(parsed) = parse_pumpswap_buy_tx(&victim_tx) {
            self.counters
                .raw_victim_buys
                .fetch_add(1, Ordering::Relaxed);
            let _ = self
                .event_tx
                .send(MarketEvent::PreExecutionPumpSwapBuy {
                    signature: sig_str,
                    victim_tx,
                    parsed,
                })
                .await;
        }
    }
}

pub fn decode_flexible_tx_frame(frame: &str) -> Option<Vec<u8>> {
    let trimmed = frame.trim();
    if trimmed.is_empty() {
        return None;
    }

    if trimmed.starts_with('{') {
        let val: Value = serde_json::from_str(trimmed).ok()?;
        let candidate_str = val
            .get("tx")
            .and_then(|v| v.as_str())
            .or_else(|| val.get("transaction").and_then(|v| v.as_str()))
            .or_else(|| {
                val.get("transaction")
                    .and_then(|v| v.as_array())
                    .and_then(|a| a.first())
                    .and_then(|v| v.as_str())
            })
            .or_else(|| {
                val.get("params")
                    .and_then(|p| p.get("result"))
                    .and_then(|r| {
                        r.get("tx")
                            .and_then(|v| v.as_str())
                            .or_else(|| r.get("transaction").and_then(|v| v.as_str()))
                            .or_else(|| {
                                r.get("transaction")
                                    .and_then(|v| v.as_array())
                                    .and_then(|a| a.first())
                                    .and_then(|v| v.as_str())
                            })
                    })
            })?;
        decode_b64_or_b58(candidate_str)
    } else {
        decode_b64_or_b58(trimmed)
    }
}

fn decode_b64_or_b58(encoded: &str) -> Option<Vec<u8>> {
    base64::engine::general_purpose::STANDARD
        .decode(encoded.trim())
        .ok()
        .or_else(|| bs58::decode(encoded.trim()).into_vec().ok())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_flexible_tx_frame_decoder() {
        let sample = vec![1u8, 2, 3, 4, 5, 6, 7, 8];
        let b64 = base64::engine::general_purpose::STANDARD.encode(&sample);
        let json_msg = format!(r#"{{"tx": "{}"}}"#, b64);
        assert_eq!(decode_flexible_tx_frame(&json_msg).unwrap(), sample);

        let b58 = bs58::encode(&sample).into_string();
        assert_eq!(decode_flexible_tx_frame(&b58).unwrap(), sample);
    }
}
