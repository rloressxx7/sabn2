//! `--sell-mint <MINT>`: cüzdandaki tokenin TAMAMINI satar (Pump curve veya PumpSwap).
//! Pozisyonlar yalnızca RAM'de tutulduğu için bot yeniden başlayınca elde kalan tokeni bu komut satar.
//! Önce simüle eder; simülasyon geçmezse hiçbir şey göndermez.

use anyhow::{bail, Context, Result};
use solana_commitment_config::CommitmentConfig;
use solana_instruction::Instruction;
use solana_keypair::Keypair;
use solana_pubkey::Pubkey;
use solana_signer::Signer;
use std::str::FromStr;
use std::time::Duration;

use crate::config::AppConfig;
use crate::jito::JitoClient;
use crate::pump::{
    build_close_token_account_ix, build_sell_fast_ix, default_buyback_fee_recipient,
    derive_ata, derive_bonding_curve_pda, derive_creator_vault_pda, derive_global_pda,
    derive_user_volume_accumulator_pda, is_native_sol_quote, is_supported_token_program,
    pump_program_id, quote_sell_tokens, wsol_mint_id, BondingCurveState, GlobalConfigState,
    MintDerivedPdas,
};
use crate::pumpswap::{build_pumpswap_atomic_sell_ixs, pumpswap_program_id, PumpSwapPoolMeta};
use crate::rpc::SolanaRpcClient;

/// Self-test'te canlı PumpSwap simülasyonunu geçen buyback alıcısı; Pump Global listesinde olmayabilir.
const PUMPSWAP_ALT_BUYBACK: &str = "5eHhjP8JaYkz83CWwvGU2uMUXefd3AazWGx4gpcuEEYD";
/// Aynı imzalı tx her denemede yeniden gönderilir (çift satış olmaz); ~10 x 4 sn blockhash ömrü içinde kalır.
const BUNDLE_ATTEMPTS: usize = 10;

pub async fn run(cfg: &AppConfig, wallet: &Keypair, mint_str: &str) -> Result<()> {
    let mint = Pubkey::from_str(mint_str.trim()).context("Geçersiz mint adresi")?;
    let owner = wallet.pubkey();
    let urls = if cfg.network.rpc_endpoints.is_empty() {
        vec![cfg.network.rpc_http.clone()]
    } else {
        cfg.network.rpc_endpoints.clone()
    };
    let rpc = SolanaRpcClient::new(urls, CommitmentConfig::processed());

    let mint_acc = rpc
        .get_account_info(&mint)
        .await?
        .context("Mint hesabı zincirde bulunamadı")?;
    if !is_supported_token_program(&mint_acc.owner) {
        bail!("Desteklenmeyen token programı: {}", mint_acc.owner);
    }
    let token_program = mint_acc.owner;
    let user_ata = derive_ata(&owner, &mint, &token_program);
    let balance = token_balance_or_zero(&rpc, &user_ata).await?;
    println!("Cüzdan  : {owner}");
    println!("Token   : {mint} | ATA {user_ata} | bakiye {balance}");
    if balance == 0 {
        bail!("Bu cüzdanda bu tokenden yok, satılacak bir şey yok");
    }

    let global_acc = rpc
        .get_account_info(&derive_global_pda())
        .await?
        .context("Pump Global hesabı okunamadı")?;
    let global = GlobalConfigState::from_account_data(&global_acc.data)?;
    // Motorun zarar-çıkışıyla aynı tolerans: sell_slippage_bps * 3, en fazla %20.
    let slip_bps = (cfg.strategy.sell_slippage_bps as u64 * 3).min(2_000);
    let min_out = |expected: u64| expected * (10_000 - slip_bps) / 10_000;

    let bc_pda = derive_bonding_curve_pda(&mint);
    let curve = match rpc.get_account_info(&bc_pda).await? {
        Some(acc) => Some(BondingCurveState::from_account_data(mint, bc_pda, &acc.data)?),
        None => None,
    };

    // Her buyback alıcı adayı için ayrı bir tx; simülasyonu ilk geçen gönderilir.
    let (venue, expected, candidates): (&str, u64, Vec<Vec<Instruction>>) = match curve {
        Some(c) if !c.complete => {
            if !is_native_sol_quote(&c.quote_mint) {
                bail!("SOL dışı paritedeki eğriler desteklenmiyor (quote {})", c.quote_mint);
            }
            let creator_bps = c.effective_creator_fee_bps(global.creator_fee_basis_points);
            let expected = quote_sell_tokens(&c, balance, global.fee_basis_points, creator_bps)
                .context("Eğri satış kotasyonu hesaplanamadı")?
                .net_sol_out;
            let pdas = MintDerivedPdas::derive(&mint, Some(bc_pda), &token_program, &owner);
            let fee_recipient = global.effective_fee_recipient(c.is_mayhem_mode);
            let creator_vault = derive_creator_vault_pda(&c.creator);
            let user_vol = derive_user_volume_accumulator_pda(&owner);
            let buybacks: Vec<Option<Pubkey>> = if global.buyback_basis_points == 0 {
                vec![None]
            } else if global.buyback_fee_recipients.is_empty() {
                vec![Some(default_buyback_fee_recipient())]
            } else {
                global.buyback_fee_recipients.iter().copied().map(Some).collect()
            };
            let txs = buybacks
                .iter()
                .map(|bb| {
                    vec![
                        build_sell_fast_ix(
                            &owner,
                            &user_vol,
                            &mint,
                            &pdas,
                            &fee_recipient,
                            &creator_vault,
                            &token_program,
                            bb.as_ref(),
                            c.is_cashback_coin,
                            balance,
                            min_out(expected),
                        ),
                        build_close_token_account_ix(&token_program, &user_ata, &owner, &owner),
                    ]
                })
                .collect();
            ("Pump bonding curve", expected, txs)
        }
        _ => {
            let pool = canonical_pumpswap_pool(&mint);
            let pool_acc = rpc.get_account_info(&pool).await?.with_context(|| {
                format!("Eğri bitmiş ama PumpSwap havuzu ({pool}) bulunamadı; token pump.fun mezunu olmayabilir")
            })?;
            let mut meta =
                PumpSwapPoolMeta::from_pool_account_data(pool, token_program, 0, 0, &pool_acc.data)?;
            if meta.base_mint != mint || meta.quote_mint != wsol_mint_id() {
                bail!("Havuz {pool} bu mint/WSOL çiftine ait değil");
            }
            meta.pool_base_reserves = rpc.get_token_account_balance(&meta.pool_base_token_account).await?;
            meta.pool_quote_reserves = rpc.get_token_account_balance(&meta.pool_quote_token_account).await?;
            let expected = meta
                .quote_sell_tokens(balance)
                .context("PumpSwap satış kotasyonu hesaplanamadı")?;

            let mut buybacks: Vec<Pubkey> = Vec::new();
            for b in global
                .buyback_fee_recipients
                .iter()
                .copied()
                .chain([default_buyback_fee_recipient(), Pubkey::from_str(PUMPSWAP_ALT_BUYBACK)?])
            {
                if !buybacks.contains(&b) {
                    buybacks.push(b);
                }
            }

            let txs = buybacks
                .into_iter()
                .map(|bb| {
                    let mut m = meta.clone();
                    m.buyback_fee_recipient = bb;
                    build_pumpswap_atomic_sell_ixs(&owner, &m, balance, min_out(expected), true)
                })
                .collect();
            ("PumpSwap AMM", expected, txs)
        }
    };

    let tip = cfg.jito.tip_lamports;
    println!(
        "Mekan   : {venue} | beklenen {:.6} SOL | en az {:.6} SOL (kayma toleransı %{:.1}) | Jito tip {:.6} SOL",
        lamports_to_sol(expected),
        lamports_to_sol(min_out(expected)),
        slip_bps as f64 / 100.0,
        lamports_to_sol(tip)
    );

    let jito = JitoClient::new(
        cfg.jito.block_engine_urls.clone(),
        cfg.jito.uuid.clone(),
        cfg.parsed_tip_accounts()?,
        cfg.network.allenhark_relay_url.clone(),
        cfg.network.allenhark_relay_api_key.clone(),
    )?;

    let bh = rpc.get_latest_blockhash().await?;
    let mut chosen = None;
    let mut last_err = None;
    let mut last_logs = Vec::new();
    for mut ixs in candidates {
        // Botun kendi çıkışıyla aynı: tek-tx Jito bundle + jitodontfront.
        ixs.push(jito.build_tip_ix_with_dontfront(&owner, tip));
        let tx = JitoClient::compile_v0_tx(
            wallet,
            cfg.strategy.compute_unit_limit,
            cfg.strategy.compute_unit_price_micro_lamports,
            ixs,
            bh,
        )?;
        let sim = rpc.simulate_transaction(&tx).await?;
        if sim.success {
            println!("Simülasyon BAŞARILI (CU={})", sim.units_consumed);
            chosen = Some(tx);
            break;
        }
        last_err = sim.error;
        last_logs = sim.logs;
    }
    let Some(tx) = chosen else {
        for l in &last_logs {
            println!("  {l}");
        }
        bail!("Simülasyon başarısız, işlem GÖNDERİLMEDİ: {:?}", last_err);
    };

    let sol_before = rpc.get_balance(&owner).await.unwrap_or(0);
    println!("İmza: https://solscan.io/tx/{}", tx.signatures[0]);

    let mut left = balance;
    for attempt in 1..=BUNDLE_ATTEMPTS {
        match jito.send_single_atomic_tx(&tx).await {
            Ok(receipt) => {
                let state = match receipt.bundle_id {
                    Some(id) => format!("{:?}", jito.wait_for_bundle(&id, Duration::from_millis(3500)).await?),
                    None => {
                        tokio::time::sleep(Duration::from_millis(1500)).await;
                        "bundleOnly kabul edildi".into()
                    }
                };
                println!("Bundle deneme {attempt}/{BUNDLE_ATTEMPTS}: {state}");
            }
            Err(e) => {
                println!("Bundle deneme {attempt}/{BUNDLE_ATTEMPTS}: Jito reddetti: {e}");
                tokio::time::sleep(Duration::from_secs(1)).await;
            }
        }
        left = token_balance_or_zero(&rpc, &user_ata).await.unwrap_or(left);
        if left == 0 {
            break;
        }
    }

    if left > 0 {
        bail!(
            "Bundle zincire girmedi (kalan bakiye {left}); tip ve gas ödenmedi. Komutu tekrar çalıştırın; \
             Jito 429 alıyorsanız jito.uuid girin veya tip_lamports'u artırın"
        );
    }
    let sol_after = rpc.get_balance(&owner).await.unwrap_or(sol_before);
    println!(
        "SATILDI. Cüzdan SOL değişimi: {:+.6} SOL (ücret + ATA kira iadesi dahil)",
        (sol_after as i128 - sol_before as i128) as f64 / 1e9
    );
    Ok(())
}

/// pump.fun mezuniyetinde açılan kanonik havuz: ["pool", index=0, pool-authority, mint, WSOL].
fn canonical_pumpswap_pool(mint: &Pubkey) -> Pubkey {
    let pool_authority =
        Pubkey::find_program_address(&[b"pool-authority", mint.as_ref()], &pump_program_id()).0;
    Pubkey::find_program_address(
        &[
            b"pool",
            &0u16.to_le_bytes(),
            pool_authority.as_ref(),
            mint.as_ref(),
            wsol_mint_id().as_ref(),
        ],
        &pumpswap_program_id(),
    )
    .0
}

/// ATA yoksa (kapatılmış) 0; RPC hatasını 0 saymaz.
async fn token_balance_or_zero(rpc: &SolanaRpcClient, ata: &Pubkey) -> Result<u64> {
    match rpc.get_account_info(ata).await? {
        None => Ok(0),
        Some(_) => rpc.get_token_account_balance(ata).await,
    }
}

fn lamports_to_sol(l: u64) -> f64 {
    l as f64 / 1e9
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn canonical_pool_matches_mainnet() {
        // Zincirden okundu: GHE2bp... havuzunun base_mint'i 6AfhF8...pump, index 0.
        let mint = Pubkey::from_str("6AfhF8NUoB3wbVGXGAdSVQ2sJYzqz2m8mGmFg4EBpump").unwrap();
        let pool = Pubkey::from_str("GHE2bpQkN9DKyCyiCdt9QdDs9iFJY8TbjzXXjeUYQkTt").unwrap();
        assert_eq!(canonical_pumpswap_pool(&mint), pool);
    }
}
