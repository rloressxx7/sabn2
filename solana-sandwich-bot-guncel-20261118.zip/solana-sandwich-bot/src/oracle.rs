use serde_json::Value;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Duration;
use tracing::{debug, info};

/// Sıfır Gecikmeli (1 Nanosaniye RAM Okumalı) Canlı SOL/USD Fiyat Kahini (Oracle).
/// Arka planda her 30 saniyede bir Coinbase ve Kraken spot API'lerinden canlı SOL/USD kurunu günceller;
/// sıcak işlem yolunda (`hot-path`) hiçbir ağ çağrısı yapmadan `AtomicU64` (sent cinsinden) okur!
#[derive(Clone)]
pub struct SolUsdOracle {
    price_cents: Arc<AtomicU64>,
    http: reqwest::Client,
}

impl SolUsdOracle {
    pub fn new(fallback_sol_usd: f64) -> Self {
        let initial_cents = ((fallback_sol_usd.max(1.0)) * 100.0).round() as u64;
        let http = reqwest::Client::builder()
            .timeout(Duration::from_secs(4))
            .connect_timeout(Duration::from_secs(2))
            .user_agent("solana-hft-oracle/5.0")
            .build()
            .unwrap_or_else(|_| reqwest::Client::new());

        Self {
            price_cents: Arc::new(AtomicU64::new(initial_cents)),
            http,
        }
    }

    /// Başlangıçta canlı SOL/USD kurunu çeker; erişilemezse fallback değerini korur.
    pub async fn warm_up(&self) -> f64 {
        if let Some(live_cents) = self.fetch_live_cents().await {
            self.price_cents.store(live_cents, Ordering::Relaxed);
        }
        self.price_usd()
    }

    /// Arka planda 30 saniyede bir canlı SOL/USD fiyatını günceller.
    pub fn spawn_refresher(&self) -> tokio::task::JoinHandle<()> {
        let oracle = self.clone();
        tokio::spawn(async move {
            let mut ticker = tokio::time::interval(Duration::from_secs(30));
            ticker.tick().await;
            loop {
                ticker.tick().await;
                if let Some(cents) = oracle.fetch_live_cents().await {
                    let prev = oracle.price_cents.swap(cents, Ordering::Relaxed);
                    if prev.abs_diff(cents) >= 25 {
                        info!(
                            "[CANLI SOL/USD KURU GÜNCELLENDİ] ${:.2} -> ${:.2}",
                            prev as f64 / 100.0,
                            cents as f64 / 100.0
                        );
                    } else {
                        debug!("Canlı SOL/USD kuru: ${:.2}", cents as f64 / 100.0);
                    }
                }
            }
        })
    }

    #[inline(always)]
    pub fn price_cents(&self) -> u64 {
        self.price_cents.load(Ordering::Relaxed).max(100)
    }

    #[inline(always)]
    pub fn price_usd(&self) -> f64 {
        self.price_cents() as f64 / 100.0
    }

    /// Lamport cinsinden SOL değerini (ör. `mcap_lamports`) anında USD'ye çevirir (0-RPC, 1 ns!).
    #[inline(always)]
    pub fn lamports_to_usd(&self, lamports: u64) -> f64 {
        let cents = self.price_cents() as u128;
        let total_cents = (lamports as u128 * cents) / 1_000_000_000u128;
        total_cents as f64 / 100.0
    }

    /// `mcap_lamports` değerinin `[min_mcap_usd, max_mcap_usd]` aralığında olup olmadığını
    /// kayan nokta hatası olmadan `u128` tam sayı aritmetiğiyle 1 nanosaniyede kontrol eder!
    #[inline(always)]
    pub fn is_mcap_in_usd_window(
        &self,
        mcap_lamports: u64,
        min_mcap_usd: f64,
        max_mcap_usd: f64,
    ) -> bool {
        let sol_cents = self.price_cents() as u128;
        // mcap_usd_cents = (mcap_lamports * sol_cents) / 1e9
        let mcap_usd_cents = (mcap_lamports as u128 * sol_cents) / 1_000_000_000u128;
        let min_cents = (min_mcap_usd.max(0.0) * 100.0).round() as u128;
        let max_cents = (max_mcap_usd.max(min_mcap_usd) * 100.0).round() as u128;
        mcap_usd_cents >= min_cents && mcap_usd_cents <= max_cents
    }

    async fn fetch_live_cents(&self) -> Option<u64> {
        // 1) Coinbase Spot API (ABD & Avrupa'dan çok hızlı ve limitsiz)
        if let Ok(resp) = self
            .http
            .get("https://api.coinbase.com/v2/prices/SOL-USD/spot")
            .send()
            .await
        {
            if let Ok(val) = resp.json::<Value>().await {
                if let Some(s) = val
                    .get("data")
                    .and_then(|d| d.get("amount"))
                    .and_then(|a| a.as_str())
                {
                    if let Ok(p) = s.parse::<f64>() {
                        if p > 5.0 && p < 100_000.0 {
                            return Some((p * 100.0).round() as u64);
                        }
                    }
                }
            }
        }

        // 2) Kraken Spot API (Yedek)
        if let Ok(resp) = self
            .http
            .get("https://api.kraken.com/0/public/Ticker?pair=SOLUSD")
            .send()
            .await
        {
            if let Ok(val) = resp.json::<Value>().await {
                if let Some(s) = val
                    .get("result")
                    .and_then(|r| r.get("SOLUSD"))
                    .and_then(|pair| pair.get("c"))
                    .and_then(|c| c.get(0))
                    .and_then(|v| v.as_str())
                {
                    if let Ok(p) = s.parse::<f64>() {
                        if p > 5.0 && p < 100_000.0 {
                            return Some((p * 100.0).round() as u64);
                        }
                    }
                }
            }
        }

        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_usd_mcap_window_math() {
        // SOL = $100.00 iken $10,000 .. $50,000 MCAP == 100 SOL .. 500 SOL MCAP!
        let oracle = SolUsdOracle::new(100.0);
        assert!(!oracle.is_mcap_in_usd_window(99_900_000_000, 10_000.0, 50_000.0));
        assert!(oracle.is_mcap_in_usd_window(100_000_000_000, 10_000.0, 50_000.0));
        assert!(oracle.is_mcap_in_usd_window(250_000_000_000, 10_000.0, 50_000.0));
        assert!(oracle.is_mcap_in_usd_window(500_000_000_000, 10_000.0, 50_000.0));
        assert!(!oracle.is_mcap_in_usd_window(500_100_000_000, 10_000.0, 50_000.0));
    }
}
