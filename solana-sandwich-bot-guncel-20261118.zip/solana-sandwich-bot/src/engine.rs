use anyhow::{bail, Context, Result};
use dashmap::DashMap;
use solana_commitment_config::CommitmentConfig;
use solana_keypair::Keypair;
use solana_pubkey::Pubkey;
use solana_signer::Signer;
use solana_transaction::versioned::VersionedTransaction;
use std::sync::atomic::Ordering;
use std::sync::Arc;
use std::time::{Duration, Instant};
use tokio::sync::mpsc;
use tracing::{debug, info, warn};

use crate::config::AppConfig;
use crate::grpc_streams::{ShredStreamGrpcMonitor, YellowstoneGeyserMonitor};
use crate::jito::{JitoBundleState, JitoClient};
use crate::monitor::{
    HeliusLogMonitor, MarketEvent, MonitorCounters, RawTxStreamMonitor, TxAccountHints,
};
use crate::oracle::SolUsdOracle;
use crate::pump::{
    build_buy_exact_sol_in_fast_ix, build_buy_exact_tokens_out_fast_ix,
    build_close_token_account_ix, build_sell_fast_ix, create_ata_idempotent_with_ata_ix,
    default_buyback_fee_recipient, derive_ata, derive_bonding_curve_pda,
    derive_creator_vault_pda, derive_event_authority_pda, derive_fee_config_pda, derive_global_pda,
    derive_global_volume_accumulator_pda, derive_user_volume_accumulator_pda, is_native_sol_quote,
    is_supported_token_program, jitodontfront_pubkey, mayhem_agent_wallet, mayhem_program_id,
    mayhem_reserved_fee_recipient, optimize_sandwich, quote_buy_exact_sol_in,
    quote_buy_exact_tokens_out, quote_sell_tokens, token_2022_program_id, tx_has_jitodontfront,
    wsol_mint_id, BondingCurveState, GlobalConfigState, MintDerivedPdas, ParsedTradeEvent,
    ParsedVictimBuy, VictimBuyOrder,
};
use crate::pumpswap::{
    build_pumpswap_atomic_buy_ixs, build_pumpswap_atomic_sell_ixs,
    pumpswap_event_authority_pda, pumpswap_fee_config_pda, pumpswap_global_config_pda,
    pumpswap_global_volume_pda, pumpswap_program_id, ParsedPumpSwapTrade, ParsedPumpSwapWhaleBuy,
    PumpSwapPoolMeta, PumpSwapTxHints,
};
use crate::risk::{CircuitBreaker, CooldownGuard, PnLTracker};
use crate::rpc::{BlockhashCache, SolanaRpcClient};

const BASE_TX_FEE_LAMPORTS: u64 = 5_000;

#[derive(Debug, Clone)]
pub enum PositionVenue {
    PumpBondingCurve {
        pdas: MintDerivedPdas,
        creator_vault: Pubkey,
        buyback_fee_recipient: Option<Pubkey>,
        is_mayhem_mode: bool,
        is_cashback_coin: bool,
    },
    PumpSwapAmm {
        meta: PumpSwapPoolMeta,
        user_base_ata: Pubkey,
    },
}

#[derive(Debug, Clone)]
pub struct ActivePosition {
    pub mint: Pubkey,
    pub token_program: Pubkey,
    pub venue: PositionVenue,
    pub trigger_whale: Option<Pubkey>,
    pub awaiting_mayhem_buy_pump: bool,
    pub token_amount: u64,
    pub exact_fill_confirmed: bool,
    pub entry_cost_lamports: u64,
    pub peak_net_sol_lamports: u64,
    pub opened_at: Instant,
    pub exit_in_flight: bool,
}

impl ActivePosition {
    #[inline]
    pub fn user_ata(&self) -> Pubkey {
        match &self.venue {
            PositionVenue::PumpBondingCurve { pdas, .. } => pdas.user_ata,
            PositionVenue::PumpSwapAmm { user_base_ata, .. } => *user_base_ata,
        }
    }
}

#[derive(Debug, Clone)]
struct MintResolvedMeta {
    token_program: Pubkey,
    curve: BondingCurveState,
}

pub struct BotEngine {
    cfg: AppConfig,
    wallet: Arc<Keypair>,
    wallet_pubkey: Pubkey,
    wallet_user_vol_pda: Pubkey,
    mayhem_wallets: Vec<Pubkey>,
    oracle: SolUsdOracle,
    rpc: SolanaRpcClient,
    blockhash_cache: Arc<BlockhashCache>,
    jito: JitoClient,
    breaker: Arc<CircuitBreaker>,
    pnl: Arc<PnLTracker>,
    cooldowns: Arc<CooldownGuard>,
    global_cfg: GlobalConfigState,
    positions: Arc<DashMap<Pubkey, ActivePosition>>,
    curve_cache: Arc<DashMap<Pubkey, (BondingCurveState, Instant)>>,
    pumpswap_cache: Arc<DashMap<Pubkey, (PumpSwapPoolMeta, Instant)>>,
    ps_hint_cache: Arc<DashMap<Pubkey, PumpSwapTxHints>>,
    mint_prog_cache: Arc<DashMap<Pubkey, Pubkey>>,
    mint_pdas_cache: Arc<DashMap<Pubkey, MintDerivedPdas>>,
    hint_cache: Arc<DashMap<Pubkey, TxAccountHints>>,
    mayhem_sell_streak: Arc<DashMap<Pubkey, u8>>,
    counters: Arc<MonitorCounters>,
}

impl BotEngine {
    pub async fn initialize(cfg: AppConfig, wallet: Keypair) -> Result<Arc<Self>> {
        cfg.validate()?;

        // Tüm statik Pump + PumpSwap + Mayhem PDA'ları başlangıçta önbelleğe al (sıcak yolda 0 SHA256!)
        let _ = (
            derive_global_pda(),
            derive_event_authority_pda(),
            derive_global_volume_accumulator_pda(),
            derive_fee_config_pda(),
            jitodontfront_pubkey(),
            mayhem_program_id(),
            mayhem_agent_wallet(),
            mayhem_reserved_fee_recipient(),
            default_buyback_fee_recipient(),
            pumpswap_program_id(),
            pumpswap_global_config_pda(),
            pumpswap_event_authority_pda(),
            pumpswap_fee_config_pda(),
            pumpswap_global_volume_pda(),
        );
        let wallet_pubkey = wallet.pubkey();
        let wallet_user_vol_pda = derive_user_volume_accumulator_pda(&wallet_pubkey);
        let mayhem_wallets = cfg.parsed_mayhem_wallets()?;

        let oracle = SolUsdOracle::new(cfg.whale.fallback_sol_usd);
        let live_sol_usd = oracle.warm_up().await;

        let rpc_urls: Vec<String> = if cfg.network.rpc_endpoints.is_empty() {
            vec![cfg.network.rpc_http.clone()]
        } else {
            cfg.network.rpc_endpoints.clone()
        };
        let rpc = SolanaRpcClient::new(rpc_urls, CommitmentConfig::processed());
        let blockhash_cache = Arc::new(BlockhashCache::new(rpc.clone()));
        let bh = blockhash_cache
            .warm_up()
            .await
            .context("Başlangıç blockhash alınamadı — HTTP RPC adresinizi kontrol edin")?;

        let global_pda = derive_global_pda();
        let global_cfg = match rpc.get_account_info(&global_pda).await? {
            Some(acc) => GlobalConfigState::from_account_data(&acc.data)
                .unwrap_or_else(|_| GlobalConfigState::default()),
            None => GlobalConfigState::default(),
        };

        let tip_accounts = cfg.parsed_tip_accounts()?;
        let jito = JitoClient::new(
            cfg.jito.block_engine_urls.clone(),
            cfg.jito.uuid.clone(),
            tip_accounts,
            cfg.network.allenhark_relay_url.clone(),
            cfg.network.allenhark_relay_api_key.clone(),
        )?;

        let wallet_balance = rpc.get_balance(&wallet_pubkey).await.unwrap_or(0);

        info!("============================================================");
        info!("Pump.fun + PumpSwap [$10k–$50k MCAP | >=5 SOL WHALE] Motoru v5.0");
        info!("Cüzdan Adresi         : {}", wallet_pubkey);
        info!(
            "Cüzdan Bakiyesi       : {:.6} SOL ({} lamports)",
            wallet_balance as f64 / 1_000_000_000.0,
            wallet_balance
        );
        info!(
            "Canlı SOL/USD Kuru    : ${:.2} (Her 30 sn'de otomatik güncellenir)",
            live_sol_usd
        );
        if cfg.whale.enabled {
            let min_sol_eq = cfg.whale.min_mcap_usd / live_sol_usd.max(1.0);
            let max_sol_eq = cfg.whale.max_mcap_usd / live_sol_usd.max(1.0);
            info!(
                "BALİNA HEDEF FİLTRESİ : ${:.0} – ${:.0} MCAP (~{:.1} – {:.1} SOL MCAP) | MinAlım >= {:.2} SOL",
                cfg.whale.min_mcap_usd,
                cfg.whale.max_mcap_usd,
                min_sol_eq,
                max_sol_eq,
                cfg.whale.min_whale_buy_sol
            );
            info!(
                "Kapsanan Havuzlar     : PumpBondingCurve={} ($10k..~$29.5k) | PumpSwapAMM={} (~$29.5k..$50k)",
                cfg.whale.trade_pump_bonding_curve, cfg.whale.trade_pumpswap_amm
            );
        }
        if cfg.mayhem.enabled {
            info!(
                "Ek Mayhem Filtresi    : {:.2} – {:.2} SOL MCAP (Mod={:?})",
                cfg.mayhem.min_mcap_sol, cfg.mayhem.max_mcap_sol, cfg.mayhem.entry_mode
            );
        }
        info!(
            "Bizim İşlem Büyüklüğü : {:.4} SOL | Taban Jito Tip: {:.5} SOL ({} lamports)",
            cfg.strategy.position_sol,
            cfg.jito.tip_lamports as f64 / 1_000_000_000.0,
            cfg.jito.tip_lamports
        );
        info!(
            "Atomik Revert Koruması: {} (Başarısız İşlem = 0 SOL, Solscan = 0 Hata!)",
            if !cfg.network.dual_send_momentum {
                "TAM ATOMİK (Jito bundleOnly + sendBundle + jitodontfront)"
            } else {
                "Kısmi (dual_send_momentum açık)"
            }
        );
        info!("Başlangıç Blockhash   : {}", bh);
        info!("============================================================");

        let min_needed_lamports = (cfg.strategy.position_sol * 1_000_000_000.0) as u64
            + cfg.jito.tip_lamports
            + 4_250_000;
        if wallet_balance < min_needed_lamports {
            warn!(
                "UYARI: Cüzdan bakiyesi ({:.6} SOL) PumpSwap geçici WSOL+Token ATA kirası (~0.0041 SOL, satışta %100 geri döner!) için düşük olabilir (~{:.4} SOL önerilir).",
                wallet_balance as f64 / 1_000_000_000.0,
                min_needed_lamports as f64 / 1_000_000_000.0
            );
        }

        let breaker = Arc::new(CircuitBreaker::new(cfg.risk.max_errors_per_minute));

        Ok(Arc::new(Self {
            cfg,
            wallet: Arc::new(wallet),
            wallet_pubkey,
            wallet_user_vol_pda,
            mayhem_wallets,
            oracle,
            rpc,
            blockhash_cache,
            jito,
            breaker,
            pnl: Arc::new(PnLTracker::new()),
            cooldowns: Arc::new(CooldownGuard::new()),
            global_cfg,
            positions: Arc::new(DashMap::new()),
            curve_cache: Arc::new(DashMap::new()),
            pumpswap_cache: Arc::new(DashMap::new()),
            ps_hint_cache: Arc::new(DashMap::new()),
            mint_prog_cache: Arc::new(DashMap::new()),
            mint_pdas_cache: Arc::new(DashMap::new()),
            hint_cache: Arc::new(DashMap::new()),
            mayhem_sell_streak: Arc::new(DashMap::new()),
            counters: Arc::new(MonitorCounters::default()),
        }))
    }

    #[inline(always)]
    fn is_mayhem_agent(&self, user: &Pubkey) -> bool {
        self.mayhem_wallets.iter().any(|w| w == user)
    }

    #[inline]
    fn get_or_derive_pdas(
        &self,
        mint: &Pubkey,
        bonding_curve_opt: Option<Pubkey>,
        token_program: &Pubkey,
    ) -> MintDerivedPdas {
        if let Some(cached) = self.mint_pdas_cache.get(mint) {
            return *cached.value();
        }
        let pdas =
            MintDerivedPdas::derive(mint, bonding_curve_opt, token_program, &self.wallet_pubkey);
        self.mint_pdas_cache.insert(*mint, pdas);
        pdas
    }

    #[inline]
    fn prewarm_from_parsed(&self, parsed: &ParsedVictimBuy) {
        self.mint_prog_cache
            .insert(parsed.mint, parsed.token_program);
        self.hint_cache.insert(
            parsed.mint,
            TxAccountHints {
                token_program: parsed.token_program,
                creator_vault: parsed.creator_vault,
                fee_recipient: parsed.fee_recipient,
                buyback_fee_recipient: parsed.buyback_fee_recipient,
            },
        );
        let _ = self.get_or_derive_pdas(
            &parsed.mint,
            Some(parsed.bonding_curve),
            &parsed.token_program,
        );
    }

    pub async fn run(self: Arc<Self>) -> Result<()> {
        let _bh_worker = self.blockhash_cache.spawn_refresher();
        let _oracle_worker = self.oracle.spawn_refresher();
        let _jito_warmer = self.jito.spawn_connection_warmer();

        let (event_tx, mut event_rx) = mpsc::channel::<MarketEvent>(8192);

        if let Some(geyser_url) = self.cfg.network.geyser_grpc_url.clone() {
            let geyser_mon = YellowstoneGeyserMonitor::new(
                geyser_url,
                self.cfg.network.geyser_x_token.clone(),
                (*self.blockhash_cache).clone(),
                event_tx.clone(),
                self.counters.clone(),
            );
            tokio::spawn(async move {
                geyser_mon.run_forever().await;
            });
        }

        if let Some(shred_url) = self.cfg.network.shredstream_grpc_url.clone() {
            let shred_mon = ShredStreamGrpcMonitor::new(
                shred_url,
                self.cfg.network.shredstream_api_key.clone(),
                event_tx.clone(),
                self.counters.clone(),
            );
            tokio::spawn(async move {
                shred_mon.run_forever().await;
            });
        }

        if let Some(ws_url) = self.cfg.network.rpc_ws.clone() {
            if !ws_url.contains("YOUR_HELIUS_KEY") {
                let helius_mon = HeliusLogMonitor::new(
                    ws_url,
                    self.rpc.clone(),
                    event_tx.clone(),
                    self.counters.clone(),
                );
                tokio::spawn(async move {
                    helius_mon.run_forever().await;
                });
            }
        }

        if self.cfg.mode.strategy.runs_sandwich()
            || self.cfg.whale.frontrun_via_jito_bundle
            || self.cfg.mayhem.frontrun_via_jito_bundle
        {
            if let Some(raw_ws) = self.cfg.network.raw_tx_ws.clone() {
                let raw_mon =
                    RawTxStreamMonitor::new(raw_ws, event_tx.clone(), self.counters.clone());
                tokio::spawn(async move {
                    raw_mon.run_forever().await;
                });
            }
        }

        {
            let eng = self.clone();
            tokio::spawn(async move {
                eng.position_supervisor_loop().await;
            });
        }

        {
            let eng = self.clone();
            tokio::spawn(async move {
                let mut ticker = tokio::time::interval(Duration::from_secs(30));
                ticker.tick().await;
                loop {
                    ticker.tick().await;
                    let snap = eng.pnl.snapshot();
                    info!(
                        "[TELEMETRİ] SOL=${:.2} | gRPC={} | CurveTx={} | PumpSwapTx={} | Balina($10k-$50k,>=5SOL)={} | AçıkPoz={} | NetPnL={:+.6} SOL ({}/{} Win)",
                        eng.oracle.price_usd(),
                        eng.counters.grpc_messages.load(Ordering::Relaxed),
                        eng.counters.decoded_trades.load(Ordering::Relaxed),
                        eng.counters.pumpswap_trades.load(Ordering::Relaxed),
                        eng.counters.whale_10k_50k_signals.load(Ordering::Relaxed),
                        eng.positions.len(),
                        snap.total_profit_lamports as f64 / 1_000_000_000.0,
                        snap.winning_trades,
                        snap.total_trades,
                    );
                }
            });
        }

        while let Some(ev) = event_rx.recv().await {
            match ev {
                MarketEvent::ConfirmedTrade {
                    signature,
                    trade,
                    hints,
                } => {
                    self.on_confirmed_trade(signature, trade, hints).await;
                }
                MarketEvent::ConfirmedPumpSwapTrade {
                    signature,
                    trade,
                    hints,
                } => {
                    self.on_confirmed_pumpswap_trade(signature, trade, hints)
                        .await;
                }
                MarketEvent::ShredFastBuy {
                    slot,
                    signature,
                    victim_tx,
                    parsed,
                } => {
                    self.prewarm_from_parsed(&parsed);
                    if self.cfg.mode.strategy.runs_momentum() {
                        let eng = self.clone();
                        tokio::spawn(async move {
                            if let Err(e) =
                                eng.on_shred_fast_buy(slot, signature, victim_tx, parsed).await
                            {
                                debug!("Shred Pump hızlı alım atlandı: {}", e);
                            }
                        });
                    }
                }
                MarketEvent::ShredFastPumpSwapBuy {
                    slot,
                    signature,
                    victim_tx,
                    parsed,
                } => {
                    self.ps_hint_cache.insert(parsed.hints.pool, parsed.hints);
                    if self.cfg.mode.strategy.runs_momentum() {
                        let eng = self.clone();
                        tokio::spawn(async move {
                            if let Err(e) = eng
                                .on_shred_pumpswap_buy(slot, signature, victim_tx, parsed)
                                .await
                            {
                                debug!("Shred PumpSwap hızlı alım atlandı: {}", e);
                            }
                        });
                    }
                }
                MarketEvent::PreExecutionVictimBuy {
                    signature,
                    victim_tx,
                    parsed,
                } => {
                    self.prewarm_from_parsed(&parsed);
                    let eng = self.clone();
                    tokio::spawn(async move {
                        if let Err(e) =
                            eng.on_pre_execution_victim(signature, victim_tx, parsed).await
                        {
                            debug!("Pre-exec Pump front-run/sandwich atlandı: {}", e);
                        }
                    });
                }
                MarketEvent::PreExecutionPumpSwapBuy {
                    signature,
                    victim_tx,
                    parsed,
                } => {
                    self.ps_hint_cache.insert(parsed.hints.pool, parsed.hints);
                    let eng = self.clone();
                    tokio::spawn(async move {
                        if let Err(e) = eng
                            .on_pre_execution_pumpswap_buy(signature, victim_tx, parsed)
                            .await
                        {
                            debug!("Pre-exec PumpSwap front-run atlandı: {}", e);
                        }
                    });
                }
            }
        }

        Ok(())
    }

    fn check_entry_guards(&self, mint: &Pubkey) -> Result<()> {
        if self.breaker.is_open() {
            bail!("Devre kesici (Circuit Breaker) açık");
        }
        let max_loss = (self.cfg.risk.max_daily_loss_sol * 1_000_000_000.0) as u64;
        if self.pnl.is_daily_loss_exceeded(max_loss) {
            bail!("Günlük maksimum zarar limiti aşıldı");
        }
        if self.positions.len() >= self.cfg.risk.max_concurrent_positions {
            bail!("Maksimum eşzamanlı pozisyon sınırı dolu");
        }
        if self.positions.contains_key(mint) {
            bail!("Bu mint'te zaten açık pozisyon var");
        }
        let cd = Duration::from_secs(self.cfg.risk.cooldown_per_mint_secs);
        if !self.cooldowns.check_and_mark_mint(mint, cd) {
            bail!("Mint soğuma (cooldown) süresinde");
        }
        Ok(())
    }

    // ========================================================================
    // VENUE 1: PUMP.FUN BONDING CURVE (`$10,000 – ~$29,500` MCAP | `>= 5 SOL` BALİNA)
    // ========================================================================

    fn on_own_pump_trade(&self, trade: &ParsedTradeEvent, hints: Option<TxAccountHints>) {
        let live_curve = trade.to_curve_state();
        self.curve_cache
            .insert(trade.mint, (live_curve.clone(), Instant::now()));

        if trade.is_buy {
            if let Some(mut pos) = self.positions.get_mut(&trade.mint) {
                pos.token_amount = trade.token_amount;
                pos.exact_fill_confirmed = true;
                if let PositionVenue::PumpBondingCurve {
                    is_mayhem_mode,
                    is_cashback_coin,
                    ..
                } = &mut pos.venue
                {
                    *is_mayhem_mode = trade.mayhem_mode;
                    *is_cashback_coin = trade.cashback_enabled;
                }
                info!(
                    "[0-RPC PUMP DOLUM ONAYI] Mint={} | MCAP=${:.0} | KesinToken={} | HarcananSOL={:.6}",
                    trade.mint,
                    self.oracle.lamports_to_usd(live_curve.market_cap_lamports(false)),
                    trade.token_amount,
                    (trade.sol_amount + trade.fee + trade.creator_fee) as f64 / 1_000_000_000.0
                );
            } else {
                let effective_hints =
                    hints.or_else(|| self.hint_cache.get(&trade.mint).map(|r| *r.value()));
                let tp = effective_hints
                    .map(|h| h.token_program)
                    .unwrap_or_else(token_2022_program_id);
                let cv = effective_hints
                    .map(|h| h.creator_vault)
                    .unwrap_or_else(|| derive_creator_vault_pda(&trade.creator));
                let bb = self.global_cfg.effective_buyback_recipient(
                    effective_hints.and_then(|h| h.buyback_fee_recipient),
                );
                let pdas =
                    self.get_or_derive_pdas(&trade.mint, Some(live_curve.bonding_curve), &tp);
                let total_in = trade
                    .sol_amount
                    .saturating_add(trade.fee)
                    .saturating_add(trade.creator_fee)
                    .saturating_add(self.cfg.jito.tip_lamports)
                    .saturating_add(BASE_TX_FEE_LAMPORTS);
                self.positions.insert(
                    trade.mint,
                    ActivePosition {
                        mint: trade.mint,
                        token_program: tp,
                        venue: PositionVenue::PumpBondingCurve {
                            pdas,
                            creator_vault: cv,
                            buyback_fee_recipient: bb,
                            is_mayhem_mode: trade.mayhem_mode,
                            is_cashback_coin: trade.cashback_enabled,
                        },
                        trigger_whale: None,
                        awaiting_mayhem_buy_pump: false,
                        token_amount: trade.token_amount,
                        exact_fill_confirmed: true,
                        entry_cost_lamports: total_in,
                        peak_net_sol_lamports: trade.sol_amount,
                        opened_at: Instant::now(),
                        exit_in_flight: false,
                    },
                );
            }
        } else if let Some((_, closed_pos)) = self.positions.remove(&trade.mint) {
            let net_sol_from_curve = trade
                .sol_amount
                .saturating_sub(trade.fee)
                .saturating_sub(trade.creator_fee);
            let net_pnl = net_sol_from_curve as i64
                - closed_pos.entry_cost_lamports as i64
                - self.cfg.jito.tip_lamports as i64
                - BASE_TX_FEE_LAMPORTS as i64;
            self.pnl.record_trade(net_pnl);
            self.breaker.record_success();
            info!(
                "[0-RPC PUMP SATIŞ ONAYI & ATA KİRA İADESİ] Mint={} | Net PnL={:+.6} SOL",
                trade.mint,
                net_pnl as f64 / 1_000_000_000.0
            );
        }
    }

    async fn on_confirmed_trade(
        self: &Arc<Self>,
        signature: String,
        trade: ParsedTradeEvent,
        hints: Option<TxAccountHints>,
    ) {
        if let Some(h) = hints {
            self.mint_prog_cache.insert(trade.mint, h.token_program);
            self.hint_cache.insert(trade.mint, h);
            let _ = self.get_or_derive_pdas(&trade.mint, None, &h.token_program);
        }

        if trade.user == self.wallet_pubkey {
            self.on_own_pump_trade(&trade, hints);
            return;
        }

        let live_curve = trade.to_curve_state();
        self.curve_cache
            .insert(trade.mint, (live_curve.clone(), Instant::now()));

        let from_mayhem_bot = self.is_mayhem_agent(&trade.user);
        let current_sell_streak = if from_mayhem_bot {
            if trade.is_buy {
                self.mayhem_sell_streak.insert(trade.mint, 0);
                0
            } else {
                let mut entry = self.mayhem_sell_streak.entry(trade.mint).or_insert(0);
                *entry = entry.saturating_add(1);
                *entry
            }
        } else {
            0
        };

        // Açık pozisyon varsa: Balina veya Mayhem satış kalkanı + 0-RPC TP/SL kontrolü!
        if self.positions.contains_key(&trade.mint) {
            let mut immediate_shield_reason: Option<String> = None;

            if let Some(mut pos_ref) = self.positions.get_mut(&trade.mint) {
                if from_mayhem_bot && trade.is_buy && pos_ref.awaiting_mayhem_buy_pump {
                    pos_ref.awaiting_mayhem_buy_pump = false;
                } else if !trade.is_buy && !pos_ref.exit_in_flight {
                    if self.cfg.whale.instant_exit_on_whale_sell
                        && pos_ref.trigger_whale == Some(trade.user)
                    {
                        pos_ref.exit_in_flight = true;
                        immediate_shield_reason = Some(format!(
                            "Takip edilen Balina ({:.2} SOL) satış yaptı — Anında Atomik Çıkış",
                            trade.sol_amount as f64 / 1_000_000_000.0
                        ));
                    } else if from_mayhem_bot
                        && self.cfg.mayhem.enabled
                        && self.cfg.mayhem.instant_exit_on_mayhem_sell
                        && !pos_ref.awaiting_mayhem_buy_pump
                    {
                        pos_ref.exit_in_flight = true;
                        immediate_shield_reason = Some(format!(
                            "Mayhem Bot satış yaptı ({:.4} SOL) — Anında Atomik Çıkış",
                            trade.sol_amount as f64 / 1_000_000_000.0
                        ));
                    }
                }
            }

            if let Some(reason) = immediate_shield_reason {
                let eng = self.clone();
                let mint = trade.mint;
                tokio::spawn(async move {
                    if let Err(e) = eng
                        .execute_pump_exit(mint, &live_curve, &reason, false)
                        .await
                    {
                        debug!("Koruma çıkışı yeniden denenecek ({}): {}", mint, e);
                        if let Some(mut p) = eng.positions.get_mut(&mint) {
                            p.exit_in_flight = false;
                        }
                    }
                });
                return;
            }

            let eng = self.clone();
            let mint = trade.mint;
            tokio::spawn(async move {
                eng.evaluate_pump_position(mint, live_curve).await;
            });
            return;
        }

        if !self.cfg.mode.strategy.runs_momentum() || !is_native_sol_quote(&trade.quote_mint) {
            return;
        }

        // ====================================================================
        // GİRİŞ KARARI (PUMP.FUN BONDING CURVE):
        //   1) $10,000 – $50,000 USD MCAP + >= 5.0 SOL BALİNA ALIMI (`whale.enabled`)
        //   2) Opsiyonel Mayhem 0.20 – 1.00 SOL MCAP (`mayhem.enabled`)
        // ====================================================================
        let mut matched_whale = false;
        let mut entered_as_dip_prebuy = false;

        if self.cfg.whale.enabled
            && self.cfg.whale.trade_pump_bonding_curve
            && trade.is_buy
            && !(self.cfg.whale.ignore_mayhem_bot_as_whale && from_mayhem_bot)
            && trade.sol_amount >= self.cfg.whale.min_buy_lamports()
        {
            let pre_buy_mcap_lamports = trade.pre_trade_curve_state().market_cap_lamports(false);
            if self.oracle.is_mcap_in_usd_window(
                pre_buy_mcap_lamports,
                self.cfg.whale.min_mcap_usd,
                self.cfg.whale.max_mcap_usd,
            ) {
                if live_curve.complete {
                    info!(
                        "[BALİNA EĞRİYİ MEZUN ETTİ!] Mint={} | Balina={:.2} SOL | PumpSwap ($29.5k-$50k) akışı izleniyor.",
                        trade.mint,
                        trade.sol_amount as f64 / 1_000_000_000.0
                    );
                    return;
                }
                matched_whale = true;
                self.counters
                    .whale_10k_50k_signals
                    .fetch_add(1, Ordering::Relaxed);
            }
        }

        if !matched_whale {
            if from_mayhem_bot && self.cfg.mayhem.enabled {
                let use_2b = self.cfg.mayhem.use_2b_supply_for_mcap;
                if trade.is_buy {
                    if !self.cfg.mayhem.entry_mode.triggers_on_confirmed_buy()
                        || trade.sol_amount < self.cfg.mayhem.min_buy_lamports()
                    {
                        return;
                    }
                    let pre_mcap = trade.pre_trade_curve_state().market_cap_lamports(use_2b);
                    if !self.cfg.mayhem.is_mcap_in_window(pre_mcap) {
                        return;
                    }
                    self.counters
                        .mayhem_bot_buys
                        .fetch_add(1, Ordering::Relaxed);
                } else {
                    if !self.cfg.mayhem.entry_mode.triggers_on_dip_before_buy()
                        || current_sell_streak < self.cfg.mayhem.dip_consecutive_sells.max(1)
                    {
                        return;
                    }
                    let post_mcap = live_curve.market_cap_lamports(use_2b);
                    if !self.cfg.mayhem.is_mcap_in_window(post_mcap) {
                        return;
                    }
                    entered_as_dip_prebuy = true;
                    self.counters
                        .mayhem_bot_buys
                        .fetch_add(1, Ordering::Relaxed);
                }
            } else {
                return;
            }
        }

        if !self.cooldowns.check_and_mark_signature(&signature) {
            return;
        }
        if let Err(reason) = self.check_entry_guards(&trade.mint) {
            warn!("⚠️ PUMP GİRİŞ FİLTRELENDİ: Mint={} | Neden: {}", trade.mint, reason);
            return;
        }

        let eng = self.clone();
        let drop_mint = trade.mint;
        let drop_sol = trade.sol_amount;
        tokio::spawn(async move {
            if let Err(e) = eng
                .execute_pump_momentum_entry(
                    signature,
                    trade,
                    hints,
                    matched_whale,
                    from_mayhem_bot,
                    entered_as_dip_prebuy,
                )
                .await
            {
                warn!(
                    "⚠️ PUMP GİRİŞ REDDEDİLDİ (0 SOL kayıp): Mint={} | Balina={:.2} SOL | Hata: {}",
                    drop_mint,
                    drop_sol as f64 / 1_000_000_000.0,
                    e
                );
            }
        });
    }

    async fn execute_pump_momentum_entry(
        self: &Arc<Self>,
        trigger_sig: String,
        trade: ParsedTradeEvent,
        hints: Option<TxAccountHints>,
        matched_whale: bool,
        from_mayhem_bot: bool,
        entered_as_dip_prebuy: bool,
    ) -> Result<()> {
        let t0 = Instant::now();
        let mint = trade.mint;
        let effective_hints = hints.or_else(|| self.hint_cache.get(&mint).map(|r| *r.value()));

        let (token_program, creator_vault, fee_recipient, buyback_recipient, curve) =
            if self.cfg.strategy.zero_rpc_fast_entry {
                if let Some(h) = effective_hints {
                    let mut c = trade.to_curve_state();
                    if from_mayhem_bot {
                        c.is_mayhem_mode = true;
                    }
                    let checked_fr = self
                        .global_cfg
                        .effective_fee_recipient_checked(c.is_mayhem_mode, Some(h.fee_recipient));
                    let checked_bb = self
                        .global_cfg
                        .effective_buyback_recipient(h.buyback_fee_recipient);
                    // v3 eğrili Token-2022 tx'lerde gRPC hint'te creator_vault sıfır gelir;
                    // Pump programı creator_vault PDA'sını ["creator-vault", creator] seed'inden
                    // türetip karşılaştırır, bu yüzden sıfır geçmek ConstraintSeeds (2006) hatası verir.
                    let cv_hint = if h.creator_vault == Pubkey::default() {
                        if c.creator == Pubkey::default() {
                            h.creator_vault // hiçbir çare yok, olduğu gibi geç
                        } else {
                            derive_creator_vault_pda(&c.creator)
                        }
                    } else {
                        h.creator_vault
                    };
                    (h.token_program, cv_hint, checked_fr, checked_bb, c)
                } else {
                    let meta = self.resolve_mint_and_curve(&mint).await?;
                    let cv = derive_creator_vault_pda(&meta.curve.creator);
                    let fr = self
                        .global_cfg
                        .effective_fee_recipient(meta.curve.is_mayhem_mode);
                    let bb = self.global_cfg.effective_buyback_recipient(None);
                    (meta.token_program, cv, fr, bb, meta.curve)
                }
            } else {
                let meta = self.resolve_mint_and_curve(&mint).await?;
                let cv = derive_creator_vault_pda(&meta.curve.creator);
                let fr = self
                    .global_cfg
                    .effective_fee_recipient(meta.curve.is_mayhem_mode);
                let bb = self.global_cfg.effective_buyback_recipient(None);
                (meta.token_program, cv, fr, bb, meta.curve)
            };

        if curve.complete {
            bail!("Bonding curve tamamlanmış (mezun olmuş)");
        }
        let fill_pct = curve.fill_percentage();
        if fill_pct > self.cfg.risk.max_curve_fill_pct {
            bail!(
                "Bonding curve doluluğu yüksek ({:.1}% > {:.1}%)",
                fill_pct,
                self.cfg.risk.max_curve_fill_pct
            );
        }

        let spendable_sol = (self.cfg.strategy.position_sol * 1_000_000_000.0) as u64;
        let creator_bps = curve.effective_creator_fee_bps(self.global_cfg.creator_fee_basis_points);
        let buy_quote = quote_buy_exact_sol_in(
            &curve,
            spendable_sol,
            self.global_cfg.fee_basis_points,
            creator_bps,
        )
        .context("Pump alım kotasyonu üretilemedi")?;

        if buy_quote.price_impact_pct > self.cfg.risk.max_price_impact_pct {
            bail!(
                "Fiyat etkisi çok yüksek ({:.2}% > {:.2}%)",
                buy_quote.price_impact_pct,
                self.cfg.risk.max_price_impact_pct
            );
        }

        let min_tokens_out = ((buy_quote.tokens_out as u128
            * (10_000u128.saturating_sub(self.cfg.strategy.buy_slippage_bps as u128)))
            / 10_000u128) as u64;

        let pdas = self.get_or_derive_pdas(&mint, Some(curve.bonding_curve), &token_program);
        let create_ata_ix = create_ata_idempotent_with_ata_ix(
            &self.wallet_pubkey,
            &self.wallet_pubkey,
            &pdas.user_ata,
            &mint,
            &token_program,
        );
        let buy_ix = build_buy_exact_sol_in_fast_ix(
            &self.wallet_pubkey,
            &self.wallet_user_vol_pda,
            &mint,
            &pdas,
            &fee_recipient,
            &creator_vault,
            &token_program,
            buyback_recipient.as_ref(),
            spendable_sol,
            min_tokens_out.max(1),
            false,
        );
        let tip_ix = self
            .jito
            .build_tip_ix_with_dontfront(&self.wallet_pubkey, self.cfg.jito.tip_lamports);

        let recent_bh = self.blockhash_cache.get().await?;
        let buy_tx = JitoClient::compile_v0_tx(
            &self.wallet,
            self.cfg.strategy.compute_unit_limit,
            self.cfg.strategy.compute_unit_price_micro_lamports,
            vec![create_ata_ix.clone(), buy_ix.clone(), tip_ix],
            recent_bh,
        )?;

        let build_us = t0.elapsed().as_micros();
        if !self.cfg.risk.simulate_before_submit {
            warn!(
                "⚠️ simulate_before_submit = KAPALI: Mint={} | İşlem pre-flight kontrolü yapılmadan Jito'ya gönderiliyor!",
                mint
            );
        }
        if self.cfg.risk.simulate_before_submit {
            self.simulate_checked(&buy_tx, "Pump Atomik Alım").await?;
        }

        let pre_mcap_usd = self
            .oracle
            .lamports_to_usd(trade.pre_trade_curve_state().market_cap_lamports(false));
        let post_mcap_usd = self
            .oracle
            .lamports_to_usd(curve.market_cap_lamports(false));

        info!(
            "[PUMP EĞRİ BALİNA GİRİŞ] Mint={} | Balina={:.2} SOL | AlımAnıMCAP=${:.0} -> ŞuAn=${:.0} | BizimAlım={:.4} SOL | Derleme={} µs ({})",
            mint,
            trade.sol_amount as f64 / 1_000_000_000.0,
            pre_mcap_usd,
            post_mcap_usd,
            spendable_sol as f64 / 1_000_000_000.0,
            build_us,
            &trigger_sig[..trigger_sig.len().min(10)]
        );

        // --- İntra-tx kiraya kontrolü: cüzdanın işlem içinde kilitlenecek tüm renti karşılayabilir mi? ---
        let wallet_lamports = self.rpc.get_balance(&self.wallet_pubkey).await.unwrap_or(0);
        let needs_ata_rent = if self.rpc.get_token_account_balance(&pdas.user_ata).await.unwrap_or(0) == 0 {
            2_074_080 // Token-2022 ATA kiraya (varsa zaten var ve 0 ek maliyet)
        } else {
            0
        };
        let min_wallet_rent = 890_880u64;
        let required_lamports = min_wallet_rent
            .saturating_add(needs_ata_rent)
            .saturating_add(spendable_sol)
            .saturating_add(self.cfg.jito.tip_lamports)
            .saturating_add(BASE_TX_FEE_LAMPORTS);
        if wallet_lamports < required_lamports {
            warn!(
                "⚠️ YETERSİZ BAKİYE (intra-tx kiraya): Mint={} | Cüzdan={} lamports | Gerekli≈{} lamports | İşlem iptal, 0 SOL kayıp",
                mint, wallet_lamports, required_lamports
            );
            bail!(
                "Yetersiz bakiye intra-tx kiraya: cüzdan={} < gerekli={} lamports",
                wallet_lamports,
                required_lamports
            );
        }

        let landed = self
            .dispatch_atomic_tx(&buy_tx, pdas.user_ata, Some((&create_ata_ix, &buy_ix, recent_bh)))
            .await;

        if !landed {
            warn!(
                "⚠️ JITO BUNDLE YERLEŞMEDİ: Mint={} | Tip={} lamports | CU limit={} | 0 SOL kayıp",
                mint,
                self.cfg.jito.tip_lamports,
                self.cfg.strategy.compute_unit_limit
            );
            bail!("Atomik alım hedef slotta yerleşmedi (0 SOL kayıp)");
        }

        self.breaker.record_success();
        self.confirm_and_register_position(
            mint,
            token_program,
            PositionVenue::PumpBondingCurve {
                pdas,
                creator_vault,
                buyback_fee_recipient: buyback_recipient,
                is_mayhem_mode: curve.is_mayhem_mode,
                is_cashback_coin: curve.is_cashback_coin,
            },
            if matched_whale { Some(trade.user) } else { None },
            entered_as_dip_prebuy,
            buy_quote.tokens_out,
            spendable_sol,
        )
        .await
    }

    // ========================================================================
    // VENUE 2: PUMPSWAP AMM (`~$29,500 – $50,000` MCAP | `>= 5.0 SOL` BALİNA!)
    // ========================================================================

    fn on_own_pumpswap_trade(
        &self,
        trade: &ParsedPumpSwapTrade,
        hints: Option<PumpSwapTxHints>,
    ) {
        let Some(h) = hints.or_else(|| self.ps_hint_cache.get(&trade.pool).map(|r| *r.value()))
        else {
            return;
        };
        let meta = trade.to_pool_meta(&h);
        let mint = meta.base_mint;
        self.pumpswap_cache
            .insert(trade.pool, (meta.clone(), Instant::now()));

        if trade.is_buy {
            if let Some(mut pos) = self.positions.get_mut(&mint) {
                pos.token_amount = trade.token_amount;
                pos.exact_fill_confirmed = true;
                info!(
                    "[0-RPC PUMPSWAP DOLUM ONAYI] Mint={} | MCAP=${:.0} | KesinToken={} | HarcananSOL={:.6}",
                    mint,
                    self.oracle.lamports_to_usd(meta.market_cap_lamports()),
                    trade.token_amount,
                    trade.sol_amount as f64 / 1_000_000_000.0
                );
            }
        } else if let Some((_, closed_pos)) = self.positions.remove(&mint) {
            let net_pnl = trade.sol_amount as i64
                - closed_pos.entry_cost_lamports as i64
                - self.cfg.jito.tip_lamports as i64
                - BASE_TX_FEE_LAMPORTS as i64;
            self.pnl.record_trade(net_pnl);
            self.breaker.record_success();
            info!(
                "[0-RPC PUMPSWAP SATIŞ & KİRA İADESİ ONAYI] Mint={} | Net PnL={:+.6} SOL",
                mint,
                net_pnl as f64 / 1_000_000_000.0
            );
        }
    }

    async fn on_confirmed_pumpswap_trade(
        self: &Arc<Self>,
        signature: String,
        trade: ParsedPumpSwapTrade,
        hints: Option<PumpSwapTxHints>,
    ) {
        if let Some(h) = hints {
            self.ps_hint_cache.insert(trade.pool, h);
        }

        if trade.user == self.wallet_pubkey {
            self.on_own_pumpswap_trade(&trade, hints);
            return;
        }

        let effective_hints =
            hints.or_else(|| self.ps_hint_cache.get(&trade.pool).map(|r| *r.value()));

        let Some(h) = effective_hints else {
            return;
        };
        if h.quote_mint != wsol_mint_id() {
            return;
        }

        let live_meta = trade.to_pool_meta(&h);
        let mint = live_meta.base_mint;
        self.pumpswap_cache
            .insert(trade.pool, (live_meta.clone(), Instant::now()));

        // Açık PumpSwap pozisyonu varsa: Balina satış kalkanı + 0-RPC TP/SL değerlendirmesi!
        if self.positions.contains_key(&mint) {
            let mut whale_dumped = false;
            if !trade.is_buy && self.cfg.whale.instant_exit_on_whale_sell {
                if let Some(mut pos_ref) = self.positions.get_mut(&mint) {
                    if !pos_ref.exit_in_flight && pos_ref.trigger_whale == Some(trade.user) {
                        pos_ref.exit_in_flight = true;
                        whale_dumped = true;
                    }
                }
            }
            if whale_dumped {
                let eng = self.clone();
                let sol_dump = trade.sol_amount as f64 / 1_000_000_000.0;
                tokio::spawn(async move {
                    let reason = format!(
                        "Takip edilen PumpSwap Balinası ({:.2} SOL) satış yaptı — Anında Atomik Çıkış",
                        sol_dump
                    );
                    if let Err(e) = eng
                        .execute_pumpswap_exit(mint, &live_meta, &reason, false)
                        .await
                    {
                        debug!("PumpSwap koruma çıkışı yeniden denenecek: {}", e);
                        if let Some(mut p) = eng.positions.get_mut(&mint) {
                            p.exit_in_flight = false;
                        }
                    }
                });
                return;
            }

            let eng = self.clone();
            tokio::spawn(async move {
                eng.evaluate_pumpswap_position(mint, live_meta).await;
            });
            return;
        }

        // Giriş filtresi: `$10,000 <= pre_buy_mcap_usd <= $50,000` VE `sol_amount >= 5.0 SOL`!
        if !self.cfg.mode.strategy.runs_momentum()
            || !self.cfg.whale.enabled
            || !self.cfg.whale.trade_pumpswap_amm
            || !trade.is_buy
        {
            return;
        }

        if self.cfg.whale.ignore_mayhem_bot_as_whale && self.is_mayhem_agent(&trade.user) {
            return;
        }

        if trade.sol_amount < self.cfg.whale.min_buy_lamports() {
            return;
        }

        let pre_buy_mcap = trade.pre_trade_mcap_lamports();
        if !self.oracle.is_mcap_in_usd_window(
            pre_buy_mcap,
            self.cfg.whale.min_mcap_usd,
            self.cfg.whale.max_mcap_usd,
        ) {
            return;
        }

        if !self.cooldowns.check_and_mark_signature(&signature) {
            return;
        }
        if let Err(reason) = self.check_entry_guards(&mint) {
            debug!("PumpSwap giriş risk filtresi ({}): {}", mint, reason);
            return;
        }

        self.counters
            .whale_10k_50k_signals
            .fetch_add(1, Ordering::Relaxed);

        let eng = self.clone();
        let whale_pk = trade.user;
        let whale_sol = trade.sol_amount;
        tokio::spawn(async move {
            if let Err(e) = eng
                .execute_pumpswap_momentum_entry(
                    signature,
                    live_meta,
                    pre_buy_mcap,
                    whale_pk,
                    whale_sol,
                )
                .await
            {
                debug!("PumpSwap atomik giriş elendi (0 SOL kayıp): {}", e);
            }
        });
    }

    async fn execute_pumpswap_momentum_entry(
        self: &Arc<Self>,
        trigger_sig: String,
        meta: PumpSwapPoolMeta,
        pre_buy_mcap_lamports: u64,
        whale_wallet: Pubkey,
        whale_sol_lamports: u64,
    ) -> Result<()> {
        let t0 = Instant::now();
        let spendable_sol = (self.cfg.strategy.position_sol * 1_000_000_000.0) as u64;
        let (expected_tokens, impact_pct) = meta
            .quote_buy_exact_sol_in(spendable_sol)
            .context("PumpSwap alım kotasyonu üretilemedi")?;

        if impact_pct > self.cfg.risk.max_price_impact_pct {
            bail!(
                "PumpSwap fiyat etkisi yüksek ({:.2}% > {:.2}%)",
                impact_pct,
                self.cfg.risk.max_price_impact_pct
            );
        }

        let min_tokens_out = ((expected_tokens as u128
            * (10_000u128.saturating_sub(self.cfg.strategy.buy_slippage_bps as u128)))
            / 10_000u128) as u64;

        let mut ixs = build_pumpswap_atomic_buy_ixs(
            &self.wallet_pubkey,
            &meta,
            spendable_sol,
            min_tokens_out.max(1),
        );
        ixs.push(
            self.jito
                .build_tip_ix_with_dontfront(&self.wallet_pubkey, self.cfg.jito.tip_lamports),
        );

        let recent_bh = self.blockhash_cache.get().await?;
        let buy_tx = JitoClient::compile_v0_tx(
            &self.wallet,
            self.cfg.strategy.compute_unit_limit,
            self.cfg.strategy.compute_unit_price_micro_lamports,
            ixs,
            recent_bh,
        )?;

        let build_us = t0.elapsed().as_micros();
        if self.cfg.risk.simulate_before_submit {
            self.simulate_checked(&buy_tx, "PumpSwap Atomik Alım")
                .await?;
        }

        let pre_usd = self.oracle.lamports_to_usd(pre_buy_mcap_lamports);
        let post_usd = self.oracle.lamports_to_usd(meta.market_cap_lamports());

        info!(
            "[PUMPSWAP AMM BALİNA GİRİŞ] Mint={} | Balina={:.2} SOL | AlımAnıMCAP=${:.0} -> ŞuAn=${:.0} | BizimAlım={:.4} SOL | Derleme={} µs ({})",
            meta.base_mint,
            whale_sol_lamports as f64 / 1_000_000_000.0,
            pre_usd,
            post_usd,
            spendable_sol as f64 / 1_000_000_000.0,
            build_us,
            &trigger_sig[..trigger_sig.len().min(10)]
        );

        let user_base_ata = derive_ata(
            &self.wallet_pubkey,
            &meta.base_mint,
            &meta.base_token_program,
        );
        let landed = self.dispatch_atomic_tx(&buy_tx, user_base_ata, None).await;
        if !landed {
            bail!("PumpSwap atomik alım yerleşmedi (0 SOL kayıp)");
        }

        self.breaker.record_success();
        let mint = meta.base_mint;
        let tp = meta.base_token_program;
        self.confirm_and_register_position(
            mint,
            tp,
            PositionVenue::PumpSwapAmm {
                meta,
                user_base_ata,
            },
            Some(whale_wallet),
            false,
            expected_tokens,
            spendable_sol,
        )
        .await
    }

    // ========================================================================
    // SHREDSTREAM 0-RPC ERKEN GİRİŞ (`$10k–$50k` USD MCAP + `>= 5 SOL` BALİNA)
    // ========================================================================

    async fn on_shred_fast_buy(
        self: &Arc<Self>,
        slot: u64,
        signature: String,
        victim_tx: VersionedTransaction,
        parsed: ParsedVictimBuy,
    ) -> Result<()> {
        if parsed.buyer == self.wallet_pubkey {
            return Ok(());
        }
        let from_mayhem_bot =
            parsed.is_mayhem_program_cpi || self.is_mayhem_agent(&parsed.buyer);

        let est_sol = match parsed.order {
            VictimBuyOrder::ExactSolIn {
                spendable_sol_in, ..
            } => spendable_sol_in,
            VictimBuyOrder::ExactTokensOut { max_sol_cost, .. } => max_sol_cost,
            VictimBuyOrder::MayhemProgramDynamicBuy { .. } => 0,
        };

        let Some(cached_curve) = self.curve_cache.get(&parsed.mint).map(|e| e.value().0.clone())
        else {
            return Ok(());
        };
        if cached_curve.complete {
            return Ok(());
        }

        let mut matched_whale = false;
        if self.cfg.whale.enabled
            && self.cfg.whale.trade_pump_bonding_curve
            && !(self.cfg.whale.ignore_mayhem_bot_as_whale && from_mayhem_bot)
            && est_sol >= self.cfg.whale.min_buy_lamports()
            && self.oracle.is_mcap_in_usd_window(
                cached_curve.market_cap_lamports(false),
                self.cfg.whale.min_mcap_usd,
                self.cfg.whale.max_mcap_usd,
            )
        {
            matched_whale = true;
            self.counters
                .whale_10k_50k_signals
                .fetch_add(1, Ordering::Relaxed);
        } else if from_mayhem_bot
            && self.cfg.mayhem.enabled
            && self.cfg.mayhem.entry_mode.triggers_on_confirmed_buy()
            && self
                .cfg
                .mayhem
                .is_mcap_in_window(cached_curve.market_cap_lamports(self.cfg.mayhem.use_2b_supply_for_mcap))
        {
            self.counters
                .mayhem_bot_buys
                .fetch_add(1, Ordering::Relaxed);
        } else {
            return Ok(());
        }

        if !self.cooldowns.check_and_mark_signature(&signature) {
            return Ok(());
        }
        self.check_entry_guards(&parsed.mint)?;

        let t0 = Instant::now();
        let spendable_sol = (self.cfg.strategy.position_sol * 1_000_000_000.0) as u64;
        let q = quote_buy_exact_sol_in(
            &cached_curve,
            spendable_sol,
            self.global_cfg.fee_basis_points,
            cached_curve.effective_creator_fee_bps(self.global_cfg.creator_fee_basis_points),
        )
        .context("Shred Pump kotasyonu alınamadı")?;

        let min_tokens_out = ((q.tokens_out as u128
            * (10_000u128.saturating_sub(self.cfg.strategy.buy_slippage_bps as u128)))
            / 10_000u128) as u64;

        let pdas = self.get_or_derive_pdas(
            &parsed.mint,
            Some(parsed.bonding_curve),
            &parsed.token_program,
        );
        let checked_fee_rec = self.global_cfg.effective_fee_recipient_checked(
            cached_curve.is_mayhem_mode,
            Some(parsed.fee_recipient),
        );
        let checked_bb = self
            .global_cfg
            .effective_buyback_recipient(parsed.buyback_fee_recipient);

        let create_ata_ix = create_ata_idempotent_with_ata_ix(
            &self.wallet_pubkey,
            &self.wallet_pubkey,
            &pdas.user_ata,
            &parsed.mint,
            &parsed.token_program,
        );
        let buy_ix = build_buy_exact_sol_in_fast_ix(
            &self.wallet_pubkey,
            &self.wallet_user_vol_pda,
            &parsed.mint,
            &pdas,
            &checked_fee_rec,
            &parsed.creator_vault,
            &parsed.token_program,
            checked_bb.as_ref(),
            spendable_sol,
            min_tokens_out.max(1),
            false,
        );
        let tip_ix = self
            .jito
            .build_tip_ix_with_dontfront(&self.wallet_pubkey, self.cfg.jito.tip_lamports);

        let recent_bh = self.blockhash_cache.get().await?;
        let front_tx = JitoClient::compile_v0_tx(
            &self.wallet,
            self.cfg.strategy.compute_unit_limit,
            self.cfg.strategy.compute_unit_price_micro_lamports,
            vec![create_ata_ix.clone(), buy_ix.clone(), tip_ix],
            recent_bh,
        )?;

        info!(
            "[SHRED 2-TX FRONT-RUN] Slot={} | Mint={} | Balina={:.2} SOL | MCAP=${:.0} | Index0=BizimAlım -> Index1=Balina | Derleme={} µs",
            slot,
            parsed.mint,
            est_sol as f64 / 1_000_000_000.0,
            self.oracle.lamports_to_usd(cached_curve.market_cap_lamports(false)),
            t0.elapsed().as_micros()
        );

        // 2-Tx Jito Atomik Front-Run Bundle: [Tx0: Bizim Alım, Tx1: Balinanın >=5 SOL Alımı]
        let bundle_id = self.jito.send_bundle(&[front_tx, victim_tx]).await?;
        if let JitoBundleState::Landed { slot: landed_slot } = self
            .jito
            .wait_for_bundle(&bundle_id, Duration::from_millis(3500))
            .await?
        {
            self.breaker.record_success();
            self.confirm_and_register_position(
                parsed.mint,
                parsed.token_program,
                PositionVenue::PumpBondingCurve {
                    pdas,
                    creator_vault: parsed.creator_vault,
                    buyback_fee_recipient: checked_bb,
                    is_mayhem_mode: cached_curve.is_mayhem_mode,
                    is_cashback_coin: cached_curve.is_cashback_coin,
                },
                if matched_whale {
                    Some(parsed.buyer)
                } else {
                    None
                },
                false,
                q.tokens_out,
                spendable_sol,
            )
            .await?;
            info!(
                "[SHRED FRONT-RUN LANDI] Slot={} | Mint={} | 2-Tx bundle mevcut bloğa yerleşti!",
                landed_slot,
                parsed.mint
            );
        }
        Ok(())
    }

    async fn on_shred_pumpswap_buy(
        self: &Arc<Self>,
        slot: u64,
        signature: String,
        victim_tx: VersionedTransaction,
        parsed: ParsedPumpSwapWhaleBuy,
    ) -> Result<()> {
        if !self.cfg.whale.enabled
            || !self.cfg.whale.trade_pumpswap_amm
            || parsed.buyer == self.wallet_pubkey
        {
            return Ok(());
        }
        if self.cfg.whale.ignore_mayhem_bot_as_whale && self.is_mayhem_agent(&parsed.buyer) {
            return Ok(());
        }
        if parsed.estimated_sol_in < self.cfg.whale.min_buy_lamports() {
            return Ok(());
        }

        let Some(cached_meta) = self
            .pumpswap_cache
            .get(&parsed.hints.pool)
            .map(|e| e.value().0.clone())
        else {
            return Ok(());
        };

        let mcap_lamports = cached_meta.market_cap_lamports();
        if !self.oracle.is_mcap_in_usd_window(
            mcap_lamports,
            self.cfg.whale.min_mcap_usd,
            self.cfg.whale.max_mcap_usd,
        ) {
            return Ok(());
        }

        if !self.cooldowns.check_and_mark_signature(&signature) {
            return Ok(());
        }
        self.check_entry_guards(&cached_meta.base_mint)?;

        self.counters
            .whale_10k_50k_signals
            .fetch_add(1, Ordering::Relaxed);

        let t0 = Instant::now();
        let spendable_sol = (self.cfg.strategy.position_sol * 1_000_000_000.0) as u64;
        let (expected_tokens, impact_pct) = cached_meta
            .quote_buy_exact_sol_in(spendable_sol)
            .context("PumpSwap alım kotasyonu üretilemedi")?;

        if impact_pct > self.cfg.risk.max_price_impact_pct {
            bail!(
                "PumpSwap fiyat etkisi yüksek ({:.2}% > {:.2}%)",
                impact_pct,
                self.cfg.risk.max_price_impact_pct
            );
        }

        let min_tokens_out = ((expected_tokens as u128
            * (10_000u128.saturating_sub(self.cfg.strategy.buy_slippage_bps as u128)))
            / 10_000u128) as u64;

        let mut ixs = build_pumpswap_atomic_buy_ixs(
            &self.wallet_pubkey,
            &cached_meta,
            spendable_sol,
            min_tokens_out.max(1),
        );
        ixs.push(
            self.jito
                .build_tip_ix_with_dontfront(&self.wallet_pubkey, self.cfg.jito.tip_lamports),
        );

        let recent_bh = self.blockhash_cache.get().await?;
        let front_tx = JitoClient::compile_v0_tx(
            &self.wallet,
            self.cfg.strategy.compute_unit_limit,
            self.cfg.strategy.compute_unit_price_micro_lamports,
            ixs,
            recent_bh,
        )?;

        info!(
            "[SHRED 2-TX PUMPSWAP FRONT-RUN] Slot={} | Mint={} | Balina={:.2} SOL | MCAP=${:.0} | Index0=BizimAlım -> Index1=Balina | Derleme={} µs",
            slot,
            cached_meta.base_mint,
            parsed.estimated_sol_in as f64 / 1_000_000_000.0,
            self.oracle.lamports_to_usd(mcap_lamports),
            t0.elapsed().as_micros()
        );

        let user_base_ata = derive_ata(
            &self.wallet_pubkey,
            &cached_meta.base_mint,
            &cached_meta.base_token_program,
        );

        let bundle_id = self.jito.send_bundle(&[front_tx, victim_tx]).await?;
        if let JitoBundleState::Landed { slot: landed_slot } = self
            .jito
            .wait_for_bundle(&bundle_id, Duration::from_millis(3500))
            .await?
        {
            self.breaker.record_success();
            self.confirm_and_register_position(
                cached_meta.base_mint,
                cached_meta.base_token_program,
                PositionVenue::PumpSwapAmm {
                    meta: cached_meta.clone(),
                    user_base_ata,
                },
                Some(parsed.buyer),
                false,
                expected_tokens,
                spendable_sol,
            )
            .await?;
            info!(
                "[SHRED PUMPSWAP FRONT-RUN LANDI] Slot={} | Mint={} | 2-Tx bundle mevcut bloğa yerleşti!",
                landed_slot,
                cached_meta.base_mint
            );
        }
        Ok(())
    }

    // ========================================================================
    // PRE-EXECUTION (`raw_tx_ws`) FRONT-RUN & 3-TX SANDWICH (`>= 5 SOL` BALİNA!)
    // ========================================================================

    async fn on_pre_execution_victim(
        self: &Arc<Self>,
        victim_sig: String,
        victim_tx: VersionedTransaction,
        parsed: ParsedVictimBuy,
    ) -> Result<()> {
        if parsed.buyer == self.wallet_pubkey {
            return Ok(());
        }
        if tx_has_jitodontfront(&victim_tx) {
            if self.cfg.mode.strategy.runs_momentum() {
                return self
                    .on_shred_fast_buy(0, victim_sig, victim_tx.clone(), parsed)
                    .await;
            }
            return Ok(());
        }

        let from_mayhem_bot =
            parsed.is_mayhem_program_cpi || self.is_mayhem_agent(&parsed.buyer);

        let (token_program, curve) = if let Some(cached) = self.curve_cache.get(&parsed.mint) {
            if cached.value().1.elapsed() < Duration::from_secs(2) {
                (parsed.token_program, cached.value().0.clone())
            } else {
                let m = self.resolve_mint_and_curve(&parsed.mint).await?;
                (m.token_program, m.curve)
            }
        } else {
            let m = self.resolve_mint_and_curve(&parsed.mint).await?;
            (m.token_program, m.curve)
        };

        if curve.complete {
            bail!("Eğri mezun olmuş");
        }

        let creator_bps = curve.effective_creator_fee_bps(self.global_cfg.creator_fee_basis_points);
        let est_sol = parsed
            .order
            .estimated_sol_lamports(&curve, self.global_cfg.fee_basis_points, creator_bps)
            .unwrap_or(0);

        let mcap_lamports = curve.market_cap_lamports(false);
        let is_valid_whale = self.cfg.whale.enabled
            && self.cfg.whale.trade_pump_bonding_curve
            && !(self.cfg.whale.ignore_mayhem_bot_as_whale && from_mayhem_bot)
            && est_sol >= self.cfg.whale.min_buy_lamports()
            && self.oracle.is_mcap_in_usd_window(
                mcap_lamports,
                self.cfg.whale.min_mcap_usd,
                self.cfg.whale.max_mcap_usd,
            );

        let is_valid_mayhem = from_mayhem_bot
            && self.cfg.mayhem.enabled
            && self
                .cfg
                .mayhem
                .is_mcap_in_window(curve.market_cap_lamports(self.cfg.mayhem.use_2b_supply_for_mcap));

        if !is_valid_whale && !is_valid_mayhem {
            return Ok(());
        }

        if !self.cooldowns.check_and_mark_signature(&victim_sig) {
            return Ok(());
        }
        self.check_entry_guards(&parsed.mint)?;

        if is_valid_whale {
            self.counters
                .whale_10k_50k_signals
                .fetch_add(1, Ordering::Relaxed);
        }

        // Eğer 3-Tx Sandwich modundaysak ve balina emri deterministik ise önce kâr kilitli 3-Tx Sandwich dene!
        if self.cfg.mode.strategy.runs_sandwich() && !parsed.is_mayhem_program_cpi {
            let max_front_lamports = (self.cfg.strategy.max_position_sol * 1_000_000_000.0) as u64;
            if let Some(plan) = optimize_sandwich(
                &curve,
                &parsed.order,
                max_front_lamports,
                self.cfg.risk.max_price_impact_pct,
                self.global_cfg.fee_basis_points,
                creator_bps,
                from_mayhem_bot,
                self.cfg.jito.tip_lamports,
                15_000,
            ) {
                let dynamic_tip = ((plan.gross_profit_lamports.max(0) as u128
                    * self.cfg.jito.dynamic_tip_profit_share_bps as u128)
                    / 10_000u128) as u64;
                let dynamic_tip =
                    dynamic_tip.clamp(self.cfg.jito.tip_lamports, self.cfg.jito.max_tip_lamports);
                let exact_tokens = plan.front_run_tokens_out;
                if let Some(exact_buy_quote) = quote_buy_exact_tokens_out(
                    &curve,
                    exact_tokens,
                    self.global_cfg.fee_basis_points,
                    creator_bps,
                ) {
                    let max_front_sol_cost = exact_buy_quote.total_sol_cost;
                    let net_expected_profit = plan.back_run_net_sol_out as i64
                        - max_front_sol_cost as i64
                        - dynamic_tip as i64
                        - 15_000;
                    if net_expected_profit >= self.cfg.strategy.min_sandwich_profit_lamports as i64
                    {
                        return self
                            .execute_three_tx_pump_sandwich(
                                victim_tx,
                                &parsed,
                                token_program,
                                &curve,
                                exact_tokens,
                                max_front_sol_cost,
                                dynamic_tip,
                                net_expected_profit,
                            )
                            .await;
                    }
                }
            }
        }

        // 2-Tx Jito Atomik Front-Run (`[Tx1: Bizim Alım (Index 0), Tx2: Balinanın >=5 SOL Alımı (Index 1)]`)!
        if (is_valid_whale && self.cfg.whale.frontrun_via_jito_bundle)
            || (is_valid_mayhem && self.cfg.mayhem.frontrun_via_jito_bundle)
        {
            return self
                .execute_two_tx_pump_frontrun(
                    victim_sig,
                    victim_tx,
                    parsed,
                    token_program,
                    curve,
                    is_valid_whale,
                )
                .await;
        }

        Ok(())
    }

    #[allow(clippy::too_many_arguments)]
    async fn execute_three_tx_pump_sandwich(
        &self,
        victim_tx: VersionedTransaction,
        parsed: &ParsedVictimBuy,
        token_program: Pubkey,
        curve: &BondingCurveState,
        exact_tokens: u64,
        max_front_sol_cost: u64,
        dynamic_tip: u64,
        net_expected_profit: i64,
    ) -> Result<()> {
        let strict_min_sol_out = max_front_sol_cost
            .saturating_add(dynamic_tip)
            .saturating_add(15_000)
            .saturating_add(self.cfg.strategy.min_sandwich_profit_lamports);

        let pdas =
            self.get_or_derive_pdas(&parsed.mint, Some(parsed.bonding_curve), &token_program);
        let creator_vault = derive_creator_vault_pda(&curve.creator);
        let fee_recipient = self
            .global_cfg
            .effective_fee_recipient_checked(curve.is_mayhem_mode, Some(parsed.fee_recipient));
        let buyback_recipient = self
            .global_cfg
            .effective_buyback_recipient(parsed.buyback_fee_recipient);

        let create_ata_ix = create_ata_idempotent_with_ata_ix(
            &self.wallet_pubkey,
            &self.wallet_pubkey,
            &pdas.user_ata,
            &parsed.mint,
            &token_program,
        );
        let front_buy_ix = build_buy_exact_tokens_out_fast_ix(
            &self.wallet_pubkey,
            &self.wallet_user_vol_pda,
            &parsed.mint,
            &pdas,
            &fee_recipient,
            &creator_vault,
            &token_program,
            buyback_recipient.as_ref(),
            exact_tokens,
            max_front_sol_cost,
            false,
        );
        let back_sell_ix = build_sell_fast_ix(
            &self.wallet_pubkey,
            &self.wallet_user_vol_pda,
            &parsed.mint,
            &pdas,
            &fee_recipient,
            &creator_vault,
            &token_program,
            buyback_recipient.as_ref(),
            curve.is_cashback_coin,
            exact_tokens,
            strict_min_sol_out,
        );

        let mut back_ixs = vec![back_sell_ix];
        if self.cfg.strategy.auto_close_ata_reclaim_rent {
            back_ixs.push(build_close_token_account_ix(
                &token_program,
                &pdas.user_ata,
                &self.wallet_pubkey,
                &self.wallet_pubkey,
            ));
        }
        back_ixs.push(self.jito.build_tip_ix(&self.wallet_pubkey, dynamic_tip));

        let recent_bh = self.blockhash_cache.get().await?;
        let front_tx = JitoClient::compile_v0_tx_with_options(
            &self.wallet,
            self.cfg.strategy.compute_unit_limit,
            self.cfg.strategy.compute_unit_price_micro_lamports,
            vec![create_ata_ix, front_buy_ix],
            recent_bh,
            true,
        )?;
        let back_tx = JitoClient::compile_v0_tx(
            &self.wallet,
            self.cfg.strategy.compute_unit_limit,
            self.cfg.strategy.compute_unit_price_micro_lamports,
            back_ixs,
            recent_bh,
        )?;

        info!(
            "[3-TX ATOMİK BALİNA SANDWICH] Mint={} | MCAP=${:.0} | Front={:.4} SOL | GarantiNetKâr=+{:.6} SOL",
            parsed.mint,
            self.oracle.lamports_to_usd(curve.market_cap_lamports(false)),
            max_front_sol_cost as f64 / 1_000_000_000.0,
            net_expected_profit as f64 / 1_000_000_000.0
        );

        let bundle_id = self
            .jito
            .send_bundle(&[front_tx, victim_tx, back_tx])
            .await?;
        if let JitoBundleState::Landed { slot } = self
            .jito
            .wait_for_bundle(&bundle_id, Duration::from_secs(5))
            .await?
        {
            self.breaker.record_success();
            self.pnl.record_trade(net_expected_profit);
            info!(
                "[SANDWICH BAŞARILI & KİRA İADE EDİLDİ] Slot={} | Net Kâr={:+.6} SOL",
                slot,
                net_expected_profit as f64 / 1_000_000_000.0
            );
        }
        Ok(())
    }

    async fn execute_two_tx_pump_frontrun(
        &self,
        victim_sig: String,
        victim_tx: VersionedTransaction,
        parsed: ParsedVictimBuy,
        token_program: Pubkey,
        curve: BondingCurveState,
        is_whale: bool,
    ) -> Result<()> {
        let spendable_sol = (self.cfg.strategy.position_sol * 1_000_000_000.0) as u64;
        let creator_bps = curve.effective_creator_fee_bps(self.global_cfg.creator_fee_basis_points);
        let buy_quote = quote_buy_exact_sol_in(
            &curve,
            spendable_sol,
            self.global_cfg.fee_basis_points,
            creator_bps,
        )
        .context("2-Tx Front-Run kotasyonu üretilemedi")?;

        let min_tokens_out = ((buy_quote.tokens_out as u128
            * (10_000u128.saturating_sub(self.cfg.strategy.buy_slippage_bps as u128)))
            / 10_000u128) as u64;

        let pdas =
            self.get_or_derive_pdas(&parsed.mint, Some(parsed.bonding_curve), &token_program);
        let creator_vault = derive_creator_vault_pda(&curve.creator);
        let fee_recipient = self
            .global_cfg
            .effective_fee_recipient_checked(curve.is_mayhem_mode, Some(parsed.fee_recipient));
        let buyback_recipient = self
            .global_cfg
            .effective_buyback_recipient(parsed.buyback_fee_recipient);

        let create_ata_ix = create_ata_idempotent_with_ata_ix(
            &self.wallet_pubkey,
            &self.wallet_pubkey,
            &pdas.user_ata,
            &parsed.mint,
            &token_program,
        );
        let front_buy_ix = build_buy_exact_sol_in_fast_ix(
            &self.wallet_pubkey,
            &self.wallet_user_vol_pda,
            &parsed.mint,
            &pdas,
            &fee_recipient,
            &creator_vault,
            &token_program,
            buyback_recipient.as_ref(),
            spendable_sol,
            min_tokens_out.max(1),
            false,
        );
        let tip_ix = self
            .jito
            .build_tip_ix_with_dontfront(&self.wallet_pubkey, self.cfg.jito.tip_lamports);

        let recent_bh = self.blockhash_cache.get().await?;
        let front_tx = JitoClient::compile_v0_tx(
            &self.wallet,
            self.cfg.strategy.compute_unit_limit,
            self.cfg.strategy.compute_unit_price_micro_lamports,
            vec![create_ata_ix, front_buy_ix, tip_ix],
            recent_bh,
        )?;

        info!(
            "[2-TX JITO ATOMİK FRONT-RUN] Mint={} | MCAP=${:.0} | Index0=BizimAlım -> Index1=Hedef({})",
            parsed.mint,
            self.oracle.lamports_to_usd(curve.market_cap_lamports(false)),
            &victim_sig[..victim_sig.len().min(10)]
        );

        let bundle_id = self.jito.send_bundle(&[front_tx, victim_tx]).await?;
        if let JitoBundleState::Landed { slot } = self
            .jito
            .wait_for_bundle(&bundle_id, Duration::from_millis(3500))
            .await?
        {
            info!("[HEDEFİN ÖNÜNE GEÇİLDİ!] Slot={} içinde 2-Tx Front-Run onaylandı!", slot);
            self.breaker.record_success();
            self.confirm_and_register_position(
                parsed.mint,
                token_program,
                PositionVenue::PumpBondingCurve {
                    pdas,
                    creator_vault,
                    buyback_fee_recipient: buyback_recipient,
                    is_mayhem_mode: curve.is_mayhem_mode,
                    is_cashback_coin: curve.is_cashback_coin,
                },
                if is_whale { Some(parsed.buyer) } else { None },
                false,
                buy_quote.tokens_out,
                spendable_sol,
            )
            .await?;
        }
        Ok(())
    }

    async fn on_pre_execution_pumpswap_buy(
        self: &Arc<Self>,
        victim_sig: String,
        victim_tx: VersionedTransaction,
        parsed: ParsedPumpSwapWhaleBuy,
    ) -> Result<()> {
        if !self.cfg.whale.enabled
            || !self.cfg.whale.trade_pumpswap_amm
            || !self.cfg.whale.frontrun_via_jito_bundle
            || parsed.buyer == self.wallet_pubkey
        {
            return Ok(());
        }
        if tx_has_jitodontfront(&victim_tx) {
            if self.cfg.mode.strategy.runs_momentum() {
                return self
                    .on_shred_pumpswap_buy(0, victim_sig, victim_tx.clone(), parsed)
                    .await;
            }
            return Ok(());
        }
        if parsed.estimated_sol_in < self.cfg.whale.min_buy_lamports() {
            return Ok(());
        }

        let meta = if let Some(cached) = self.pumpswap_cache.get(&parsed.hints.pool) {
            cached.value().0.clone()
        } else {
            self.resolve_pumpswap_pool(&parsed.hints).await?
        };

        let mcap = meta.market_cap_lamports();
        if !self.oracle.is_mcap_in_usd_window(
            mcap,
            self.cfg.whale.min_mcap_usd,
            self.cfg.whale.max_mcap_usd,
        ) {
            return Ok(());
        }

        if !self.cooldowns.check_and_mark_signature(&victim_sig) {
            return Ok(());
        }
        self.check_entry_guards(&meta.base_mint)?;

        let spendable_sol = (self.cfg.strategy.position_sol * 1_000_000_000.0) as u64;
        let (expected_tokens, _) = meta
            .quote_buy_exact_sol_in(spendable_sol)
            .context("PumpSwap 2-Tx Front-Run kotasyonu alınamadı")?;
        let min_tokens_out = ((expected_tokens as u128
            * (10_000u128.saturating_sub(self.cfg.strategy.buy_slippage_bps as u128)))
            / 10_000u128) as u64;

        let mut ixs = build_pumpswap_atomic_buy_ixs(
            &self.wallet_pubkey,
            &meta,
            spendable_sol,
            min_tokens_out.max(1),
        );
        ixs.push(
            self.jito
                .build_tip_ix_with_dontfront(&self.wallet_pubkey, self.cfg.jito.tip_lamports),
        );

        let recent_bh = self.blockhash_cache.get().await?;
        let front_tx = JitoClient::compile_v0_tx(
            &self.wallet,
            self.cfg.strategy.compute_unit_limit,
            self.cfg.strategy.compute_unit_price_micro_lamports,
            ixs,
            recent_bh,
        )?;

        info!(
            "[2-TX PUMPSWAP BALİNA FRONT-RUN] Mint={} | MCAP=${:.0} | Balina={:.2} SOL | Index0=BizimAlım -> Index1=Balina",
            meta.base_mint,
            self.oracle.lamports_to_usd(mcap),
            parsed.estimated_sol_in as f64 / 1_000_000_000.0
        );

        let bundle_id = self.jito.send_bundle(&[front_tx, victim_tx]).await?;
        if let JitoBundleState::Landed { slot } = self
            .jito
            .wait_for_bundle(&bundle_id, Duration::from_millis(3500))
            .await?
        {
            info!("[PUMPSWAP BALİNANIN ÖNÜNE GEÇİLDİ!] Slot={}", slot);
            let user_base_ata = derive_ata(
                &self.wallet_pubkey,
                &meta.base_mint,
                &meta.base_token_program,
            );
            let mint = meta.base_mint;
            let tp = meta.base_token_program;
            self.breaker.record_success();
            self.confirm_and_register_position(
                mint,
                tp,
                PositionVenue::PumpSwapAmm {
                    meta,
                    user_base_ata,
                },
                Some(parsed.buyer),
                false,
                expected_tokens,
                spendable_sol,
            )
            .await?;
        }
        Ok(())
    }

    // ========================================================================
    // ORTAK ATOMİK GÖNDERİM, POZİSYON KAYDI VE ÇIKIŞ YÖNETİCİSİ
    // ========================================================================

    async fn dispatch_atomic_tx(
        &self,
        jito_tx: &VersionedTransaction,
        target_user_ata: Pubkey,
        relay_parts: Option<(
            &solana_instruction::Instruction,
            &solana_instruction::Instruction,
            solana_hash::Hash,
        )>,
    ) -> bool {
        let jito_fut = self.jito.send_single_atomic_tx(jito_tx);
        let rpc_fut = async {
            if self.cfg.network.dual_send_momentum {
                Some(self.rpc.send_transaction_fast(jito_tx).await)
            } else {
                None
            }
        };
        let relay_fut = async {
            if let Some((c_ix, b_ix, r_bh)) = relay_parts {
                if self.jito.has_allenhark_relay() {
                    let r_tip = self
                        .jito
                        .build_allenhark_relay_tip_ix(&self.wallet_pubkey, self.cfg.jito.tip_lamports);
                    if let Ok(r_tx) = JitoClient::compile_v0_tx(
                        &self.wallet,
                        self.cfg.strategy.compute_unit_limit,
                        self.cfg.strategy.compute_unit_price_micro_lamports,
                        vec![c_ix.clone(), b_ix.clone(), r_tip],
                        r_bh,
                    ) {
                        return Some(self.jito.send_via_allenhark_relay(&r_tx).await);
                    }
                }
            }
            None
        };

        let (atomic_res, rpc_res, _) = tokio::join!(jito_fut, rpc_fut, relay_fut);

        if let Ok(receipt) = atomic_res {
            if let Some(bundle_id) = receipt.bundle_id {
                if let Ok(JitoBundleState::Landed { slot }) = self
                    .jito
                    .wait_for_bundle(&bundle_id, Duration::from_millis(3500))
                    .await
                {
                    info!("Jito Atomik Bundle ONAYLANDI (Slot: {})", slot);
                    return true;
                }
            }
        }

        if let Some(sig) = jito_tx.signatures.first() {
            for _ in 0..5 {
                if let Ok(bal) = self.rpc.get_token_account_balance(&target_user_ata).await {
                    if bal > 0 {
                        return true;
                    }
                }
                if let Ok(true) = self.rpc.is_signature_confirmed(sig).await {
                    return true;
                }
                tokio::time::sleep(Duration::from_millis(220)).await;
            }
        }
        if let Some(Ok(sig)) = rpc_res {
            if self.rpc.is_signature_confirmed(&sig).await.unwrap_or(false) {
                return true;
            }
        }
        false
    }

    async fn confirm_and_register_position(
        &self,
        mint: Pubkey,
        token_program: Pubkey,
        venue: PositionVenue,
        trigger_whale: Option<Pubkey>,
        awaiting_mayhem_buy_pump: bool,
        fallback_tokens: u64,
        spendable_sol: u64,
    ) -> Result<()> {
        if let Some(existing) = self.positions.get(&mint) {
            if existing.exact_fill_confirmed {
                return Ok(());
            }
        }

        let ata = match &venue {
            PositionVenue::PumpBondingCurve { pdas, .. } => pdas.user_ata,
            PositionVenue::PumpSwapAmm { user_base_ata, .. } => *user_base_ata,
        };

        let mut actual_tokens = 0u64;
        for _ in 0..6 {
            if let Some(existing) = self.positions.get(&mint) {
                if existing.exact_fill_confirmed {
                    return Ok(());
                }
            }
            if let Ok(bal) = self.rpc.get_token_account_balance(&ata).await {
                if bal > 0 {
                    actual_tokens = bal;
                    break;
                }
            }
            tokio::time::sleep(Duration::from_millis(200)).await;
        }
        if actual_tokens == 0 {
            actual_tokens = fallback_tokens;
        }

        let entry_total_cost = spendable_sol
            .saturating_add(self.cfg.jito.tip_lamports)
            .saturating_add(BASE_TX_FEE_LAMPORTS);

        let venue_label = match &venue {
            PositionVenue::PumpBondingCurve { .. } => "PumpCurve",
            PositionVenue::PumpSwapAmm { .. } => "PumpSwapAMM",
        };

        self.positions.insert(
            mint,
            ActivePosition {
                mint,
                token_program,
                venue,
                trigger_whale,
                awaiting_mayhem_buy_pump,
                token_amount: actual_tokens,
                exact_fill_confirmed: true,
                entry_cost_lamports: entry_total_cost,
                peak_net_sol_lamports: spendable_sol,
                opened_at: Instant::now(),
                exit_in_flight: false,
            },
        );

        info!(
            "[POZİSYON AÇIK — {}] Mint={} | Token={} | BaşaBaşMaliyet={:.6} SOL",
            venue_label,
            mint,
            actual_tokens,
            entry_total_cost as f64 / 1_000_000_000.0
        );
        Ok(())
    }

    async fn position_supervisor_loop(self: Arc<Self>) {
        let mut ticker = tokio::time::interval(Duration::from_millis(200));
        ticker.tick().await;

        loop {
            ticker.tick().await;
            if self.positions.is_empty() {
                continue;
            }

            let snapshots: Vec<ActivePosition> = self
                .positions
                .iter()
                .filter(|r| !r.value().exit_in_flight)
                .map(|r| r.value().clone())
                .collect();

            for pos in snapshots {
                match &pos.venue {
                    PositionVenue::PumpBondingCurve { pdas, .. } => {
                        let curve_opt = self.curve_cache.get(&pos.mint).and_then(|c| {
                            if c.value().1.elapsed() < Duration::from_millis(300) {
                                Some(c.value().0.clone())
                            } else {
                                None
                            }
                        });
                        let curve = match curve_opt {
                            Some(c) => c,
                            None => match self.rpc.get_account_info(&pdas.bonding_curve).await {
                                Ok(Some(acc)) => match BondingCurveState::from_account_data(
                                    pos.mint,
                                    pdas.bonding_curve,
                                    &acc.data,
                                ) {
                                    Ok(c) => {
                                        self.curve_cache.insert(pos.mint, (c.clone(), Instant::now()));
                                        c
                                    }
                                    Err(_) => continue,
                                },
                                _ => continue,
                            },
                        };
                        self.evaluate_pump_position(pos.mint, curve).await;
                    }
                    PositionVenue::PumpSwapAmm { meta, .. } => {
                        let fresh_meta = if let Some(c) = self.pumpswap_cache.get(&meta.pool) {
                            if c.value().1.elapsed() < Duration::from_millis(300) {
                                c.value().0.clone()
                            } else {
                                self.refresh_pumpswap_reserves(meta).await.unwrap_or_else(|_| meta.clone())
                            }
                        } else {
                            self.refresh_pumpswap_reserves(meta).await.unwrap_or_else(|_| meta.clone())
                        };
                        self.evaluate_pumpswap_position(pos.mint, fresh_meta).await;
                    }
                }
            }
        }
    }

    async fn evaluate_pump_position(self: &Arc<Self>, mint: Pubkey, curve: BondingCurveState) {
        let mut exit_decision: Option<(String, bool)> = None;

        if let Some(mut pos_ref) = self.positions.get_mut(&mint) {
            if pos_ref.exit_in_flight {
                return;
            }
            let creator_bps =
                curve.effective_creator_fee_bps(self.global_cfg.creator_fee_basis_points);
            let gross_sell_sol = quote_sell_tokens(
                &curve,
                pos_ref.token_amount,
                self.global_cfg.fee_basis_points,
                creator_bps,
            )
            .map(|q| q.net_sol_out)
            .unwrap_or(0);

            let realizable_net_sol = gross_sell_sol.saturating_sub(
                self.cfg
                    .jito
                    .tip_lamports
                    .saturating_add(BASE_TX_FEE_LAMPORTS),
            );
            if realizable_net_sol > pos_ref.peak_net_sol_lamports {
                pos_ref.peak_net_sol_lamports = realizable_net_sol;
            }

            exit_decision = self.check_tp_sl_rules(
                &pos_ref,
                realizable_net_sol,
                curve.complete,
            );
            if exit_decision.is_some() {
                pos_ref.exit_in_flight = true;
            }
        }

        if let Some((reason, is_profit_exit)) = exit_decision {
            let eng = self.clone();
            tokio::spawn(async move {
                if let Err(e) = eng
                    .execute_pump_exit(mint, &curve, &reason, is_profit_exit)
                    .await
                {
                    debug!("Pump çıkış yeniden denenecek ({}): {}", mint, e);
                    if let Some(mut p) = eng.positions.get_mut(&mint) {
                        p.exit_in_flight = false;
                    }
                }
            });
        }
    }

    async fn evaluate_pumpswap_position(self: &Arc<Self>, mint: Pubkey, meta: PumpSwapPoolMeta) {
        let mut exit_decision: Option<(String, bool)> = None;

        if let Some(mut pos_ref) = self.positions.get_mut(&mint) {
            if pos_ref.exit_in_flight {
                return;
            }
            let gross_sell_sol = meta.quote_sell_tokens(pos_ref.token_amount).unwrap_or(0);
            let realizable_net_sol = gross_sell_sol.saturating_sub(
                self.cfg
                    .jito
                    .tip_lamports
                    .saturating_add(BASE_TX_FEE_LAMPORTS),
            );
            if realizable_net_sol > pos_ref.peak_net_sol_lamports {
                pos_ref.peak_net_sol_lamports = realizable_net_sol;
            }
            pos_ref.venue = PositionVenue::PumpSwapAmm {
                user_base_ata: pos_ref.user_ata(),
                meta: meta.clone(),
            };

            exit_decision = self.check_tp_sl_rules(&pos_ref, realizable_net_sol, false);
            if exit_decision.is_some() {
                pos_ref.exit_in_flight = true;
            }
        }

        if let Some((reason, is_profit_exit)) = exit_decision {
            let eng = self.clone();
            tokio::spawn(async move {
                if let Err(e) = eng
                    .execute_pumpswap_exit(mint, &meta, &reason, is_profit_exit)
                    .await
                {
                    debug!("PumpSwap çıkış yeniden denenecek ({}): {}", mint, e);
                    if let Some(mut p) = eng.positions.get_mut(&mint) {
                        p.exit_in_flight = false;
                    }
                }
            });
        }
    }

    fn check_tp_sl_rules(
        &self,
        pos: &ActivePosition,
        realizable_net_sol: u64,
        curve_graduated: bool,
    ) -> Option<(String, bool)> {
        let entry = pos.entry_cost_lamports.max(1);
        let true_net_pnl_bps =
            ((realizable_net_sol as i128 - entry as i128) * 10_000i128) / (entry as i128);
        let drawdown_from_peak_bps = if pos.peak_net_sol_lamports > 0 {
            ((pos.peak_net_sol_lamports.saturating_sub(realizable_net_sol)) as u128 * 10_000u128)
                / (pos.peak_net_sol_lamports as u128)
        } else {
            0
        };

        if curve_graduated {
            Some(("Bonding curve mezun oldu".into(), false))
        } else if realizable_net_sol > entry
            && true_net_pnl_bps >= self.cfg.strategy.take_profit_bps as i128
        {
            Some((format!("Net Take-Profit (+{} bps)", true_net_pnl_bps), true))
        } else if realizable_net_sol > entry
            && drawdown_from_peak_bps >= self.cfg.strategy.trailing_stop_bps as u128
        {
            Some((
                format!(
                    "Kâr Kilitli Trailing-Stop (zirveden -{} bps, net kârda)",
                    drawdown_from_peak_bps
                ),
                true,
            ))
        } else if true_net_pnl_bps <= -(self.cfg.strategy.stop_loss_bps as i128) {
            Some((format!("Stop-Loss ({} bps)", true_net_pnl_bps), false))
        } else if pos.opened_at.elapsed().as_secs() >= self.cfg.strategy.max_hold_seconds {
            Some((
                format!("Maksimum süre ({} sn) doldu", self.cfg.strategy.max_hold_seconds),
                realizable_net_sol > entry,
            ))
        } else {
            None
        }
    }

    async fn execute_pump_exit(
        &self,
        mint: Pubkey,
        curve: &BondingCurveState,
        reason: &str,
        is_profit_exit: bool,
    ) -> Result<()> {
        let Some(pos) = self.positions.get(&mint).map(|r| r.value().clone()) else {
            return Ok(());
        };
        let PositionVenue::PumpBondingCurve {
            pdas,
            creator_vault,
            buyback_fee_recipient,
            is_mayhem_mode,
            ..
        } = pos.venue
        else {
            return Ok(());
        };

        let live_balance = if pos.exact_fill_confirmed && pos.token_amount > 0 {
            pos.token_amount
        } else {
            self.rpc
                .get_token_account_balance(&pdas.user_ata)
                .await
                .unwrap_or(pos.token_amount)
        };
        if live_balance == 0 {
            self.positions.remove(&mint);
            return Ok(());
        }

        let creator_bps = curve.effective_creator_fee_bps(self.global_cfg.creator_fee_basis_points);
        let expected_sol = quote_sell_tokens(
            curve,
            live_balance,
            self.global_cfg.fee_basis_points,
            creator_bps,
        )
        .map(|q| q.net_sol_out)
        .unwrap_or(0);

        let min_sol_output = self.compute_exit_min_sol(expected_sol, pos.entry_cost_lamports, is_profit_exit);
        let fee_recipient = self
            .global_cfg
            .effective_fee_recipient(curve.is_mayhem_mode || is_mayhem_mode);
        let bb = self
            .global_cfg
            .effective_buyback_recipient(buyback_fee_recipient);

        let sell_ix = build_sell_fast_ix(
            &self.wallet_pubkey,
            &self.wallet_user_vol_pda,
            &mint,
            &pdas,
            &fee_recipient,
            &creator_vault,
            &pos.token_program,
            bb.as_ref(),
            curve.is_cashback_coin,
            live_balance,
            min_sol_output,
        );

        let mut exit_ixs = vec![sell_ix];
        if self.cfg.strategy.auto_close_ata_reclaim_rent {
            exit_ixs.push(build_close_token_account_ix(
                &pos.token_program,
                &pdas.user_ata,
                &self.wallet_pubkey,
                &self.wallet_pubkey,
            ));
        }
        exit_ixs.push(
            self.jito
                .build_tip_ix_with_dontfront(&self.wallet_pubkey, self.cfg.jito.tip_lamports),
        );

        let recent_bh = self.blockhash_cache.get().await?;
        let sell_tx = JitoClient::compile_v0_tx(
            &self.wallet,
            self.cfg.strategy.compute_unit_limit,
            self.cfg.strategy.compute_unit_price_micro_lamports,
            exit_ixs,
            recent_bh,
        )?;

        info!(
            "[PUMP ATOMİK ÇIKIŞ + KİRA İADESİ] Mint={} | MCAP=${:.0} | Sebep='{}' | Beklenen={:.6} SOL",
            mint,
            self.oracle.lamports_to_usd(curve.market_cap_lamports(false)),
            reason,
            expected_sol as f64 / 1_000_000_000.0
        );

        self.submit_and_verify_exit(mint, pdas.user_ata, &sell_tx, expected_sol, pos.entry_cost_lamports, reason)
            .await
    }

    async fn execute_pumpswap_exit(
        &self,
        mint: Pubkey,
        meta: &PumpSwapPoolMeta,
        reason: &str,
        is_profit_exit: bool,
    ) -> Result<()> {
        let Some(pos) = self.positions.get(&mint).map(|r| r.value().clone()) else {
            return Ok(());
        };
        let ata = pos.user_ata();

        let live_balance = if pos.exact_fill_confirmed && pos.token_amount > 0 {
            pos.token_amount
        } else {
            self.rpc
                .get_token_account_balance(&ata)
                .await
                .unwrap_or(pos.token_amount)
        };
        if live_balance == 0 {
            self.positions.remove(&mint);
            return Ok(());
        }

        let expected_sol = meta.quote_sell_tokens(live_balance).unwrap_or(0);
        let min_sol_output =
            self.compute_exit_min_sol(expected_sol, pos.entry_cost_lamports, is_profit_exit);

        let mut exit_ixs = build_pumpswap_atomic_sell_ixs(
            &self.wallet_pubkey,
            meta,
            live_balance,
            min_sol_output,
            self.cfg.strategy.auto_close_ata_reclaim_rent,
        );
        exit_ixs.push(
            self.jito
                .build_tip_ix_with_dontfront(&self.wallet_pubkey, self.cfg.jito.tip_lamports),
        );

        let recent_bh = self.blockhash_cache.get().await?;
        let sell_tx = JitoClient::compile_v0_tx(
            &self.wallet,
            self.cfg.strategy.compute_unit_limit,
            self.cfg.strategy.compute_unit_price_micro_lamports,
            exit_ixs,
            recent_bh,
        )?;

        info!(
            "[PUMPSWAP ATOMİK ÇIKIŞ + ÇİFT KİRA İADESİ] Mint={} | MCAP=${:.0} | Sebep='{}' | Beklenen={:.6} SOL",
            mint,
            self.oracle.lamports_to_usd(meta.market_cap_lamports()),
            reason,
            expected_sol as f64 / 1_000_000_000.0
        );

        self.submit_and_verify_exit(
            mint,
            ata,
            &sell_tx,
            expected_sol,
            pos.entry_cost_lamports,
            reason,
        )
        .await
    }

    fn compute_exit_min_sol(
        &self,
        expected_sol: u64,
        entry_cost_lamports: u64,
        is_profit_exit: bool,
    ) -> u64 {
        let effective_slip_bps = if !is_profit_exit {
            (self.cfg.strategy.sell_slippage_bps * 3).min(2_000)
        } else {
            self.cfg.strategy.sell_slippage_bps
        };
        let mut min_sol_output = ((expected_sol as u128
            * (10_000u128.saturating_sub(effective_slip_bps as u128)))
            / 10_000u128) as u64;

        if is_profit_exit && self.cfg.strategy.strict_profit_lock_tp {
            let break_even_floor = entry_cost_lamports
                .saturating_add(self.cfg.jito.tip_lamports)
                .saturating_add(BASE_TX_FEE_LAMPORTS);
            if expected_sol >= break_even_floor {
                min_sol_output = min_sol_output.max(break_even_floor);
            }
        }
        min_sol_output
    }

    async fn submit_and_verify_exit(
        &self,
        mint: Pubkey,
        user_ata: Pubkey,
        sell_tx: &VersionedTransaction,
        expected_sol: u64,
        entry_cost_lamports: u64,
        reason: &str,
    ) -> Result<()> {
        let atomic_res = self.jito.send_single_atomic_tx(sell_tx).await;
        if let Ok(receipt) = atomic_res {
            if let Some(bundle_id) = receipt.bundle_id {
                let _ = self
                    .jito
                    .wait_for_bundle(&bundle_id, Duration::from_millis(3500))
                    .await;
            }
        } else if self.cfg.network.dual_send_momentum {
            let _ = self.rpc.send_transaction_fast(sell_tx).await;
        }

        if !self.positions.contains_key(&mint) {
            return Ok(());
        }

        let closed_or_zero = match self.rpc.get_account_info(&user_ata).await {
            Ok(None) => true,
            Ok(Some(_)) => self
                .rpc
                .get_token_account_balance(&user_ata)
                .await
                .map(|b| b == 0)
                .unwrap_or(false),
            Err(_) => false,
        };

        if closed_or_zero {
            if self.positions.remove(&mint).is_some() {
                let net_pnl = expected_sol as i64
                    - entry_cost_lamports as i64
                    - self.cfg.jito.tip_lamports as i64
                    - BASE_TX_FEE_LAMPORTS as i64;
                self.pnl.record_trade(net_pnl);
                self.breaker.record_success();
                info!(
                    "[POZİSYON KAPANDI & KİRALAR GERİ ALINDI] Mint={} | Net PnL={:+.6} SOL | Sebep='{}'",
                    mint,
                    net_pnl as f64 / 1_000_000_000.0,
                    reason
                );
            }
            Ok(())
        } else {
            if let Ok(real_bal) = self.rpc.get_token_account_balance(&user_ata).await {
                if let Some(mut p) = self.positions.get_mut(&mint) {
                    p.token_amount = real_bal;
                    p.exact_fill_confirmed = true;
                }
            }
            bail!("Atomik satış paketi hedef slotta yerleşmedi (0 SOL kayıp), yeniden deneniyor")
        }
    }

    async fn resolve_pumpswap_pool(&self, hints: &PumpSwapTxHints) -> Result<PumpSwapPoolMeta> {
        let pool_acc = self
            .rpc
            .get_account_info(&hints.pool)
            .await?
            .context("PumpSwap Pool hesabı bulunamadı")?;
        let base_res = self
            .rpc
            .get_token_account_balance(&hints.pool_base_token_account)
            .await
            .unwrap_or(0);
        let quote_res = self
            .rpc
            .get_token_account_balance(&hints.pool_quote_token_account)
            .await
            .unwrap_or(0);
        let mut meta = PumpSwapPoolMeta::from_pool_account_data(
            hints.pool,
            hints.base_token_program,
            base_res,
            quote_res,
            &pool_acc.data,
        )?;
        meta.buyback_fee_recipient = hints.buyback_fee_recipient;
        self.pumpswap_cache
            .insert(hints.pool, (meta.clone(), Instant::now()));
        Ok(meta)
    }

    async fn refresh_pumpswap_reserves(&self, prev: &PumpSwapPoolMeta) -> Result<PumpSwapPoolMeta> {
        let mut updated = prev.clone();
        if let Ok(b) = self
            .rpc
            .get_token_account_balance(&prev.pool_base_token_account)
            .await
        {
            updated.pool_base_reserves = b;
        }
        if let Ok(q) = self
            .rpc
            .get_token_account_balance(&prev.pool_quote_token_account)
            .await
        {
            updated.pool_quote_reserves = q;
        }
        self.pumpswap_cache
            .insert(prev.pool, (updated.clone(), Instant::now()));
        Ok(updated)
    }

    async fn resolve_mint_and_curve(&self, mint: &Pubkey) -> Result<MintResolvedMeta> {
        let bonding_curve = derive_bonding_curve_pda(mint);
        let mut accounts = self
            .rpc
            .get_multiple_accounts(&[*mint, bonding_curve])
            .await?;
        let bc_opt = accounts.pop().flatten();
        let mint_opt = accounts.pop().flatten();

        let mint_acc = mint_opt.context("Mint hesabı zincirde bulunamadı")?;
        if !is_supported_token_program(&mint_acc.owner) {
            bail!("Desteklenmeyen Mint owner programı: {}", mint_acc.owner);
        }

        let bc_acc = bc_opt.context("BondingCurve PDA hesabı zincirde bulunamadı")?;
        let curve = BondingCurveState::from_account_data(*mint, bonding_curve, &bc_acc.data)?;
        if !is_native_sol_quote(&curve.quote_mint) {
            bail!("Yalnızca Native SOL (WSOL) pariteleri desteklenmektedir");
        }

        self.mint_prog_cache.insert(*mint, mint_acc.owner);
        let _ = self.get_or_derive_pdas(mint, Some(bonding_curve), &mint_acc.owner);
        self.curve_cache
            .insert(*mint, (curve.clone(), Instant::now()));

        Ok(MintResolvedMeta {
            token_program: mint_acc.owner,
            curve,
        })
    }

    async fn simulate_checked(&self, tx: &VersionedTransaction, label: &str) -> Result<()> {
        let sim = self.rpc.simulate_transaction(tx).await?;
        if let Some(err) = sim.error {
            bail!(
                "{} simülasyonu başarısız: {} | Loglar: {:?}",
                label,
                err,
                sim.logs
            );
        }
        debug!("{} simülasyonu başarılı (CU={})", label, sim.units_consumed);
        Ok(())
    }
}
