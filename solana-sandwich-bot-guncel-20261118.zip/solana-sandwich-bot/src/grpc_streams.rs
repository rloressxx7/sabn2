//! Saf Rust (`tonic` + `prost`) ile harici `protoc` derleyicisi gerektirmeden çalışan:
//! 1. **AllenHark / Yellowstone Geyser gRPC** istemcisi (`geyser.Geyser/Subscribe`)
//! 2. **AllenHark / Jito ShredStream gRPC** istemcisi (`shredstream.ShredstreamProxy/SubscribeEntries`)

use anyhow::{Context, Result};
use futures_util::StreamExt;
use http::uri::PathAndQuery;
use serde::{Deserialize, Serialize};
use solana_hash::Hash;
use solana_pubkey::Pubkey;
use solana_transaction::versioned::VersionedTransaction;
use std::collections::HashMap;
use std::str::FromStr;
use std::sync::atomic::Ordering;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::mpsc;
use tokio_stream::wrappers::ReceiverStream;
use tonic::codec::ProstCodec;
use tonic::metadata::{Ascii, MetadataValue};
use tonic::transport::{Channel, ClientTlsConfig, Endpoint};
use tracing::{debug, error, info, warn};

use crate::monitor::{MarketEvent, MonitorCounters, TxAccountHints};
use crate::pump::{
    pump_program_id, ParsedTradeEvent, ParsedVictimBuy, BUY_DISCRIMINATOR,
    BUY_EXACT_QUOTE_IN_V2_DISCRIMINATOR, BUY_EXACT_QUOTE_IN_V3_DISCRIMINATOR,
    BUY_EXACT_SOL_IN_DISCRIMINATOR, BUY_V2_DISCRIMINATOR, BUY_V3_DISCRIMINATOR,
    MAYHEM_PROGRAM_ID_STR, PUMP_PROGRAM_ID_STR, SELL_DISCRIMINATOR,
};
use crate::pumpswap::{
    extract_pumpswap_hints_from_ix, parse_pumpswap_buy_tx, pumpswap_program_id,
    ParsedPumpSwapTrade, PumpSwapTxHints, IX_PUMPSWAP_BUY, IX_PUMPSWAP_BUY_EXACT_QUOTE_IN,
    IX_PUMPSWAP_BUY_EXACT_QUOTE_IN_V2, IX_PUMPSWAP_BUY_V2, PUMPSWAP_PROGRAM_ID_STR,
};
use crate::rpc::BlockhashCache;

const MAX_GRPC_MESSAGE_BYTES: usize = 64 * 1024 * 1024; // 64 MiB (AllenHark yoğun slot gereksinimi)

// ============================================================================
// 1. AllenHark / Jito ShredStream Wire Protobuf Yapıları (`shredstream.proto`)
// ============================================================================

#[derive(Clone, PartialEq, prost::Message)]
pub struct SubscribeEntriesRequest {}

#[derive(Clone, PartialEq, prost::Message)]
pub struct ShredEntryBatch {
    #[prost(uint64, tag = "1")]
    pub slot: u64,
    /// `bincode` ile serileştirilmiş `Vec<SolanaLedgerEntry>`
    #[prost(bytes = "vec", tag = "2")]
    pub entries: Vec<u8>,
}

/// `solana_entry::entry::Entry` ile birebir aynı bincode bellek düzeni
#[derive(Debug, Serialize, Deserialize)]
pub struct SolanaLedgerEntry {
    pub num_hashes: u64,
    pub hash: Hash,
    pub transactions: Vec<VersionedTransaction>,
}

// ============================================================================
// 2. Yellowstone Geyser Wire Protobuf Yapıları (`geyser.proto` + `solana-storage.proto`)
// ============================================================================

#[derive(Clone, PartialEq, prost::Message)]
pub struct SubscribeRequest {
    #[prost(map = "string, message", tag = "1")]
    pub accounts: HashMap<String, SubscribeRequestFilterAccounts>,
    #[prost(map = "string, message", tag = "2")]
    pub slots: HashMap<String, SubscribeRequestFilterSlots>,
    #[prost(map = "string, message", tag = "3")]
    pub transactions: HashMap<String, SubscribeRequestFilterTransactions>,
    #[prost(map = "string, message", tag = "5")]
    pub blocks_meta: HashMap<String, SubscribeRequestFilterBlocksMeta>,
    #[prost(int32, optional, tag = "6")]
    pub commitment: Option<i32>, // 0 = PROCESSED
    #[prost(message, optional, tag = "9")]
    pub ping: Option<SubscribeRequestPing>,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct SubscribeRequestFilterAccounts {
    #[prost(string, repeated, tag = "2")]
    pub account: Vec<String>,
    #[prost(string, repeated, tag = "3")]
    pub owner: Vec<String>,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct SubscribeRequestFilterSlots {
    #[prost(bool, optional, tag = "1")]
    pub filter_by_commitment: Option<bool>,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct SubscribeRequestFilterTransactions {
    #[prost(bool, optional, tag = "1")]
    pub vote: Option<bool>,
    #[prost(bool, optional, tag = "2")]
    pub failed: Option<bool>,
    #[prost(string, repeated, tag = "3")]
    pub account_include: Vec<String>,
    #[prost(string, repeated, tag = "4")]
    pub account_exclude: Vec<String>,
    #[prost(string, repeated, tag = "6")]
    pub account_required: Vec<String>,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct SubscribeRequestFilterBlocksMeta {}

#[derive(Clone, PartialEq, prost::Message)]
pub struct SubscribeRequestPing {
    #[prost(int32, tag = "1")]
    pub id: i32,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct SubscribeUpdate {
    #[prost(string, repeated, tag = "1")]
    pub filters: Vec<String>,
    #[prost(oneof = "UpdateOneof", tags = "2, 3, 4, 6, 7, 9")]
    pub update_oneof: Option<UpdateOneof>,
}

#[derive(Clone, PartialEq, prost::Oneof)]
pub enum UpdateOneof {
    #[prost(message, tag = "2")]
    Account(SubscribeUpdateAccount),
    #[prost(message, tag = "3")]
    Slot(SubscribeUpdateSlot),
    #[prost(message, tag = "4")]
    Transaction(SubscribeUpdateTransaction),
    #[prost(message, tag = "6")]
    Ping(SubscribeUpdatePing),
    #[prost(message, tag = "7")]
    BlockMeta(SubscribeUpdateBlockMeta),
    #[prost(message, tag = "9")]
    Pong(SubscribeUpdatePong),
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct SubscribeUpdateAccount {
    #[prost(message, optional, tag = "1")]
    pub account: Option<SubscribeUpdateAccountInfo>,
    #[prost(uint64, tag = "2")]
    pub slot: u64,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct SubscribeUpdateAccountInfo {
    #[prost(bytes = "vec", tag = "1")]
    pub pubkey: Vec<u8>,
    #[prost(uint64, tag = "2")]
    pub lamports: u64,
    #[prost(bytes = "vec", tag = "3")]
    pub owner: Vec<u8>,
    #[prost(bytes = "vec", tag = "6")]
    pub data: Vec<u8>,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct SubscribeUpdateSlot {
    #[prost(uint64, tag = "1")]
    pub slot: u64,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct SubscribeUpdatePing {}

#[derive(Clone, PartialEq, prost::Message)]
pub struct SubscribeUpdatePong {
    #[prost(int32, tag = "1")]
    pub id: i32,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct SubscribeUpdateBlockMeta {
    #[prost(uint64, tag = "1")]
    pub slot: u64,
    #[prost(string, tag = "2")]
    pub blockhash: String,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct SubscribeUpdateTransaction {
    #[prost(message, optional, tag = "1")]
    pub transaction: Option<SubscribeUpdateTransactionInfo>,
    #[prost(uint64, tag = "2")]
    pub slot: u64,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct SubscribeUpdateTransactionInfo {
    #[prost(bytes = "vec", tag = "1")]
    pub signature: Vec<u8>,
    #[prost(bool, tag = "2")]
    pub is_vote: bool,
    #[prost(message, optional, tag = "3")]
    pub transaction: Option<ProtoSolanaTransaction>,
    #[prost(message, optional, tag = "4")]
    pub meta: Option<ProtoTransactionStatusMeta>,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct ProtoSolanaTransaction {
    #[prost(bytes = "vec", repeated, tag = "1")]
    pub signatures: Vec<Vec<u8>>,
    #[prost(message, optional, tag = "2")]
    pub message: Option<ProtoSolanaMessage>,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct ProtoSolanaMessage {
    #[prost(bytes = "vec", repeated, tag = "2")]
    pub account_keys: Vec<Vec<u8>>,
    #[prost(bytes = "vec", tag = "3")]
    pub recent_blockhash: Vec<u8>,
    #[prost(message, repeated, tag = "4")]
    pub instructions: Vec<ProtoCompiledInstruction>,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct ProtoCompiledInstruction {
    #[prost(uint32, tag = "1")]
    pub program_id_index: u32,
    #[prost(bytes = "vec", tag = "2")]
    pub accounts: Vec<u8>,
    #[prost(bytes = "vec", tag = "3")]
    pub data: Vec<u8>,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct ProtoInnerInstructions {
    #[prost(uint32, tag = "1")]
    pub index: u32,
    #[prost(message, repeated, tag = "2")]
    pub instructions: Vec<ProtoCompiledInstruction>,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct ProtoTransactionError {
    #[prost(bytes = "vec", tag = "1")]
    pub err: Vec<u8>,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct ProtoTransactionStatusMeta {
    #[prost(message, optional, tag = "1")]
    pub err: Option<ProtoTransactionError>,
    #[prost(message, repeated, tag = "5")]
    pub inner_instructions: Vec<ProtoInnerInstructions>,
    #[prost(string, repeated, tag = "6")]
    pub log_messages: Vec<String>,
    #[prost(bytes = "vec", repeated, tag = "12")]
    pub loaded_writable_addresses: Vec<Vec<u8>>,
    #[prost(bytes = "vec", repeated, tag = "13")]
    pub loaded_readonly_addresses: Vec<Vec<u8>>,
}

// ============================================================================
// Ortak HTTP/2 gRPC Kanal Kurucu (Plaintext HTTP/2 + TLS Otomatik Algılama)
// ============================================================================

async fn build_grpc_channel(raw_endpoint: &str) -> Result<Channel> {
    let url = if raw_endpoint.starts_with("http://") || raw_endpoint.starts_with("https://") {
        raw_endpoint.to_string()
    } else {
        // AllenHark port 10001 / 9090 varsayılan olarak plaintext HTTP/2 kullanır
        format!("http://{}", raw_endpoint)
    };

    let mut ep = Endpoint::from_shared(url.clone())
        .with_context(|| format!("Geçersiz gRPC endpoint adresi: {}", url))?
        .tcp_nodelay(true)
        .http2_keep_alive_interval(Duration::from_secs(10))
        .keep_alive_timeout(Duration::from_secs(5))
        .keep_alive_while_idle(true)
        .connect_timeout(Duration::from_secs(8));

    if url.starts_with("https://") {
        ep = ep
            .tls_config(ClientTlsConfig::new().with_webpki_roots())
            .context("gRPC TLS yapılandırması başarısız")?;
    }

    ep.connect()
        .await
        .with_context(|| format!("gRPC sunucusuna bağlanılamadı: {}", url))
}

fn attach_auth_headers<T>(req: &mut tonic::Request<T>, token: &Option<String>) {
    if let Some(tok) = token.as_deref().map(str::trim).filter(|s| !s.is_empty()) {
        if let Ok(val) = MetadataValue::<Ascii>::try_from(tok) {
            req.metadata_mut().insert("x-token", val.clone());
            req.metadata_mut().insert("x-api-key", val);
        }
    }
}

// ============================================================================
// 3. AllenHark / Yellowstone Geyser gRPC Akış İzleyicisi
// ============================================================================

pub struct YellowstoneGeyserMonitor {
    endpoint: String,
    x_token: Option<String>,
    blockhash_cache: BlockhashCache,
    event_tx: mpsc::Sender<MarketEvent>,
    counters: Arc<MonitorCounters>,
}

impl YellowstoneGeyserMonitor {
    pub fn new(
        endpoint: String,
        x_token: Option<String>,
        blockhash_cache: BlockhashCache,
        event_tx: mpsc::Sender<MarketEvent>,
        counters: Arc<MonitorCounters>,
    ) -> Self {
        Self {
            endpoint,
            x_token,
            blockhash_cache,
            event_tx,
            counters,
        }
    }

    pub async fn run_forever(self) {
        let mut backoff = 1u64;
        loop {
            match self.connect_and_subscribe().await {
                Ok(()) => {
                    warn!("Yellowstone Geyser gRPC akışı kapandı, 1 sn içinde yeniden bağlanılıyor...");
                    backoff = 1;
                }
                Err(e) => {
                    error!(
                        "Yellowstone Geyser gRPC hatası ({}): {:#} — {} sn sonra tekrar denenecek...",
                        self.endpoint, e, backoff
                    );
                }
            }
            tokio::time::sleep(Duration::from_secs(backoff)).await;
            backoff = (backoff * 2).min(10);
        }
    }

    async fn connect_and_subscribe(&self) -> Result<()> {
        let channel = build_grpc_channel(&self.endpoint).await?;
        let mut grpc = tonic::client::Grpc::new(channel)
            .max_decoding_message_size(MAX_GRPC_MESSAGE_BYTES);

        grpc.ready()
            .await
            .context("Geyser HTTP/2 servisi hazır değil")?;

        let (sub_tx, sub_rx) = mpsc::channel::<SubscribeRequest>(32);

        // AllenHark Standard ($5/gün veya $99/ay) planındaki 500 hesap filtresi sınırına %100 uyumlu!
        // Yalnızca 3 program filtresi (`PUMP` + `PUMPSWAP` + `MAYHEM`) ile hem $10k-$29.5k eğriyi hem de
        // $29.5k-$50k mezun olmuş PumpSwap AMM havuzlarını 0-ms gecikmeyle yakalar!
        let mut tx_filters = HashMap::new();
        tx_filters.insert(
            "pump_txs".to_string(),
            SubscribeRequestFilterTransactions {
                vote: Some(false),
                failed: Some(false),
                account_include: vec![
                    PUMP_PROGRAM_ID_STR.to_string(),
                    PUMPSWAP_PROGRAM_ID_STR.to_string(),
                    MAYHEM_PROGRAM_ID_STR.to_string(),
                ],
                account_exclude: Vec::new(),
                account_required: Vec::new(),
            },
        );

        let mut blocks_meta = HashMap::new();
        blocks_meta.insert("meta".to_string(), SubscribeRequestFilterBlocksMeta {});

        let initial_req = SubscribeRequest {
            accounts: HashMap::new(),
            slots: HashMap::new(),
            transactions: tx_filters,
            blocks_meta,
            commitment: Some(0), // PROCESSED (en düşük gecikme)
            ping: None,
        };
        sub_tx.send(initial_req).await?;

        let mut request = tonic::Request::new(ReceiverStream::new(sub_rx));
        attach_auth_headers(&mut request, &self.x_token);

        let codec = ProstCodec::<SubscribeRequest, SubscribeUpdate>::default();
        let path = PathAndQuery::from_static("/geyser.Geyser/Subscribe");

        let response = grpc
            .streaming(request, path, codec)
            .await
            .context("Geyser Subscribe çağrısı reddedildi (IP whitelist veya x-token kontrol edin)")?;

        info!(
            "AllenHark / Yellowstone Geyser gRPC BAĞLANDI ({}) — 0-ms Pump.fun işlem + blockhash akışı aktif!",
            self.endpoint
        );

        let mut stream = response.into_inner();
        let mut ping_id = 1i32;

        while let Some(item) = stream.next().await {
            let update = item.context("Geyser gRPC paket okuma hatası")?;
            self.counters.grpc_messages.fetch_add(1, Ordering::Relaxed);

            let Some(oneof) = update.update_oneof else {
                continue;
            };

            match oneof {
                UpdateOneof::Ping(_) => {
                    ping_id = ping_id.wrapping_add(1);
                    let pong_req = SubscribeRequest {
                        accounts: HashMap::new(),
                        slots: HashMap::new(),
                        transactions: HashMap::new(),
                        blocks_meta: HashMap::new(),
                        commitment: None,
                        ping: Some(SubscribeRequestPing { id: ping_id }),
                    };
                    let _ = sub_tx.try_send(pong_req);
                }
                UpdateOneof::BlockMeta(bm) => {
                    if let Ok(bh) = Hash::from_str(&bm.blockhash) {
                        self.blockhash_cache.update_from_stream(bh);
                    }
                }
                UpdateOneof::Transaction(tx_upd) => {
                    self.process_geyser_tx(tx_upd).await;
                }
                _ => {}
            }
        }

        Ok(())
    }

    async fn process_geyser_tx(&self, tx_upd: SubscribeUpdateTransaction) {
        let Some(info) = tx_upd.transaction else {
            return;
        };
        if info.is_vote {
            return;
        }
        let Some(meta) = info.meta else {
            return;
        };
        if meta.err.is_some() {
            self.counters
                .reverted_skipped
                .fetch_add(1, Ordering::Relaxed);
            return;
        }

        let sig_str = bs58::encode(&info.signature).into_string();

        // İşlem mesajındaki statik + ALT (Address Lookup Table) hesaplarını birleştirip
        // hem Pump.fun Bonding Curve hem de PumpSwap AMM havuz ipuçlarını 0-RPC ile doğrudan çıkar!
        let (hints, ps_hints) = extract_all_account_hints(info.transaction.as_ref(), &meta);

        let mut emitted_pumpswap = false;
        for line in &meta.log_messages {
            if let Some(b64_data) = line.strip_prefix("Program data: ") {
                if let Some(trade) = ParsedTradeEvent::from_program_data_b64(b64_data) {
                    self.counters.decoded_trades.fetch_add(1, Ordering::Relaxed);
                    let hint = hints.get(&trade.mint).copied();
                    let _ = self
                        .event_tx
                        .send(MarketEvent::ConfirmedTrade {
                            signature: sig_str.clone(),
                            trade,
                            hints: hint,
                        })
                        .await;
                } else if let Ok(raw) = base64::Engine::decode(
                    &base64::engine::general_purpose::STANDARD,
                    b64_data.trim(),
                ) {
                    if let Some(ps_trade) = ParsedPumpSwapTrade::from_raw_bytes(&raw) {
                        emitted_pumpswap = true;
                        self.counters
                            .pumpswap_trades
                            .fetch_add(1, Ordering::Relaxed);
                        let hint = ps_hints.get(&ps_trade.pool).copied();
                        let _ = self
                            .event_tx
                            .send(MarketEvent::ConfirmedPumpSwapTrade {
                                signature: sig_str.clone(),
                                trade: ps_trade,
                                hints: hint,
                            })
                            .await;
                    }
                }
            }
        }

        // PumpSwap `emit_cpi!` event'leri bazen `Program data:` yerine doğrudan CPI inner instruction olarak gelir!
        if !emitted_pumpswap {
            for ii in &meta.inner_instructions {
                for ix in &ii.instructions {
                    if let Some(ps_trade) = ParsedPumpSwapTrade::from_raw_bytes(&ix.data) {
                        self.counters
                            .pumpswap_trades
                            .fetch_add(1, Ordering::Relaxed);
                        let hint = ps_hints.get(&ps_trade.pool).copied();
                        let _ = self
                            .event_tx
                            .send(MarketEvent::ConfirmedPumpSwapTrade {
                                signature: sig_str.clone(),
                                trade: ps_trade,
                                hints: hint,
                            })
                            .await;
                    }
                }
            }
        }
    }
}

/// Geyser işlem mesajındaki tüm (üst seviye + CPI inner) komutları tarayarak hem Pump.fun
/// hem de PumpSwap AMM hesap ipuçlarını 0-RPC ile çıkarır.
fn extract_all_account_hints(
    tx_opt: Option<&ProtoSolanaTransaction>,
    meta: &ProtoTransactionStatusMeta,
) -> (HashMap<Pubkey, TxAccountHints>, HashMap<Pubkey, PumpSwapTxHints>) {
    let mut map = HashMap::new();
    let mut ps_map = HashMap::new();
    let Some(msg) = tx_opt.and_then(|t| t.message.as_ref()) else {
        return (map, ps_map);
    };

    let total_keys = msg.account_keys.len()
        + meta.loaded_writable_addresses.len()
        + meta.loaded_readonly_addresses.len();
    let mut all_keys = Vec::with_capacity(total_keys);

    for raw in msg
        .account_keys
        .iter()
        .chain(meta.loaded_writable_addresses.iter())
        .chain(meta.loaded_readonly_addresses.iter())
    {
        if let Ok(arr) = <[u8; 32]>::try_from(raw.as_slice()) {
            all_keys.push(Pubkey::new_from_array(arr));
        } else {
            return (map, ps_map);
        }
    }

    let pump_id = pump_program_id();
    let pumpswap_id = pumpswap_program_id();
    let inner_iter = meta
        .inner_instructions
        .iter()
        .flat_map(|ii| ii.instructions.iter());

    for ix in msg.instructions.iter().chain(inner_iter) {
        let Some(prog_id) = all_keys.get(ix.program_id_index as usize) else {
            continue;
        };
        if *prog_id == pumpswap_id {
            if let Some(psh) = extract_pumpswap_hints_from_ix(&all_keys, &ix.accounts, &ix.data) {
                ps_map.insert(psh.pool, psh);
            }
            continue;
        }
        if *prog_id != pump_id || ix.data.len() < 8 || ix.accounts.len() < 10 {
            continue;
        }
        let disc = &ix.data[0..8];
        let get_pk = |idx: usize| -> Option<Pubkey> {
            let key_pos = *ix.accounts.get(idx)? as usize;
            all_keys.get(key_pos).copied()
        };

        if disc == BUY_DISCRIMINATOR || disc == BUY_EXACT_SOL_IN_DISCRIMINATOR
            || disc == BUY_V2_DISCRIMINATOR || disc == BUY_EXACT_QUOTE_IN_V2_DISCRIMINATOR
        {
            let buyback_fee_recipient = if ix.accounts.len() >= 18 {
                get_pk(17)
            } else {
                None
            };
            if let (Some(fee_recipient), Some(mint), Some(token_program), Some(creator_vault)) =
                (get_pk(1), get_pk(2), get_pk(8), get_pk(9))
            {
                map.insert(
                    mint,
                    TxAccountHints {
                        token_program,
                        creator_vault,
                        fee_recipient,
                        buyback_fee_recipient,
                    },
                );
            }
        } else if (disc == BUY_V3_DISCRIMINATOR || disc == BUY_EXACT_QUOTE_IN_V3_DISCRIMINATOR)
            && ix.accounts.len() >= 14
        {
            // v3 düzeni: [1] mint, [2] quote_mint, [3] base_token_prog, [5] curve, [8] buyer, [13] buyback
            let mint = get_pk(1);
            let token_program = get_pk(3);
            let buyback_fee_recipient = get_pk(13);
            if let (Some(mint), Some(token_program)) = (mint, token_program) {
                map.insert(
                    mint,
                    TxAccountHints {
                        token_program,
                        creator_vault: Pubkey::default(), // v3'de creator_vault doğrudan hesapta yok
                        fee_recipient: Pubkey::default(), // v3'de fee_recipient doğrudan hesapta yok
                        buyback_fee_recipient,
                    },
                );
            }
        } else if disc == SELL_DISCRIMINATOR && ix.accounts.len() >= 15 {
            let buyback_fee_recipient = if ix.accounts.len() >= 16 {
                get_pk(ix.accounts.len() - 1)
            } else {
                None
            };
            if let (Some(fee_recipient), Some(mint), Some(creator_vault), Some(token_program)) =
                (get_pk(1), get_pk(2), get_pk(8), get_pk(9))
            {
                map.entry(mint).or_insert(TxAccountHints {
                    token_program,
                    creator_vault,
                    fee_recipient,
                    buyback_fee_recipient,
                });
            }
        }
    }

    (map, ps_map)
}

// ============================================================================
// 4. AllenHark / Jito ShredStream gRPC İzleyicisi (`SubscribeEntries`)
// ============================================================================

pub struct ShredStreamGrpcMonitor {
    endpoint: String,
    api_key: Option<String>,
    event_tx: mpsc::Sender<MarketEvent>,
    counters: Arc<MonitorCounters>,
}

impl ShredStreamGrpcMonitor {
    pub fn new(
        endpoint: String,
        api_key: Option<String>,
        event_tx: mpsc::Sender<MarketEvent>,
        counters: Arc<MonitorCounters>,
    ) -> Self {
        Self {
            endpoint,
            api_key,
            event_tx,
            counters,
        }
    }

    pub async fn run_forever(self) {
        let mut backoff = 1u64;
        loop {
            match self.connect_and_stream().await {
                Ok(()) => {
                    warn!("ShredStream gRPC akışı kapandı, 1 sn sonra yeniden bağlanılıyor...");
                    backoff = 1;
                }
                Err(e) => {
                    error!(
                        "ShredStream gRPC hatası ({}): {:#} — {} sn sonra tekrar denenecek...",
                        self.endpoint, e, backoff
                    );
                }
            }
            tokio::time::sleep(Duration::from_secs(backoff)).await;
            backoff = (backoff * 2).min(10);
        }
    }

    async fn connect_and_stream(&self) -> Result<()> {
        let channel = build_grpc_channel(&self.endpoint).await?;
        let mut grpc = tonic::client::Grpc::new(channel)
            .max_decoding_message_size(MAX_GRPC_MESSAGE_BYTES);

        grpc.ready()
            .await
            .context("ShredStream HTTP/2 servisi hazır değil")?;

        let mut request = tonic::Request::new(SubscribeEntriesRequest {});
        attach_auth_headers(&mut request, &self.api_key);

        let codec = ProstCodec::<SubscribeEntriesRequest, ShredEntryBatch>::default();
        let path = PathAndQuery::from_static("/shredstream.ShredstreamProxy/SubscribeEntries");

        let response = grpc
            .server_streaming(request, path, codec)
            .await
            .context("ShredStream SubscribeEntries reddedildi (x-api-key veya proxy kontrol edin)")?;

        info!(
            "ShredStream gRPC BAĞLANDI ({}) — Blok daha inşa edilirken canlı Entry akışı okunuyor!",
            self.endpoint
        );

        let mut stream = response.into_inner();
        while let Some(batch_res) = stream.next().await {
            let batch = batch_res.context("ShredStream paket okuma hatası")?;
            self.counters.shred_batches.fetch_add(1, Ordering::Relaxed);

            // 0-Allocation Nanosaniye Ön-Filtre: Shred paketi içinde Pump.fun Buy veya
            // BuyExactSolIn 8-byte imzası yoksa bincode deserialize + heap ayırmayı tamamen atla!
            if !contains_pump_buy_discriminator(&batch.entries) {
                continue;
            }

            let Ok(entries) = bincode::deserialize::<Vec<SolanaLedgerEntry>>(&batch.entries) else {
                debug!("Slot {} için Shred entry bincode çözümlenemedi", batch.slot);
                continue;
            };

            for entry in entries {
                for tx in entry.transactions {
                    if let Some(parsed) = ParsedVictimBuy::from_versioned_tx(&tx) {
                        let sig_str = tx
                            .signatures
                            .first()
                            .map(|s| s.to_string())
                            .unwrap_or_default();
                        self.counters
                            .shred_whale_buys
                            .fetch_add(1, Ordering::Relaxed);
                        let _ = self
                            .event_tx
                            .send(MarketEvent::ShredFastBuy {
                                slot: batch.slot,
                                signature: sig_str,
                                victim_tx: tx.clone(),
                                parsed,
                            })
                            .await;
                    } else if let Some(parsed) = parse_pumpswap_buy_tx(&tx) {
                        let sig_str = tx
                            .signatures
                            .first()
                            .map(|s| s.to_string())
                            .unwrap_or_default();
                        self.counters
                            .shred_whale_buys
                            .fetch_add(1, Ordering::Relaxed);
                        let _ = self
                            .event_tx
                            .send(MarketEvent::ShredFastPumpSwapBuy {
                                slot: batch.slot,
                                signature: sig_str,
                                victim_tx: tx.clone(),
                                parsed,
                            })
                            .await;
                    }
                }
            }
        }

        Ok(())
    }
}

#[inline(always)]
fn contains_pump_buy_discriminator(haystack: &[u8]) -> bool {
    if haystack.len() < 8 {
        return false;
    }
    let b_exact = BUY_EXACT_SOL_IN_DISCRIMINATOR[0];
    let b_legacy = BUY_DISCRIMINATOR[0];
    let b_ps_q = IX_PUMPSWAP_BUY_EXACT_QUOTE_IN[0];
    let b_ps_v2 = IX_PUMPSWAP_BUY_V2[0];
    let b_ps_qv2 = IX_PUMPSWAP_BUY_EXACT_QUOTE_IN_V2[0];
    let end = haystack.len() - 8;
    let mut i = 0;
    while i <= end {
        let b = haystack[i];
        if (b == b_exact && haystack[i..i + 8] == BUY_EXACT_SOL_IN_DISCRIMINATOR)
            || (b == b_legacy && haystack[i..i + 8] == BUY_DISCRIMINATOR)
            || (b == b_ps_q && haystack[i..i + 8] == IX_PUMPSWAP_BUY_EXACT_QUOTE_IN)
            || (b == b_ps_v2 && haystack[i..i + 8] == IX_PUMPSWAP_BUY_V2)
            || (b == b_ps_qv2 && haystack[i..i + 8] == IX_PUMPSWAP_BUY_EXACT_QUOTE_IN_V2)
            || (b == IX_PUMPSWAP_BUY[0] && haystack[i..i + 8] == IX_PUMPSWAP_BUY)
        {
            return true;
        }
        i += 1;
    }
    false
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct GetVersionRequest {}

#[derive(Clone, PartialEq, prost::Message)]
pub struct GetVersionResponse {
    #[prost(string, tag = "1")]
    pub version: String,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct GetSlotRequest {
    #[prost(int32, optional, tag = "1")]
    pub commitment: Option<i32>,
}

#[derive(Clone, PartialEq, prost::Message)]
pub struct GetSlotResponse {
    #[prost(uint64, tag = "1")]
    pub slot: u64,
}

/// AllenHark Yellowstone Geyser gRPC sunucusunu (`http://88.216.36.108:10001`) canlı test eder:
/// 1) HTTP/2 bağlantısı + `GetVersion` + `GetSlot` ping süresini (mikrosaniye/milisaniye) ölçer,
/// 2) 5 saniye boyunca canlı `Pump.fun` + `PumpSwap` akışına (`Subscribe`) bağlanıp gelen gerçek işlemleri sayar ve bağlantıyı temizce kapatır!
pub async fn run_geyser_live_probe(endpoint: &str, x_token: Option<String>) -> Result<()> {
    info!("=== AllenHark Frankfurt Yellowstone Geyser gRPC Canlı Testi ({}) ===", endpoint);
    let t_conn = std::time::Instant::now();
    let channel = build_grpc_channel(endpoint).await?;
    let mut grpc =
        tonic::client::Grpc::new(channel).max_decoding_message_size(MAX_GRPC_MESSAGE_BYTES);
    grpc.ready().await?;
    info!(
        "[1/3] TCP + HTTP/2 Kanal Kurulumu Başarılı ({:.2} ms)",
        t_conn.elapsed().as_secs_f64() * 1000.0
    );

    // Unary GetSlot ping ölçümü
    let t_ping = std::time::Instant::now();
    let mut slot_req = tonic::Request::new(GetSlotRequest {
        commitment: Some(0),
    });
    attach_auth_headers(&mut slot_req, &x_token);
    let slot_codec = ProstCodec::<GetSlotRequest, GetSlotResponse>::default();
    let slot_resp = grpc
        .unary(
            slot_req,
            PathAndQuery::from_static("/geyser.Geyser/GetSlot"),
            slot_codec,
        )
        .await
        .context("GetSlot reddedildi — Sunucu IP'nizin (142.93.102.109) AllenHark Allowed IPs listesinde olduğundan ve başka açık bağlantı olmadığından emin olun")?;
    let ping_ms = t_ping.elapsed().as_secs_f64() * 1000.0;
    info!(
        "[2/3] AllenHark Geyser Canlı Yanıt Verdi! Güncel Slot = {} | Frankfurt Gecikmesi (RTT) = {:.3} ms!",
        slot_resp.into_inner().slot,
        ping_ms
    );

    // 5 saniyelik canlı Pump + PumpSwap Subscribe akış testi
    let (event_tx, mut event_rx) = mpsc::channel::<MarketEvent>(2048);
    let counters = Arc::new(MonitorCounters::default());
    let dummy_rpc = crate::rpc::SolanaRpcClient::new(
        vec!["https://api.mainnet-beta.solana.com".to_string()],
        solana_commitment_config::CommitmentConfig::processed(),
    );
    let bh_cache = BlockhashCache::new(dummy_rpc);
    let mon = YellowstoneGeyserMonitor::new(
        endpoint.to_string(),
        x_token,
        bh_cache,
        event_tx,
        counters.clone(),
    );
    let handle = tokio::spawn(async move {
        mon.run_forever().await;
    });

    info!("[3/3] 5 saniye boyunca canlı Pump.fun + PumpSwap işlemleri dinleniyor...");
    let deadline = tokio::time::Instant::now() + Duration::from_secs(5);
    let mut sample_logged = 0usize;
    while tokio::time::Instant::now() < deadline {
        if let Ok(Some(ev)) =
            tokio::time::timeout(Duration::from_millis(250), event_rx.recv()).await
        {
            if sample_logged < 5 {
                match ev {
                    MarketEvent::ConfirmedTrade {
                        signature, trade, ..
                    } => {
                        sample_logged += 1;
                        info!(
                            "  -> [CANLI PUMP] {} | Mint={} | {:.4} SOL | MCAP={:.2} SOL ({})",
                            if trade.is_buy { "ALIM " } else { "SATIŞ" },
                            trade.mint,
                            trade.sol_amount as f64 / 1e9,
                            trade.to_curve_state().market_cap_sol(false),
                            &signature[..signature.len().min(12)]
                        );
                    }
                    MarketEvent::ConfirmedPumpSwapTrade {
                        signature, trade, ..
                    } => {
                        sample_logged += 1;
                        info!(
                            "  -> [CANLI PUMPSWAP] {} | Pool={} | {:.4} SOL | MCAP={:.2} SOL ({})",
                            if trade.is_buy { "ALIM " } else { "SATIŞ" },
                            trade.pool,
                            trade.sol_amount as f64 / 1e9,
                            trade.post_trade_mcap_lamports() as f64 / 1e9,
                            &signature[..signature.len().min(12)]
                        );
                    }
                    _ => {}
                }
            }
        }
    }
    handle.abort();

    info!(
        "=== SONUÇ: 5 sn içinde {} gRPC paketi, {} Pump işlemi, {} PumpSwap işlemi sıfır hatayla alındı! (Bağlantı serbest bırakıldı: 0/1) ===",
        counters.grpc_messages.load(Ordering::Relaxed),
        counters.decoded_trades.load(Ordering::Relaxed),
        counters.pumpswap_trades.load(Ordering::Relaxed)
    );
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use prost::Message;

    #[test]
    fn test_shred_entry_bincode_and_protobuf_roundtrip() {
        let ledger_entries = vec![SolanaLedgerEntry {
            num_hashes: 42,
            hash: Hash::new_unique(),
            transactions: Vec::new(),
        }];
        let bincode_bytes = bincode::serialize(&ledger_entries).unwrap();

        let batch = ShredEntryBatch {
            slot: 312_000_001,
            entries: bincode_bytes,
        };
        let encoded = batch.encode_to_vec();
        let decoded = ShredEntryBatch::decode(encoded.as_slice()).unwrap();
        assert_eq!(decoded.slot, 312_000_001);

        let unpacked: Vec<SolanaLedgerEntry> = bincode::deserialize(&decoded.entries).unwrap();
        assert_eq!(unpacked.len(), 1);
        assert_eq!(unpacked[0].num_hashes, 42);
    }
}
