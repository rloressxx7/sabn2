use anyhow::{bail, Result};
use solana_instruction::{AccountMeta, Instruction};
use solana_message::VersionedMessage;
use solana_pubkey::Pubkey;
use solana_transaction::versioned::VersionedTransaction;
use std::str::FromStr;
use std::sync::OnceLock;

use crate::pump::{
    associated_token_program_id, build_close_token_account_ix, create_ata_idempotent_with_ata_ix,
    default_buyback_fee_recipient, derive_ata, mayhem_reserved_fee_recipient, pump_fee_program_id,
    spl_token_program_id, wsol_mint_id,
};

// ============================================================================
// PUMPSWAP AMM (`pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA`) SABİTLERİ (KASIM 2026)
// Mezun olan (`>$29.5k` MCAP) tüm Pump.fun tokenlarının işlem gördüğü resmi AMM!
// ============================================================================

pub const PUMPSWAP_PROGRAM_ID_STR: &str = "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA";
pub const PUMPSWAP_GLOBAL_CONFIG_STR: &str = "ADyA8hdefvWN2dbGGWFotbzWxrAvLW83WG6QCVXvJKqw";
pub const PUMPSWAP_EVENT_AUTHORITY_STR: &str = "GS4CU59F31iL7aR2Q8zVS8DRrcRnXX1yjQ66TqNVQnaR";
pub const PUMPSWAP_FEE_CONFIG_STR: &str = "5PHirr8joyTMp9JMm6nW7hNDVyEYdkzDqazxPD7RaTjx";
pub const DEFAULT_PUMPSWAP_PROTO_FEE_RECIPIENT_STR: &str =
    "62qc2CNXwrYqQScmEdiZFFAnJR262PxWEuNQtxfafNgV";

// Komut diskriminatörleri (`pump_amm.json` v2.2.0)
pub const IX_PUMPSWAP_BUY: [u8; 8] = [102, 6, 61, 18, 1, 218, 235, 234];
pub const IX_PUMPSWAP_BUY_EXACT_QUOTE_IN: [u8; 8] = [198, 46, 21, 82, 180, 217, 232, 112];
pub const IX_PUMPSWAP_BUY_V2: [u8; 8] = [184, 23, 238, 97, 103, 197, 211, 61];
pub const IX_PUMPSWAP_BUY_EXACT_QUOTE_IN_V2: [u8; 8] = [194, 171, 28, 70, 104, 77, 91, 47];
pub const IX_PUMPSWAP_SELL: [u8; 8] = [51, 230, 133, 164, 1, 127, 131, 173];
pub const IX_PUMPSWAP_SELL_V2: [u8; 8] = [93, 246, 130, 60, 231, 233, 64, 178];

// Event & Account diskriminatörleri
pub const PUMPSWAP_POOL_DISC: [u8; 8] = [241, 154, 109, 4, 17, 177, 109, 188];
pub const PUMPSWAP_BUY_EVENT_DISC: [u8; 8] = [103, 244, 82, 31, 44, 245, 119, 119];
pub const PUMPSWAP_SELL_EVENT_DISC: [u8; 8] = [62, 47, 55, 10, 165, 3, 220, 42];
pub const CPI_EVENT_IX_DISC: [u8; 8] = [228, 69, 165, 46, 81, 203, 154, 29];

// Standart PumpSwap toplam komisyon ~30 bps (20 bps LP + 5 bps protokol + 5 bps creator)
pub const PUMPSWAP_DEFAULT_TOTAL_FEE_BPS: u64 = 30;
pub const PUMPSWAP_DEFAULT_LP_FEE_BPS: u64 = 20;

static PUMPSWAP_PROG_PK: OnceLock<Pubkey> = OnceLock::new();
static PUMPSWAP_GLOBAL_PK: OnceLock<Pubkey> = OnceLock::new();
static PUMPSWAP_EVENT_AUTH_PK: OnceLock<Pubkey> = OnceLock::new();
static PUMPSWAP_FEE_CFG_PK: OnceLock<Pubkey> = OnceLock::new();
static PUMPSWAP_GLOBAL_VOL_PK: OnceLock<Pubkey> = OnceLock::new();
static PUMPSWAP_PROTO_FEE_PK: OnceLock<Pubkey> = OnceLock::new();

#[inline(always)]
pub fn pumpswap_program_id() -> Pubkey {
    *PUMPSWAP_PROG_PK.get_or_init(|| Pubkey::from_str(PUMPSWAP_PROGRAM_ID_STR).unwrap())
}

#[inline(always)]
pub fn pumpswap_global_config_pda() -> Pubkey {
    *PUMPSWAP_GLOBAL_PK.get_or_init(|| Pubkey::from_str(PUMPSWAP_GLOBAL_CONFIG_STR).unwrap())
}

#[inline(always)]
pub fn pumpswap_event_authority_pda() -> Pubkey {
    *PUMPSWAP_EVENT_AUTH_PK.get_or_init(|| Pubkey::from_str(PUMPSWAP_EVENT_AUTHORITY_STR).unwrap())
}

#[inline(always)]
pub fn pumpswap_fee_config_pda() -> Pubkey {
    *PUMPSWAP_FEE_CFG_PK.get_or_init(|| Pubkey::from_str(PUMPSWAP_FEE_CONFIG_STR).unwrap())
}

#[inline(always)]
pub fn pumpswap_global_volume_pda() -> Pubkey {
    *PUMPSWAP_GLOBAL_VOL_PK.get_or_init(|| {
        Pubkey::find_program_address(&[b"global_volume_accumulator"], &pumpswap_program_id()).0
    })
}

#[inline(always)]
pub fn default_pumpswap_proto_fee_recipient() -> Pubkey {
    *PUMPSWAP_PROTO_FEE_PK
        .get_or_init(|| Pubkey::from_str(DEFAULT_PUMPSWAP_PROTO_FEE_RECIPIENT_STR).unwrap())
}

#[inline]
pub fn derive_pumpswap_user_volume_pda(user: &Pubkey) -> Pubkey {
    Pubkey::find_program_address(
        &[b"user_volume_accumulator", user.as_ref()],
        &pumpswap_program_id(),
    )
    .0
}

#[inline]
pub fn derive_pumpswap_creator_vault_authority(coin_creator: &Pubkey) -> Pubkey {
    Pubkey::find_program_address(
        &[b"creator_vault", coin_creator.as_ref()],
        &pumpswap_program_id(),
    )
    .0
}

#[inline]
pub fn derive_pumpswap_pool_v2_pda(base_mint: &Pubkey) -> Pubkey {
    Pubkey::find_program_address(&[b"pool-v2", base_mint.as_ref()], &pumpswap_program_id()).0
}

/// SPL Token `SyncNative` (`[17]`) komutu: WSOL hesabına aktarılan native lamport'ları WSOL bakiyesine senkronlar.
#[inline]
pub fn build_sync_native_ix(wsol_ata: &Pubkey) -> Instruction {
    Instruction {
        program_id: spl_token_program_id(),
        accounts: vec![AccountMeta::new(*wsol_ata, false)],
        data: vec![17u8],
    }
}

// ============================================================================
// PUMPSWAP HAVUZ DURUMU (`Pool` 301B + Canlı Rezervler)
// ============================================================================

#[derive(Debug, Clone)]
pub struct PumpSwapPoolMeta {
    pub pool: Pubkey,
    pub base_mint: Pubkey,
    pub quote_mint: Pubkey,
    pub pool_base_token_account: Pubkey,
    pub pool_quote_token_account: Pubkey,
    pub coin_creator: Pubkey,
    pub base_token_program: Pubkey,
    pub is_mayhem_mode: bool,
    pub is_cashback_coin: bool,
    pub virtual_quote_reserves: u64,
    pub base_supply: u64,
    pub pool_base_reserves: u64,
    pub pool_quote_reserves: u64,
    pub protocol_fee_recipient: Pubkey,
    pub buyback_fee_recipient: Pubkey,
}

impl PumpSwapPoolMeta {
    /// Zincir üstü `Pool` (`301` bayt) verisini çözümler.
    pub fn from_pool_account_data(
        pool: Pubkey,
        base_token_program: Pubkey,
        pool_base_reserves: u64,
        pool_quote_reserves: u64,
        data: &[u8],
    ) -> Result<Self> {
        if data.len() < 245 || data[0..8] != PUMPSWAP_POOL_DISC {
            bail!(
                "Geçersiz PumpSwap Pool hesabı (uzunluk={} bayt)",
                data.len()
            );
        }
        let base_mint = Pubkey::new_from_array(data[43..75].try_into().unwrap());
        let quote_mint = Pubkey::new_from_array(data[75..107].try_into().unwrap());
        let pool_base_token_account = Pubkey::new_from_array(data[139..171].try_into().unwrap());
        let pool_quote_token_account = Pubkey::new_from_array(data[171..203].try_into().unwrap());
        let coin_creator = Pubkey::new_from_array(data[211..243].try_into().unwrap());
        let is_mayhem_mode = data[243] != 0;
        let is_cashback_coin = data[244] != 0;
        let virtual_quote_reserves = if data.len() >= 261 {
            let v = i128::from_le_bytes(data[245..261].try_into().unwrap());
            v.max(0) as u64
        } else {
            0
        };
        let base_supply = if is_mayhem_mode {
            2_000_000_000_000_000
        } else {
            1_000_000_000_000_000
        };
        let protocol_fee_recipient = if is_mayhem_mode {
            mayhem_reserved_fee_recipient()
        } else {
            default_pumpswap_proto_fee_recipient()
        };

        Ok(Self {
            pool,
            base_mint,
            quote_mint,
            pool_base_token_account,
            pool_quote_token_account,
            coin_creator,
            base_token_program,
            is_mayhem_mode,
            is_cashback_coin,
            virtual_quote_reserves,
            base_supply,
            pool_base_reserves,
            pool_quote_reserves,
            protocol_fee_recipient,
            buyback_fee_recipient: default_buyback_fee_recipient(),
        })
    }

    #[inline(always)]
    pub fn effective_quote_reserves(&self) -> u64 {
        self.pool_quote_reserves
            .saturating_add(self.virtual_quote_reserves)
    }

    /// Havuzun anlık Market Cap değerini lamport (SOL * 1e9) cinsinden döndürür.
    #[inline(always)]
    pub fn market_cap_lamports(&self) -> u64 {
        if self.pool_base_reserves == 0 {
            return 0;
        }
        let supply = if self.base_supply > 0 {
            self.base_supply
        } else {
            1_000_000_000_000_000
        };
        ((self.effective_quote_reserves() as u128 * supply as u128)
            / (self.pool_base_reserves as u128)) as u64
    }

    /// `spendable_quote_in` (lamport) ile alınacak tahmini token miktarı ve fiyat etkisi.
    pub fn quote_buy_exact_sol_in(&self, spendable_quote_in: u64) -> Option<(u64, f64)> {
        let eff_q = self.effective_quote_reserves() as u128;
        let b_res = self.pool_base_reserves as u128;
        if eff_q == 0 || b_res == 0 || spendable_quote_in == 0 {
            return None;
        }
        let net_q = (spendable_quote_in as u128 * 10_000u128)
            / (10_000u128 + PUMPSWAP_DEFAULT_TOTAL_FEE_BPS as u128);
        if net_q == 0 {
            return None;
        }
        let tokens_out = ((b_res * net_q) / (eff_q + net_q)) as u64;
        if tokens_out == 0 {
            return None;
        }
        let pre_price = eff_q as f64 / b_res as f64;
        let post_price = (eff_q + net_q) as f64 / (b_res.saturating_sub(tokens_out as u128).max(1)) as f64;
        let impact_pct = ((post_price - pre_price) / pre_price) * 100.0;
        Some((tokens_out, impact_pct))
    }

    /// `base_amount_in` token satıldığında ele geçecek net SOL (lamport) — `ERR 6063` real_vault tavan korumalı!
    pub fn quote_sell_tokens(&self, base_amount_in: u64) -> Option<u64> {
        let eff_q = self.effective_quote_reserves() as u128;
        let b_res = self.pool_base_reserves as u128;
        if eff_q == 0 || b_res == 0 || base_amount_in == 0 {
            return None;
        }
        let gross_q = ((eff_q * base_amount_in as u128) / (b_res + base_amount_in as u128)) as u64;
        let capped_q = gross_q.min(self.pool_quote_reserves);
        let fees = ((capped_q as u128 * PUMPSWAP_DEFAULT_TOTAL_FEE_BPS as u128) / 10_000u128) as u64;
        Some(capped_q.saturating_sub(fees))
    }
}

// ============================================================================
// 0-RPC İŞLEM İPUÇLARI (`PumpSwapTxHints`) — BALİNA İŞLEMİNDEN DOĞRUDAN ÇIKARILIR!
// ============================================================================

#[derive(Debug, Clone, Copy)]
pub struct PumpSwapTxHints {
    pub pool: Pubkey,
    pub base_mint: Pubkey,
    pub quote_mint: Pubkey,
    pub pool_base_token_account: Pubkey,
    pub pool_quote_token_account: Pubkey,
    pub base_token_program: Pubkey,
    pub protocol_fee_recipient: Pubkey,
    pub buyback_fee_recipient: Pubkey,
}

/// Geyser / Shred / RawTx içindeki bir PumpSwap komutundan (`v1` veya `v2`) havuz hesaplarını 0-RPC çıkarır!
pub fn extract_pumpswap_hints_from_ix(
    account_keys: &[Pubkey],
    ix_accounts: &[u8],
    ix_data: &[u8],
) -> Option<PumpSwapTxHints> {
    if ix_data.len() < 8 {
        return None;
    }
    let disc: [u8; 8] = ix_data[0..8].try_into().ok()?;
    let get_pk = |pos: usize| -> Option<Pubkey> {
        let idx = *ix_accounts.get(pos)? as usize;
        account_keys.get(idx).copied()
    };

    if disc == IX_PUMPSWAP_BUY || disc == IX_PUMPSWAP_BUY_EXACT_QUOTE_IN || disc == IX_PUMPSWAP_SELL
    {
        if ix_accounts.len() < 21 {
            return None;
        }
        let pool = get_pk(0)?;
        let base_mint = get_pk(3)?;
        let quote_mint = get_pk(4)?;
        let pool_base_token_account = get_pk(7)?;
        let pool_quote_token_account = get_pk(8)?;
        let protocol_fee_recipient = get_pk(9)?;
        let base_token_program = get_pk(11)?;
        // v1 remaining accounts son 2 hesap: [buyback_fee_recipient, buyback_fee_recipient_ata]
        let buyback_fee_recipient = if ix_accounts.len() >= 25
            || (disc == IX_PUMPSWAP_SELL && ix_accounts.len() >= 23)
        {
            get_pk(ix_accounts.len() - 2).unwrap_or_else(default_buyback_fee_recipient)
        } else {
            default_buyback_fee_recipient()
        };

        Some(PumpSwapTxHints {
            pool,
            base_mint,
            quote_mint,
            pool_base_token_account,
            pool_quote_token_account,
            base_token_program,
            protocol_fee_recipient,
            buyback_fee_recipient,
        })
    } else if disc == IX_PUMPSWAP_BUY_V2
        || disc == IX_PUMPSWAP_BUY_EXACT_QUOTE_IN_V2
        || disc == IX_PUMPSWAP_SELL_V2
    {
        if ix_accounts.len() < 17 {
            return None;
        }
        Some(PumpSwapTxHints {
            pool: get_pk(0)?,
            base_mint: get_pk(3)?,
            quote_mint: get_pk(4)?,
            pool_base_token_account: get_pk(7)?,
            pool_quote_token_account: get_pk(8)?,
            base_token_program: get_pk(9)?,
            protocol_fee_recipient: default_pumpswap_proto_fee_recipient(),
            buyback_fee_recipient: default_buyback_fee_recipient(),
        })
    } else {
        None
    }
}

// ============================================================================
// PUMPSWAP `BuyEvent` / `SellEvent` ÇÖZÜMLEYİCİ (0-RPC MCAP & REZERV HESABI!)
// ============================================================================

#[derive(Debug, Clone)]
pub struct ParsedPumpSwapTrade {
    pub pool: Pubkey,
    pub user: Pubkey,
    pub coin_creator: Pubkey,
    pub protocol_fee_recipient: Pubkey,
    pub is_buy: bool,
    pub sol_amount: u64,
    pub token_amount: u64,
    pub pre_pool_base_reserves: u64,
    pub pre_pool_quote_reserves: u64,
    pub post_pool_base_reserves: u64,
    pub post_pool_quote_reserves: u64,
    pub virtual_quote_reserves: u64,
    pub base_supply: u64,
    pub is_cashback_coin: bool,
}

impl ParsedPumpSwapTrade {
    /// Balina alım yapmadan TAM ÖNCEKİ Market Cap (lamport = SOL * 1e9)!
    #[inline]
    pub fn pre_trade_mcap_lamports(&self) -> u64 {
        if self.pre_pool_base_reserves == 0 {
            return 0;
        }
        let eff_q = self
            .pre_pool_quote_reserves
            .saturating_add(self.virtual_quote_reserves);
        let supply = if self.base_supply > 0 {
            self.base_supply
        } else {
            1_000_000_000_000_000
        };
        ((eff_q as u128 * supply as u128) / (self.pre_pool_base_reserves as u128)) as u64
    }

    /// İşlem SONRASI güncel Market Cap (lamport = SOL * 1e9)!
    #[inline]
    pub fn post_trade_mcap_lamports(&self) -> u64 {
        if self.post_pool_base_reserves == 0 {
            return 0;
        }
        let eff_q = self
            .post_pool_quote_reserves
            .saturating_add(self.virtual_quote_reserves);
        let supply = if self.base_supply > 0 {
            self.base_supply
        } else {
            1_000_000_000_000_000
        };
        ((eff_q as u128 * supply as u128) / (self.post_pool_base_reserves as u128)) as u64
    }

    pub fn from_raw_bytes(raw: &[u8]) -> Option<Self> {
        let payload = if raw.len() >= 16 && raw[0..8] == CPI_EVENT_IX_DISC {
            &raw[8..]
        } else {
            raw
        };
        if payload.len() < 8 {
            return None;
        }
        let disc: [u8; 8] = payload[0..8].try_into().ok()?;
        let body = &payload[8..];

        if disc == PUMPSWAP_BUY_EVENT_DISC {
            // BuyEvent minimum boyut:
            // 14 * 8 (112) + 7 * 32 (224) + 2 * 8 (16) = 352 bayt
            if body.len() < 352 {
                return None;
            }
            let base_amount_out = u64::from_le_bytes(body[8..16].try_into().ok()?);
            let pre_base = u64::from_le_bytes(body[32..40].try_into().ok()?);
            let pre_quote = u64::from_le_bytes(body[40..48].try_into().ok()?);
            let quote_in_with_lp = u64::from_le_bytes(body[88..96].try_into().ok()?);
            let user_quote_in = u64::from_le_bytes(body[96..104].try_into().ok()?);
            let pool = Pubkey::new_from_array(body[104..136].try_into().ok()?);
            let user = Pubkey::new_from_array(body[136..168].try_into().ok()?);
            let protocol_fee_recipient = Pubkey::new_from_array(body[232..264].try_into().ok()?);
            let coin_creator = Pubkey::new_from_array(body[296..328].try_into().ok()?);

            // Opsiyonel son alanlar (`ix_name: String` uzunluğuna göre dinamik offset!)
            let mut is_cashback_coin = false;
            let mut virtual_quote_reserves = 0u64;
            let mut base_supply = 1_000_000_000_000_000u64;

            // body[344..]: track_volume(1) + total_unclaimed(8) + total_claimed(8) + cur_sol_vol(8) + last_ts(8) + min_base(8) = 41 bayt -> offset 385'te ix_name (u32 len + utf8)!
            if body.len() >= 389 {
                let str_len = u32::from_le_bytes(body[385..389].try_into().ok()?) as usize;
                let tail = 389usize.saturating_add(str_len);
                // tail + 0..8: cashback_fee_bps, +8..16: cashback, +16..24: buyback_bps, +24..32: buyback_fee, +32..48: virtual_quote_reserves(i128), +48..49: can_boost, +49..57: base_supply(u64)
                if body.len() >= tail + 8 {
                    let cb_bps = u64::from_le_bytes(body[tail..tail + 8].try_into().ok()?);
                    is_cashback_coin = cb_bps > 0;
                }
                if body.len() >= tail + 48 {
                    let vq = i128::from_le_bytes(body[tail + 32..tail + 48].try_into().ok()?);
                    virtual_quote_reserves = vq.max(0) as u64;
                }
                if body.len() >= tail + 57 {
                    let sup = u64::from_le_bytes(body[tail + 49..tail + 57].try_into().ok()?);
                    if sup > 0 {
                        base_supply = sup;
                    }
                }
            }

            Some(Self {
                pool,
                user,
                coin_creator,
                protocol_fee_recipient,
                is_buy: true,
                sol_amount: user_quote_in,
                token_amount: base_amount_out,
                pre_pool_base_reserves: pre_base,
                pre_pool_quote_reserves: pre_quote,
                post_pool_base_reserves: pre_base.saturating_sub(base_amount_out),
                post_pool_quote_reserves: pre_quote.saturating_add(quote_in_with_lp),
                virtual_quote_reserves,
                base_supply,
                is_cashback_coin,
            })
        } else if disc == PUMPSWAP_SELL_EVENT_DISC {
            if body.len() < 344 {
                return None;
            }
            let base_amount_in = u64::from_le_bytes(body[8..16].try_into().ok()?);
            let pre_base = u64::from_le_bytes(body[32..40].try_into().ok()?);
            let pre_quote = u64::from_le_bytes(body[40..48].try_into().ok()?);
            let quote_out = u64::from_le_bytes(body[48..56].try_into().ok()?);
            let lp_fee = u64::from_le_bytes(body[64..72].try_into().ok()?);
            let user_quote_out = u64::from_le_bytes(body[96..104].try_into().ok()?);
            let pool = Pubkey::new_from_array(body[104..136].try_into().ok()?);
            let user = Pubkey::new_from_array(body[136..168].try_into().ok()?);
            let protocol_fee_recipient = Pubkey::new_from_array(body[232..264].try_into().ok()?);
            let coin_creator = Pubkey::new_from_array(body[296..328].try_into().ok()?);

            // SellEvent tail starts right at offset 344!
            let tail = 344usize;
            let mut is_cashback_coin = false;
            let mut virtual_quote_reserves = 0u64;
            let mut base_supply = 1_000_000_000_000_000u64;
            if body.len() >= tail + 8 {
                let cb_bps = u64::from_le_bytes(body[tail..tail + 8].try_into().ok()?);
                is_cashback_coin = cb_bps > 0;
            }
            if body.len() >= tail + 48 {
                let vq = i128::from_le_bytes(body[tail + 32..tail + 48].try_into().ok()?);
                virtual_quote_reserves = vq.max(0) as u64;
            }
            if body.len() >= tail + 57 {
                let sup = u64::from_le_bytes(body[tail + 49..tail + 57].try_into().ok()?);
                if sup > 0 {
                    base_supply = sup;
                }
            }

            let vault_out = quote_out.saturating_sub(lp_fee);
            Some(Self {
                pool,
                user,
                coin_creator,
                protocol_fee_recipient,
                is_buy: false,
                sol_amount: user_quote_out,
                token_amount: base_amount_in,
                pre_pool_base_reserves: pre_base,
                pre_pool_quote_reserves: pre_quote,
                post_pool_base_reserves: pre_base.saturating_add(base_amount_in),
                post_pool_quote_reserves: pre_quote.saturating_sub(vault_out),
                virtual_quote_reserves,
                base_supply,
                is_cashback_coin,
            })
        } else {
            None
        }
    }

    pub fn to_pool_meta(&self, hints: &PumpSwapTxHints) -> PumpSwapPoolMeta {
        let is_mayhem_mode = self.protocol_fee_recipient == mayhem_reserved_fee_recipient()
            || self.base_supply >= 1_500_000_000_000_000;
        PumpSwapPoolMeta {
            pool: self.pool,
            base_mint: hints.base_mint,
            quote_mint: hints.quote_mint,
            pool_base_token_account: hints.pool_base_token_account,
            pool_quote_token_account: hints.pool_quote_token_account,
            coin_creator: self.coin_creator,
            base_token_program: hints.base_token_program,
            is_mayhem_mode,
            is_cashback_coin: self.is_cashback_coin,
            virtual_quote_reserves: self.virtual_quote_reserves,
            base_supply: self.base_supply,
            pool_base_reserves: self.post_pool_base_reserves,
            pool_quote_reserves: self.post_pool_quote_reserves,
            protocol_fee_recipient: if is_mayhem_mode {
                mayhem_reserved_fee_recipient()
            } else {
                hints.protocol_fee_recipient
            },
            buyback_fee_recipient: hints.buyback_fee_recipient,
        }
    }
}

// ============================================================================
// SHREDSTREAM / RAW TX HIZLI PUMPSWAP BALİNA ALIM ÇÖZÜMLEYİCİ
// ============================================================================

#[derive(Debug, Clone)]
pub struct ParsedPumpSwapWhaleBuy {
    pub buyer: Pubkey,
    pub hints: PumpSwapTxHints,
    pub estimated_sol_in: u64,
}

pub fn parse_pumpswap_buy_tx(tx: &VersionedTransaction) -> Option<ParsedPumpSwapWhaleBuy> {
    let static_keys = tx.message.static_account_keys();
    if tx.message.address_table_lookups().is_some_and(|l| !l.is_empty()) {
        // ALT kullanan işlemlerde Geyser tam çözümlü anahtar listesini sağlar
    }
    let wsol = wsol_mint_id();
    let ps_prog = pumpswap_program_id();

    let ixs = match &tx.message {
        VersionedMessage::Legacy(m) => &m.instructions,
        VersionedMessage::V0(m) => &m.instructions,
    };

    for ix in ixs {
        let Some(prog_pk) = static_keys.get(ix.program_id_index as usize) else {
            continue;
        };
        if *prog_pk != ps_prog || ix.data.len() < 24 {
            continue;
        }
        let disc: [u8; 8] = ix.data[0..8].try_into().ok()?;
        let is_buy = disc == IX_PUMPSWAP_BUY
            || disc == IX_PUMPSWAP_BUY_EXACT_QUOTE_IN
            || disc == IX_PUMPSWAP_BUY_V2
            || disc == IX_PUMPSWAP_BUY_EXACT_QUOTE_IN_V2;
        if !is_buy {
            continue;
        }
        let hints = extract_pumpswap_hints_from_ix(static_keys, &ix.accounts, &ix.data)?;
        if hints.quote_mint != wsol {
            continue;
        }
        let buyer = *static_keys.get(*ix.accounts.get(1)? as usize)?;
        let arg0 = u64::from_le_bytes(ix.data[8..16].try_into().ok()?);
        let arg1 = u64::from_le_bytes(ix.data[16..24].try_into().ok()?);
        let estimated_sol_in =
            if disc == IX_PUMPSWAP_BUY_EXACT_QUOTE_IN || disc == IX_PUMPSWAP_BUY_EXACT_QUOTE_IN_V2 {
                arg0
            } else {
                arg1
            };
        return Some(ParsedPumpSwapWhaleBuy {
            buyer,
            hints,
            estimated_sol_in,
        });
    }
    None
}

// ============================================================================
// PUMPSWAP ATOMİK ALIM & SATIŞ KOMUT DİZİLERİ (%100 KİRA İADELİ — 0 WSOL ARTIK!)
// ============================================================================

/// PumpSwap üzerinde Native SOL ile atomik alım yapar ve aynı işlem içinde geçici WSOL hesabını kapatıp
/// WSOL kirasını (~0.00204 SOL) ve artan toz lamport'ları cüzdana geri iade eder!
pub fn build_pumpswap_atomic_buy_ixs(
    user: &Pubkey,
    meta: &PumpSwapPoolMeta,
    spendable_sol_lamports: u64,
    min_tokens_out: u64,
) -> Vec<Instruction> {
    let wsol = wsol_mint_id();
    let spl_prog = spl_token_program_id();
    let user_wsol_ata = derive_ata(user, &wsol, &spl_prog);
    let user_base_ata =
        derive_ata(user, &meta.base_mint, &meta.base_token_program);
    let proto_fee_ata =
        derive_ata(&meta.protocol_fee_recipient, &wsol, &spl_prog);
    let creator_vault_auth = derive_pumpswap_creator_vault_authority(&meta.coin_creator);
    let creator_vault_ata = derive_ata(&creator_vault_auth, &wsol, &spl_prog);
    let user_vol_pda = derive_pumpswap_user_volume_pda(user);
    let buyback_ata =
        derive_ata(&meta.buyback_fee_recipient, &wsol, &spl_prog);

    let mut accounts = Vec::with_capacity(27);
    accounts.push(AccountMeta::new(meta.pool, false)); // [0] pool
    accounts.push(AccountMeta::new(*user, true)); // [1] user
    accounts.push(AccountMeta::new_readonly(pumpswap_global_config_pda(), false)); // [2] global_config
    accounts.push(AccountMeta::new_readonly(meta.base_mint, false)); // [3] base_mint
    accounts.push(AccountMeta::new_readonly(wsol, false)); // [4] quote_mint
    accounts.push(AccountMeta::new(user_base_ata, false)); // [5] user_base_token_account
    accounts.push(AccountMeta::new(user_wsol_ata, false)); // [6] user_quote_token_account
    accounts.push(AccountMeta::new(meta.pool_base_token_account, false)); // [7] pool_base_token_account
    accounts.push(AccountMeta::new(meta.pool_quote_token_account, false)); // [8] pool_quote_token_account
    accounts.push(AccountMeta::new_readonly(meta.protocol_fee_recipient, false)); // [9] protocol_fee_recipient
    accounts.push(AccountMeta::new(proto_fee_ata, false)); // [10] protocol_fee_recipient_token_account
    accounts.push(AccountMeta::new_readonly(meta.base_token_program, false)); // [11] base_token_program
    accounts.push(AccountMeta::new_readonly(spl_prog, false)); // [12] quote_token_program
    accounts.push(AccountMeta::new_readonly(Pubkey::default(), false)); // [13] system_program
    accounts.push(AccountMeta::new_readonly(associated_token_program_id(), false)); // [14] associated_token_program
    accounts.push(AccountMeta::new_readonly(pumpswap_event_authority_pda(), false)); // [15] event_authority
    accounts.push(AccountMeta::new_readonly(pumpswap_program_id(), false)); // [16] program
    accounts.push(AccountMeta::new(creator_vault_ata, false)); // [17] coin_creator_vault_ata
    accounts.push(AccountMeta::new_readonly(creator_vault_auth, false)); // [18] coin_creator_vault_authority
    accounts.push(AccountMeta::new_readonly(pumpswap_global_volume_pda(), false)); // [19] global_volume_accumulator
    accounts.push(AccountMeta::new(user_vol_pda, false)); // [20] user_volume_accumulator
    accounts.push(AccountMeta::new_readonly(pumpswap_fee_config_pda(), false)); // [21] fee_config
    accounts.push(AccountMeta::new_readonly(pump_fee_program_id(), false)); // [22] fee_program

    // Remaining accounts (Kasım 2026 @pump-fun/pump-swap-sdk v2.2.0 birebir sırası):
    if meta.is_cashback_coin {
        let user_vol_wsol_ata = derive_ata(&user_vol_pda, &wsol, &spl_prog);
        accounts.push(AccountMeta::new(user_vol_wsol_ata, false));
    }
    if meta.coin_creator != Pubkey::default() {
        accounts.push(AccountMeta::new_readonly(
            derive_pumpswap_pool_v2_pda(&meta.base_mint),
            false,
        ));
    }
    accounts.push(AccountMeta::new_readonly(meta.buyback_fee_recipient, false));
    accounts.push(AccountMeta::new(buyback_ata, false));

    let mut data = Vec::with_capacity(25);
    data.extend_from_slice(&IX_PUMPSWAP_BUY_EXACT_QUOTE_IN);
    data.extend_from_slice(&spendable_sol_lamports.to_le_bytes());
    data.extend_from_slice(&min_tokens_out.max(1).to_le_bytes());
    data.push(1u8); // OptionBool(true) -> track_volume

    let swap_ix = Instruction {
        program_id: pumpswap_program_id(),
        accounts,
        data,
    };

    vec![
        create_ata_idempotent_with_ata_ix(user, user, &user_wsol_ata, &wsol, &spl_prog),
        solana_system_interface::instruction::transfer(user, &user_wsol_ata, spendable_sol_lamports),
        build_sync_native_ix(&user_wsol_ata),
        create_ata_idempotent_with_ata_ix(
            user,
            user,
            &user_base_ata,
            &meta.base_mint,
            &meta.base_token_program,
        ),
        swap_ix,
        // WSOL hesabını aynı işlemde kapat -> ~0.00204 SOL kira + artan lamport anında cüzdana döner!
        build_close_token_account_ix(&spl_prog, &user_wsol_ata, user, user),
    ]
}

/// PumpSwap üzerinde tüm tokenları satar, elde edilen WSOL'ü native SOL'a çevirir ve
/// HEM WSOL ATA'sını HEM DE Token ATA'sını kapatarak tüm kiraları (%100) cüzdana geri yatırır!
pub fn build_pumpswap_atomic_sell_ixs(
    user: &Pubkey,
    meta: &PumpSwapPoolMeta,
    base_amount_in: u64,
    min_quote_out: u64,
    close_base_ata: bool,
) -> Vec<Instruction> {
    let wsol = wsol_mint_id();
    let spl_prog = spl_token_program_id();
    let user_wsol_ata = derive_ata(user, &wsol, &spl_prog);
    let user_base_ata =
        derive_ata(user, &meta.base_mint, &meta.base_token_program);
    let proto_fee_ata =
        derive_ata(&meta.protocol_fee_recipient, &wsol, &spl_prog);
    let creator_vault_auth = derive_pumpswap_creator_vault_authority(&meta.coin_creator);
    let creator_vault_ata = derive_ata(&creator_vault_auth, &wsol, &spl_prog);
    let user_vol_pda = derive_pumpswap_user_volume_pda(user);
    let buyback_ata =
        derive_ata(&meta.buyback_fee_recipient, &wsol, &spl_prog);

    let mut accounts = Vec::with_capacity(26);
    accounts.push(AccountMeta::new(meta.pool, false)); // [0] pool
    accounts.push(AccountMeta::new(*user, true)); // [1] user
    accounts.push(AccountMeta::new_readonly(pumpswap_global_config_pda(), false)); // [2] global_config
    accounts.push(AccountMeta::new_readonly(meta.base_mint, false)); // [3] base_mint
    accounts.push(AccountMeta::new_readonly(wsol, false)); // [4] quote_mint
    accounts.push(AccountMeta::new(user_base_ata, false)); // [5] user_base_token_account
    accounts.push(AccountMeta::new(user_wsol_ata, false)); // [6] user_quote_token_account
    accounts.push(AccountMeta::new(meta.pool_base_token_account, false)); // [7] pool_base_token_account
    accounts.push(AccountMeta::new(meta.pool_quote_token_account, false)); // [8] pool_quote_token_account
    accounts.push(AccountMeta::new_readonly(meta.protocol_fee_recipient, false)); // [9] protocol_fee_recipient
    accounts.push(AccountMeta::new(proto_fee_ata, false)); // [10] protocol_fee_recipient_token_account
    accounts.push(AccountMeta::new_readonly(meta.base_token_program, false)); // [11] base_token_program
    accounts.push(AccountMeta::new_readonly(spl_prog, false)); // [12] quote_token_program
    accounts.push(AccountMeta::new_readonly(Pubkey::default(), false)); // [13] system_program
    accounts.push(AccountMeta::new_readonly(associated_token_program_id(), false)); // [14] associated_token_program
    accounts.push(AccountMeta::new_readonly(pumpswap_event_authority_pda(), false)); // [15] event_authority
    accounts.push(AccountMeta::new_readonly(pumpswap_program_id(), false)); // [16] program
    accounts.push(AccountMeta::new(creator_vault_ata, false)); // [17] coin_creator_vault_ata
    accounts.push(AccountMeta::new_readonly(creator_vault_auth, false)); // [18] coin_creator_vault_authority
    accounts.push(AccountMeta::new_readonly(pumpswap_fee_config_pda(), false)); // [19] fee_config
    accounts.push(AccountMeta::new_readonly(pump_fee_program_id(), false)); // [20] fee_program

    if meta.is_cashback_coin {
        let user_vol_wsol_ata = derive_ata(&user_vol_wsol_owner(&user_vol_pda), &wsol, &spl_prog);
        accounts.push(AccountMeta::new(user_vol_wsol_ata, false));
        accounts.push(AccountMeta::new(user_vol_pda, false));
    }
    if meta.coin_creator != Pubkey::default() {
        accounts.push(AccountMeta::new_readonly(
            derive_pumpswap_pool_v2_pda(&meta.base_mint),
            false,
        ));
    }
    accounts.push(AccountMeta::new_readonly(meta.buyback_fee_recipient, false));
    accounts.push(AccountMeta::new(buyback_ata, false));

    let mut data = Vec::with_capacity(24);
    data.extend_from_slice(&IX_PUMPSWAP_SELL);
    data.extend_from_slice(&base_amount_in.to_le_bytes());
    data.extend_from_slice(&min_quote_out.to_le_bytes());

    let sell_ix = Instruction {
        program_id: pumpswap_program_id(),
        accounts,
        data,
    };

    let mut ixs = Vec::with_capacity(4);
    ixs.push(create_ata_idempotent_with_ata_ix(
        user,
        user,
        &user_wsol_ata,
        &wsol,
        &spl_prog,
    ));
    ixs.push(sell_ix);
    ixs.push(build_close_token_account_ix(
        &spl_prog,
        &user_wsol_ata,
        user,
        user,
    ));
    if close_base_ata {
        ixs.push(build_close_token_account_ix(
            &meta.base_token_program,
            &user_base_ata,
            user,
            user,
        ));
    }
    ixs
}

#[inline(always)]
fn user_vol_wsol_owner(pda: &Pubkey) -> Pubkey {
    *pda
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::pump::token_2022_program_id;

    #[test]
    fn test_pumpswap_pdas_match_live_mainnet_tx() {
        // Canlı Mainnet işlemi `3i5iY23y...` üzerindeki adreslerle birebir doğrulama:
        let base_mint = Pubkey::from_str("6AfhF8NUoB3wbVGXGAdSVQ2sJYzqz2m8mGmFg4EBpump").unwrap();
        let coin_creator =
            Pubkey::from_str("BNzFabBRGB8xnVCuxGZuvDgPgxxPvrZBWUAywFbNPQ7X").unwrap();

        let pool_v2 = derive_pumpswap_pool_v2_pda(&base_mint);
        assert_eq!(
            pool_v2.to_string(),
            "AGJcm91kArfrFZ7Wdbu84Co1MaAYoN37wXVGEdTcNQD8"
        );

        let cv_auth = derive_pumpswap_creator_vault_authority(&coin_creator);
        assert_eq!(
            cv_auth.to_string(),
            "BrZJ5enUxyZxYJGzk1gftqf6Cuw4d1fwQM7V4bHtgU2"
        );

        let cv_ata =
            derive_ata(&cv_auth, &wsol_mint_id(), &spl_token_program_id());
        assert_eq!(
            cv_ata.to_string(),
            "1YwSdZjEssnpRLLm6FjHH8vtuaKJEu3DNJiNvtxY1S3"
        );

        let bb_wallet = Pubkey::from_str("5eHhjP8JaYkz83CWwvGU2uMUXefd3AazWGx4gpcuEEYD").unwrap();
        let bb_ata = derive_ata(
            &bb_wallet,
            &wsol_mint_id(),
            &spl_token_program_id(),
        );
        assert_eq!(
            bb_ata.to_string(),
            "CASRL2zkwDnppxEFQ4LgdwgR9pdz5Q8R8nEMKVZ9QoLp"
        );
    }

    #[test]
    fn test_pumpswap_mcap_and_atomic_ixs() {
        let user = Pubkey::new_unique();
        let meta = PumpSwapPoolMeta {
            pool: Pubkey::new_unique(),
            base_mint: Pubkey::new_unique(),
            quote_mint: wsol_mint_id(),
            pool_base_token_account: Pubkey::new_unique(),
            pool_quote_token_account: Pubkey::new_unique(),
            coin_creator: Pubkey::new_unique(),
            base_token_program: token_2022_program_id(),
            is_mayhem_mode: false,
            is_cashback_coin: false,
            virtual_quote_reserves: 0,
            base_supply: 1_000_000_000_000_000,
            pool_base_reserves: 200_000_000_000_000, // 200M token havuzda
            pool_quote_reserves: 90_000_000_000,     // 90 SOL havuzda -> MCAP = 450 SOL (~$32.3k @ $71.85)
            protocol_fee_recipient: default_pumpswap_proto_fee_recipient(),
            buyback_fee_recipient: default_buyback_fee_recipient(),
        };

        assert_eq!(meta.market_cap_lamports(), 450_000_000_000);
        let (tok_out, impact) = meta.quote_buy_exact_sol_in(1_000_000).unwrap();
        assert!(tok_out > 0 && impact < 1.0);

        let buy_ixs = build_pumpswap_atomic_buy_ixs(&user, &meta, 1_000_000, tok_out);
        assert_eq!(buy_ixs.len(), 6); // CreateWSOL + Transfer + SyncNative + CreateBaseATA + BuyExactQuoteIn + CloseWSOL
        assert_eq!(buy_ixs[4].accounts.len(), 26); // 23 base + pool_v2 + buyback + buyback_ata

        let sell_ixs = build_pumpswap_atomic_sell_ixs(&user, &meta, tok_out, 900_000, true);
        assert_eq!(sell_ixs.len(), 4); // CreateWSOL + Sell + CloseWSOL + CloseBaseATA
    }
}
