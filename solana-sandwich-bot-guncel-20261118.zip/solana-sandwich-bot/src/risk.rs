use dashmap::DashMap;
use parking_lot::Mutex;
use solana_pubkey::Pubkey;
use std::time::{Duration, Instant};
use tracing::warn;

/// Kayar pencereli (sliding window) ve otomatik soğuma (half-open recovery) destekli Circuit Breaker.
pub struct CircuitBreaker {
    max_errors: usize,
    window: Duration,
    cooldown: Duration,
    state: Mutex<BreakerInner>,
}

struct BreakerInner {
    errors: Vec<Instant>,
    opened_at: Option<Instant>,
}

impl CircuitBreaker {
    pub fn new(max_errors_per_minute: u32) -> Self {
        Self {
            max_errors: max_errors_per_minute.max(1) as usize,
            window: Duration::from_secs(60),
            cooldown: Duration::from_secs(45),
            state: Mutex::new(BreakerInner {
                errors: Vec::new(),
                opened_at: None,
            }),
        }
    }

    pub fn is_open(&self) -> bool {
        let mut guard = self.state.lock();
        if let Some(opened) = guard.opened_at {
            if opened.elapsed() >= self.cooldown {
                // Soğuma süresi doldu, devreyi tekrar kapat
                guard.opened_at = None;
                guard.errors.clear();
                false
            } else {
                true
            }
        } else {
            false
        }
    }

    pub fn record_error(&self) {
        let mut guard = self.state.lock();
        let now = Instant::now();
        let window = self.window;
        guard.errors.retain(|t| now.duration_since(*t) < window);
        guard.errors.push(now);

        if guard.errors.len() >= self.max_errors && guard.opened_at.is_none() {
            guard.opened_at = Some(now);
            warn!(
                "DEVRE KESİCİ (Circuit Breaker) AÇILDI: Son 60 saniyede {} hata oluştu, 45 sn bekleniyor.",
                guard.errors.len()
            );
        }
    }

    pub fn record_success(&self) {
        let mut guard = self.state.lock();
        let now = Instant::now();
        let window = self.window;
        guard.errors.retain(|t| now.duration_since(*t) < window);
    }
}

#[derive(Debug, Clone, Copy, Default)]
pub struct PnLSnapshot {
    pub total_profit_lamports: i64,
    pub daily_loss_lamports: u64,
    pub total_trades: u64,
    pub winning_trades: u64,
}

impl PnLSnapshot {
    pub fn win_rate_pct(&self) -> f64 {
        if self.total_trades == 0 {
            0.0
        } else {
            (self.winning_trades as f64 / self.total_trades as f64) * 100.0
        }
    }
}

pub struct PnLTracker {
    inner: Mutex<PnLInner>,
}

struct PnLInner {
    total_profit_lamports: i64,
    daily_loss_lamports: u64,
    total_trades: u64,
    winning_trades: u64,
    day_started: Instant,
}

impl Default for PnLTracker {
    fn default() -> Self {
        Self::new()
    }
}

impl PnLTracker {
    pub fn new() -> Self {
        Self {
            inner: Mutex::new(PnLInner {
                total_profit_lamports: 0,
                daily_loss_lamports: 0,
                total_trades: 0,
                winning_trades: 0,
                day_started: Instant::now(),
            }),
        }
    }

    pub fn record_trade(&self, net_profit_lamports: i64) {
        let mut g = self.inner.lock();
        if g.day_started.elapsed() >= Duration::from_secs(86_400) {
            g.daily_loss_lamports = 0;
            g.day_started = Instant::now();
        }

        g.total_profit_lamports += net_profit_lamports;
        g.total_trades += 1;
        if net_profit_lamports > 0 {
            g.winning_trades += 1;
        } else if net_profit_lamports < 0 {
            g.daily_loss_lamports = g
                .daily_loss_lamports
                .saturating_add(net_profit_lamports.unsigned_abs());
        }
    }

    pub fn is_daily_loss_exceeded(&self, max_daily_loss_lamports: u64) -> bool {
        let mut g = self.inner.lock();
        if g.day_started.elapsed() >= Duration::from_secs(86_400) {
            g.daily_loss_lamports = 0;
            g.day_started = Instant::now();
        }
        g.daily_loss_lamports >= max_daily_loss_lamports
    }

    pub fn snapshot(&self) -> PnLSnapshot {
        let g = self.inner.lock();
        PnLSnapshot {
            total_profit_lamports: g.total_profit_lamports,
            daily_loss_lamports: g.daily_loss_lamports,
            total_trades: g.total_trades,
            winning_trades: g.winning_trades,
        }
    }
}

/// Aynı token'a üst üste girilmesini ve aynı imzanın iki kez işlenmesini engelleyen koruma tablosu.
pub struct CooldownGuard {
    mint_last_seen: DashMap<Pubkey, Instant>,
    seen_signatures: DashMap<String, Instant>,
}

impl Default for CooldownGuard {
    fn default() -> Self {
        Self::new()
    }
}

impl CooldownGuard {
    pub fn new() -> Self {
        Self {
            mint_last_seen: DashMap::new(),
            seen_signatures: DashMap::new(),
        }
    }

    pub fn check_and_mark_signature(&self, sig: &str) -> bool {
        if self.seen_signatures.len() > 10_000 {
            let cutoff = Duration::from_secs(120);
            self.seen_signatures.retain(|_, ts| ts.elapsed() < cutoff);
        }
        if self.seen_signatures.contains_key(sig) {
            return false;
        }
        self.seen_signatures.insert(sig.to_string(), Instant::now());
        true
    }

    pub fn check_and_mark_mint(&self, mint: &Pubkey, cooldown: Duration) -> bool {
        let now = Instant::now();
        if let Some(prev) = self.mint_last_seen.get(mint) {
            if now.duration_since(*prev) < cooldown {
                return false;
            }
        }
        self.mint_last_seen.insert(*mint, now);
        true
    }
}

pub fn lamports_to_sol_str(lamports: u64) -> String {
    format!("{:.6} SOL", lamports as f64 / 1e9)
}

pub fn signed_lamports_to_sol_str(lamports: i64) -> String {
    format!("{:+.6} SOL", lamports as f64 / 1e9)
}
