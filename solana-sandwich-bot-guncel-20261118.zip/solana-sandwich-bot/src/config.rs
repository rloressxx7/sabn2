use anyhow::{bail, Context, Result};
use serde::{Deserialize, Serialize};
use solana_keypair::Keypair;
use solana_pubkey::Pubkey;
use std::fs;
use std::path::{Path, PathBuf};
use std::str::FromStr;

use crate::pump::MAYHEM_AGENT_WALLET_STR;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Deserialize, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum BotMode {
    Momentum,
    Sandwich,
    Hybrid,
}

impl BotMode {
    pub fn runs_momentum(self) -> bool {
        matches!(self, BotMode::Momentum | BotMode::Hybrid)
    }

    pub fn runs_sandwich(self) -> bool {
        matches!(self, BotMode::Sandwich | BotMode::Hybrid)
    }
}

impl FromStr for BotMode {
    type Err = anyhow::Error;

    fn from_str(s: &str) -> Result<Self> {
        match s.trim().to_ascii_lowercase().as_str() {
            "momentum" | "backrun" | "helius" | "shred" | "grpc" | "mayhem" => {
                Ok(BotMode::Momentum)
            }
            "sandwich" | "atomic" => Ok(BotMode::Sandwich),
            "hybrid" | "both" => Ok(BotMode::Hybrid),
            other => bail!(
                "Geçersiz çalışma modu '{}'. Geçerli değerler: momentum | sandwich | hybrid",
                other
            ),
        }
    }
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct AppConfig {
    pub mode: ModeConfig,
    pub network: NetworkConfig,
    pub jito: JitoConfig,
    pub wallet: WalletConfig,
    pub strategy: StrategyConfig,
    #[serde(default)]
    pub whale: WhaleConfig,
    #[serde(default)]
    pub mayhem: MayhemConfig,
    pub risk: RiskConfig,
    pub logging: LoggingConfig,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct ModeConfig {
    pub strategy: BotMode,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct NetworkConfig {
    /// Birincil RPC HTTP endpoint (geriye dönük uyumluluk için korunuyor)
    pub rpc_http: String,
    /// Birden fazla RPC HTTP endpoint (failover/round-robin). Boşsa `rpc_http` tek başına kullanılır.
    #[serde(default)]
    pub rpc_endpoints: Vec<String>,
    #[serde(default)]
    pub rpc_ws: Option<String>,
    /// AllenHark / Yellowstone Geyser gRPC adresi (Frankfurt: "http://88.216.36.108:10001")
    #[serde(default)]
    pub geyser_grpc_url: Option<String>,
    #[serde(default)]
    pub geyser_x_token: Option<String>,
    /// AllenHark ShredStream ("http://185.191.117.89:9090") veya local `allenhark-shredstream-proxy`
    #[serde(default)]
    pub shredstream_grpc_url: Option<String>,
    #[serde(default)]
    pub shredstream_api_key: Option<String>,
    /// Opsiyonel AllenHark 0.1ms Relay ("https://fra.relay.allenhark.com/v1/sendTx")
    #[serde(default)]
    pub allenhark_relay_url: Option<String>,
    #[serde(default)]
    pub allenhark_relay_api_key: Option<String>,
    /// Opsiyonel pre-execution raw tx WebSocket (3'lü Atomik Sandwich için)
    #[serde(default)]
    pub raw_tx_ws: Option<String>,
    /// DİKKAT: `false` (ÖNERİLEN) olduğunda işlemler YALNIZCA Jito Atomik Bundle (`bundleOnly=true` + `sendBundle`)
    /// üzerinden gider -> Başarısız işlem ZİNCİRE HİÇ YAZILMAZ, 0 SOL gas yanar, Solscan'de 0 hata olur!
    #[serde(default = "default_false")]
    pub dual_send_momentum: bool,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct JitoConfig {
    pub block_engine_urls: Vec<String>,
    #[serde(default)]
    pub uuid: Option<String>,
    pub tip_accounts: Vec<String>,
    /// Taban Jito bahşişi (lamports; Jito min 1_000, 0.001 SOL canlı test için 10_000 = 0.00001 SOL idealdir)
    pub tip_lamports: u64,
    /// Sandwich gibi net kârı belli işlemlerde beklenen brüt kârın yüzde kaçı dinamik tip verilsin (bps; 2000 = %20)
    #[serde(default = "default_tip_share_bps")]
    pub dynamic_tip_profit_share_bps: u16,
    /// Dinamik Jito bahşişi üst sınırı (lamports)
    #[serde(default = "default_max_tip_lamports")]
    pub max_tip_lamports: u64,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct WalletConfig {
    pub keypair_path: String,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct StrategyConfig {
    /// Genel balinalar için minimum alım eşiği (`mayhem.only_mayhem_buys = false` yapılırsa devreye girer)
    pub target_min_buy_sol: f64,
    pub position_sol: f64,
    pub max_position_sol: f64,
    pub buy_slippage_bps: u16,
    pub sell_slippage_bps: u16,
    pub take_profit_bps: u16,
    pub stop_loss_bps: u16,
    pub trailing_stop_bps: u16,
    pub max_hold_seconds: u64,
    pub min_sandwich_profit_lamports: u64,
    pub compute_unit_limit: u32,
    pub compute_unit_price_micro_lamports: u64,
    /// 0-RPC Hızlı Giriş: Geyser / ShredStream paketinden <0.06 ms içinde imzalayıp ateşler
    #[serde(default = "default_true")]
    pub zero_rpc_fast_entry: bool,
    /// Satış anında boşalan Token-2022 / SPL ATA hesabını aynı atomik işlemde kapatıp ~0.00204–0.00207 SOL kirayı iade eder!
    #[serde(default = "default_true")]
    pub auto_close_ata_reclaim_rent: bool,
    /// Take-Profit ve Trailing-Stop satışlarında tüm masraflar dahil başa-baş (break-even) altına inmeyi zincir üstünde yasaklar!
    #[serde(default = "default_true")]
    pub strict_profit_lock_tp: bool,
}

/// `$10,000 – $50,000` USD Market Cap (MCAP) Tokenlarda `>= 5.0 SOL` Alım Yapan Balina Hedefleme Ayarları
/// Hem Pump.fun Bonding Curve (`$10k – ~$29.5k`) hem de mezun olmuş PumpSwap AMM (`~$29.5k – $50k`) havuzlarını kapsar!
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct WhaleConfig {
    /// Balina (`$10k–$50k` USD MCAP + `>= 5 SOL` alım) hedefleme motoru aktif mi?
    #[serde(default = "default_true")]
    pub enabled: bool,
    /// Hedeflenen kişinin tek işlemde yapması gereken MİNİMUM alım tutarı (SOL) — Varsayılan: `5.0 SOL`
    #[serde(default = "default_min_whale_buy_sol")]
    pub min_whale_buy_sol: f64,
    /// Tokenın alım anındaki MİNİMUM Market Cap değeri (USD) — Varsayılan: `$10,000`
    #[serde(default = "default_min_whale_mcap_usd")]
    pub min_mcap_usd: f64,
    /// Tokenın alım anındaki MAKSİMUM Market Cap değeri (USD) — Varsayılan: `$50,000`
    #[serde(default = "default_max_whale_mcap_usd")]
    pub max_mcap_usd: f64,
    /// Mezuniyet öncesi Pump.fun Bonding Curve (`6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P`) üzerinde işlem aç
    #[serde(default = "default_true")]
    pub trade_pump_bonding_curve: bool,
    /// Mezuniyet sonrası PumpSwap AMM (`pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA`) üzerinde işlem aç
    #[serde(default = "default_true")]
    pub trade_pumpswap_amm: bool,
    /// Resmi Mayhem AI botunu balina sayma (`true` = sadece gerçek insanların / balinaların `>= 5 SOL` alımlarına gir)
    #[serde(default = "default_true")]
    pub ignore_mayhem_bot_as_whale: bool,
    /// Bizi pozisyona sokan `>= 5 SOL` balina cüzdanı aynı coin'de SATIŞ yaparsa beklemeden anında atomik çık + kira iadesi al!
    #[serde(default = "default_true")]
    pub instant_exit_on_whale_sell: bool,
    /// Pre-execution (`raw_tx_ws`) akışı varsa `jitodontfront` kullanmayan `>= 5 SOL` balinaların ÖNÜNE geç (Sandwich / 2-Tx Front-Run)
    #[serde(default = "default_true")]
    pub frontrun_via_jito_bundle: bool,
    /// Canlı Coinbase/Kraken SOL/USD API'sine ulaşılamazsa kullanılacak yedek SOL/USD kuru
    #[serde(default = "default_fallback_sol_usd")]
    pub fallback_sol_usd: f64,
}

impl Default for WhaleConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            min_whale_buy_sol: 5.0,
            min_mcap_usd: 10_000.0,
            max_mcap_usd: 50_000.0,
            trade_pump_bonding_curve: true,
            trade_pumpswap_amm: true,
            ignore_mayhem_bot_as_whale: true,
            instant_exit_on_whale_sell: true,
            frontrun_via_jito_bundle: true,
            fallback_sol_usd: 71.85,
        }
    }
}

impl WhaleConfig {
    #[inline(always)]
    pub fn min_buy_lamports(&self) -> u64 {
        (self.min_whale_buy_sol * 1_000_000_000.0).round() as u64
    }
}

/// Mayhem Bot giriş zamanlaması modu:
/// - `on_mayhem_buy`         : Mayhem Bot `0.20 – 1.00 SOL` MCAP aralığında ALIM yaptığı anda girer
///                             (Eğer `raw_tx_ws` pre-execution akışı bağlıysa 2-Tx Jito Bundle ile Mayhem'in ÖNÜNE geçer!)
/// - `before_mayhem_buy_dip` : AllenHark Geyser gRPC ile Mayhem Bot üst üste satış yapıp MCAP'i `0.20 – 1.00 SOL`
///                             dibine indirdiğinde, Mayhem Bot'un bir sonraki alımından ÖNCE dipten ön-alım yapar!
/// - `hybrid_both`           : Hem `raw_tx_ws` Jito Front-Run + Onaylı Mayhem Alımı hem de Dip Ön-Alım modunu birlikte çalıştırır.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Deserialize, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum MayhemEntryMode {
    OnMayhemBuy,
    BeforeMayhemBuyDip,
    HybridBoth,
}

impl Default for MayhemEntryMode {
    fn default() -> Self {
        Self::OnMayhemBuy
    }
}

impl MayhemEntryMode {
    #[inline]
    pub fn triggers_on_confirmed_buy(self) -> bool {
        matches!(self, Self::OnMayhemBuy | Self::HybridBoth)
    }

    #[inline]
    pub fn triggers_on_dip_before_buy(self) -> bool {
        matches!(self, Self::BeforeMayhemBuyDip | Self::HybridBoth)
    }
}

/// Pump.fun Resmi Mayhem Mode AI Trading Bot (`BwWK17cbHxwWBKZkUYvzxLcNQ1YVyaFezduWbtm2de6s`)
/// `0.20 SOL – 1.00 SOL` Market Cap (MCAP) Hedefleme ve Ön-Alım (Front-Run / Pre-Buy) Ayarları
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct MayhemConfig {
    /// Mayhem Bot hedefleme ve Mayhem eğrilerinde (`GesfTA3X...` + `Token-2022`) işlem açma kilidi
    #[serde(default = "default_true")]
    pub enabled: bool,
    /// `true` olduğunda bot YALNIZCA Pump.fun Mayhem Bot işlemlerine göre (`[min_mcap_sol, max_mcap_sol]` MCAP aralığında) ateşler!
    #[serde(default = "default_true")]
    pub only_mayhem_buys: bool,
    /// Giriş zamanlaması: `"on_mayhem_buy"` | `"before_mayhem_buy_dip"` | `"hybrid_both"`
    #[serde(default)]
    pub entry_mode: MayhemEntryMode,
    /// Mayhem Bot alım yaptığında coin'in sahip olması gereken MİNİMUM Market Cap (SOL) — Varsayılan: `0.20 SOL`
    #[serde(default = "default_min_mcap_sol")]
    pub min_mcap_sol: f64,
    /// Mayhem Bot alım yaptığında coin'in sahip olması gereken MAKSİMUM Market Cap (SOL) — Varsayılan: `1.00 SOL`
    #[serde(default = "default_max_mcap_sol")]
    pub max_mcap_sol: f64,
    /// Market Cap hesabında `false` = Pump.fun standart 1 Milyar eğri arzı (`bc.token_total_supply`),
    /// `true` = Token-2022 2 Milyar Mayhem toplam arzı (FDV) kullanılır.
    #[serde(default = "default_false")]
    pub use_2b_supply_for_mcap: bool,
    /// Mayhem Bot alımının dikkate alınması için minimum alım büyüklüğü (SOL; `0.0` = tüm Mayhem alımlarını yakala)
    #[serde(default = "default_zero_f64")]
    pub min_mayhem_buy_sol: f64,
    /// Pre-execution akışı (`raw_tx_ws`) bağlıysa Mayhem Bot'un imzalı alım işleminin ÖNÜNE
    /// `[Tx1: Bizim Alım (+jitodontfront), Tx2: Mayhem Bot Alımı]` şeklinde 2-Tx Jito Atomik Front-Run paketi koyar!
    #[serde(default = "default_true")]
    pub frontrun_via_jito_bundle: bool,
    /// `before_mayhem_buy_dip` modunda: Mayhem Bot `0.20–1.00 SOL` MCAP bölgesinde üst üste kaç satış yaptığında
    /// onun bir sonraki alımından ÖNCE dipten ön-alım yapılsın? (Varsayılan: `2`)
    #[serde(default = "default_dip_sells")]
    pub dip_consecutive_sells: u8,
    /// `on_mayhem_buy` ile girilmiş açık pozisyonda Mayhem Bot aynı coin'de SATIŞ yaparsa anında atomik çıkış + kira iadesi yapar!
    #[serde(default = "default_true")]
    pub instant_exit_on_mayhem_sell: bool,
    /// İzlenen resmi Pump.fun Mayhem AI Agent cüzdan adresleri
    #[serde(default = "default_mayhem_wallets")]
    pub mayhem_agent_wallets: Vec<String>,
}

impl Default for MayhemConfig {
    fn default() -> Self {
        Self {
            enabled: false,
            only_mayhem_buys: false,
            entry_mode: MayhemEntryMode::OnMayhemBuy,
            min_mcap_sol: 0.20,
            max_mcap_sol: 1.00,
            use_2b_supply_for_mcap: false,
            min_mayhem_buy_sol: 0.0,
            frontrun_via_jito_bundle: true,
            dip_consecutive_sells: 2,
            instant_exit_on_mayhem_sell: true,
            mayhem_agent_wallets: default_mayhem_wallets(),
        }
    }
}

impl MayhemConfig {
    #[inline]
    pub fn min_mcap_lamports(&self) -> u64 {
        (self.min_mcap_sol * 1_000_000_000.0).round() as u64
    }

    #[inline]
    pub fn max_mcap_lamports(&self) -> u64 {
        (self.max_mcap_sol * 1_000_000_000.0).round() as u64
    }

    #[inline]
    pub fn min_buy_lamports(&self) -> u64 {
        (self.min_mayhem_buy_sol * 1_000_000_000.0).round() as u64
    }

    /// Coin'in Market Cap (MCAP) değerinin `[min_mcap_sol, max_mcap_sol]` (`0.20 SOL ..= 1.00 SOL`)
    /// aralığında olup olmadığını 1-nanosaniye tam sayı karşılaştırmasıyla kontrol eder!
    #[inline]
    pub fn is_mcap_in_window(&self, mcap_lamports: u64) -> bool {
        mcap_lamports >= self.min_mcap_lamports() && mcap_lamports <= self.max_mcap_lamports()
    }
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct RiskConfig {
    pub simulate_before_submit: bool,
    pub max_price_impact_pct: f64,
    pub max_curve_fill_pct: f64,
    pub max_concurrent_positions: usize,
    pub max_daily_loss_sol: f64,
    pub cooldown_per_mint_secs: u64,
    pub max_errors_per_minute: u32,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct LoggingConfig {
    pub level: String,
    pub log_dir: String,
}

fn default_true() -> bool {
    true
}
fn default_false() -> bool {
    false
}
fn default_tip_share_bps() -> u16 {
    2_000
}
fn default_max_tip_lamports() -> u64 {
    5_000_000
}
fn default_min_whale_buy_sol() -> f64 {
    5.0
}
fn default_min_whale_mcap_usd() -> f64 {
    10_000.0
}
fn default_max_whale_mcap_usd() -> f64 {
    50_000.0
}
fn default_fallback_sol_usd() -> f64 {
    71.85
}
fn default_min_mcap_sol() -> f64 {
    0.20
}
fn default_max_mcap_sol() -> f64 {
    1.00
}
fn default_zero_f64() -> f64 {
    0.0
}
fn default_dip_sells() -> u8 {
    2
}
fn default_mayhem_wallets() -> Vec<String> {
    vec![MAYHEM_AGENT_WALLET_STR.to_string()]
}

fn clean_opt(opt: &mut Option<String>) {
    if opt.as_deref().map(|s| s.trim().is_empty()).unwrap_or(false) {
        *opt = None;
    }
}

impl Default for AppConfig {
    fn default() -> Self {
        Self {
            mode: ModeConfig {
                strategy: BotMode::Hybrid,
            },
            network: NetworkConfig {
                rpc_http: "https://mainnet.helius-rpc.com/?api-key=YOUR_HELIUS_KEY".to_string(),
                rpc_endpoints: vec![],
                rpc_ws: None,
                geyser_grpc_url: Some("http://88.216.36.108:10001".to_string()),
                geyser_x_token: None,
                shredstream_grpc_url: None,
                shredstream_api_key: None,
                allenhark_relay_url: None,
                allenhark_relay_api_key: None,
                raw_tx_ws: None,
                dual_send_momentum: false, // %100 Jito Atomik Revert Koruması (0 Hata, 0 Boşa Gas)
            },
            jito: JitoConfig {
                block_engine_urls: vec![
                    "https://frankfurt.mainnet.block-engine.jito.wtf/api/v1/bundles".to_string(),
                    "https://amsterdam.mainnet.block-engine.jito.wtf/api/v1/bundles".to_string(),
                    "https://london.mainnet.block-engine.jito.wtf/api/v1/bundles".to_string(),
                    "https://mainnet.block-engine.jito.wtf/api/v1/bundles".to_string(),
                ],
                uuid: None,
                tip_accounts: vec![
                    "96gYZGLnJYVFmbjzopPSU6QiEV5fGqZNyN9nmNhvrZU5".to_string(),
                    "HFqU5x63VTqvQss8hp11i4wVV8bD44PvwucfZ2bU7gRe".to_string(),
                    "Cw8CFyM9FkoMi7K7Crf6HNQqf4uEMzpKw6QNghXLvLkY".to_string(),
                    "ADaUMid9yfUytqMBgopwjb2DTLSokTSzL1zt6iGPaS49".to_string(),
                    "DfXygSm4jCyNCybVYYK6DwvWqjKee8pbDmJGcLWNDXjh".to_string(),
                    "ADuUkR4vqLUMWXxW9gh6D6L8pMSawimctcNZ5pGwDcEt".to_string(),
                    "DttWaMuVvTiduZRnguLF7jNxTgiMBZ1hyAumKUiL2KRL".to_string(),
                    "3AVi9Tg9Uo68tJfuvoKvqKNWKkC5wPdSSdeBnizKZ6jT".to_string(),
                ],
                tip_lamports: 10_000,
                dynamic_tip_profit_share_bps: 2_000,
                max_tip_lamports: 5_000_000,
            },
            wallet: WalletConfig {
                keypair_path: "~/.config/solana/id.json".to_string(),
            },
            strategy: StrategyConfig {
                target_min_buy_sol: 5.0,
                position_sol: 0.001,
                max_position_sol: 0.5,
                buy_slippage_bps: 250,
                sell_slippage_bps: 250,
                take_profit_bps: 700,
                stop_loss_bps: 400,
                trailing_stop_bps: 250,
                max_hold_seconds: 25,
                min_sandwich_profit_lamports: 50_000,
                compute_unit_limit: 240_000, // Pump 18-hesap + PumpSwap WSOL Wrap/Unwrap + CloseAccount için ideal
                compute_unit_price_micro_lamports: 1_000,
                zero_rpc_fast_entry: true,
                auto_close_ata_reclaim_rent: true,
                strict_profit_lock_tp: true,
            },
            whale: WhaleConfig::default(),
            mayhem: MayhemConfig::default(),
            risk: RiskConfig {
                simulate_before_submit: false,
                max_price_impact_pct: 8.0,
                max_curve_fill_pct: 92.0,
                max_concurrent_positions: 1,
                max_daily_loss_sol: 0.02,
                cooldown_per_mint_secs: 60,
                max_errors_per_minute: 20,
            },
            logging: LoggingConfig {
                level: "info".to_string(),
                log_dir: "logs".to_string(),
            },
        }
    }
}

impl AppConfig {
    pub fn load(path: impl AsRef<Path>) -> Result<Self> {
        let expanded = expand_tilde_path(path.as_ref());
        let raw = fs::read_to_string(&expanded).with_context(|| {
            format!(
                "Yapılandırma dosyası okunamadı: {}",
                expanded.to_string_lossy()
            )
        })?;
        let mut cfg: Self = toml::from_str(&raw).with_context(|| {
            format!(
                "TOML yapılandırma dosyası ayrıştırılamadı: {}",
                expanded.to_string_lossy()
            )
        })?;

        clean_opt(&mut cfg.network.rpc_ws);
        clean_opt(&mut cfg.network.geyser_grpc_url);
        clean_opt(&mut cfg.network.geyser_x_token);
        clean_opt(&mut cfg.network.shredstream_grpc_url);
        clean_opt(&mut cfg.network.shredstream_api_key);
        clean_opt(&mut cfg.network.allenhark_relay_url);
        clean_opt(&mut cfg.network.allenhark_relay_api_key);
        clean_opt(&mut cfg.network.raw_tx_ws);
        clean_opt(&mut cfg.jito.uuid);

        Ok(cfg)
    }

    pub fn validate(&self) -> Result<()> {
        if self.network.rpc_http.contains("YOUR_HELIUS_KEY") {
            bail!(
                "config.toml içindeki 'network.rpc_http' alanına gerçek Solana / Helius / AllenHark HTTP RPC adresinizi yazın!"
            );
        }

        if let Some(ws) = &self.network.rpc_ws {
            if ws.contains("YOUR_HELIUS_KEY")
                && self.network.geyser_grpc_url.is_none()
                && self.network.shredstream_grpc_url.is_none()
            {
                bail!(
                    "Hiçbir veri akışı yapılandırılmadı! 'geyser_grpc_url', 'shredstream_grpc_url' veya geçerli bir 'rpc_ws' tanımlayın."
                );
            }
        }

        if self.network.rpc_ws.is_none()
            && self.network.geyser_grpc_url.is_none()
            && self.network.shredstream_grpc_url.is_none()
            && self.network.raw_tx_ws.is_none()
        {
            bail!(
                "En az bir canlı veri akışı aktif olmalıdır: geyser_grpc_url (AllenHark gRPC), shredstream_grpc_url veya rpc_ws!"
            );
        }

        if self.mode.strategy == BotMode::Sandwich && self.network.raw_tx_ws.is_none() {
            bail!(
                "Salt 'sandwich' modu seçildi ancak 'network.raw_tx_ws' boş. AllenHark gRPC veya ShredStream ile çalıştırmak için modu 'hybrid' veya 'momentum' yapın."
            );
        }

        if self.jito.block_engine_urls.is_empty() {
            bail!("En az bir Jito 'block_engine_urls' adresi tanımlanmalıdır.");
        }
        if self.jito.tip_accounts.is_empty() {
            bail!("En az bir Jito 'tip_accounts' adresi tanımlanmalıdır.");
        }
        for acc in &self.jito.tip_accounts {
            Pubkey::from_str(acc)
                .with_context(|| format!("Geçersiz Jito tip hesabı pubkey: {}", acc))?;
        }
        if self.jito.tip_lamports < 1_000 {
            bail!(
                "Jito minimum tip tutarı 1_000 lamports'tur (şu an: {}).",
                self.jito.tip_lamports
            );
        }

        if self.strategy.position_sol < 0.0001 || self.strategy.max_position_sol <= 0.0 {
            bail!("'position_sol' en az 0.0001 SOL olmalıdır.");
        }
        if self.strategy.position_sol > self.strategy.max_position_sol {
            bail!("'position_sol' değeri 'max_position_sol' değerinden büyük olamaz.");
        }

        if self.mayhem.only_mayhem_buys && !self.mayhem.enabled {
            bail!(
                "'mayhem.only_mayhem_buys = true' iken 'mayhem.enabled = false' olamaz! Mayhem modunu açın veya 'only_mayhem_buys = false' yapın."
            );
        }
        if self.whale.enabled {
            if self.whale.min_whale_buy_sol <= 0.0 {
                bail!("'whale.min_whale_buy_sol' 0'dan büyük olmalıdır (ör. 5.0 SOL)");
            }
            if self.whale.min_mcap_usd <= 0.0
                || self.whale.max_mcap_usd < self.whale.min_mcap_usd
            {
                bail!(
                    "Geçersiz Whale USD Market Cap aralığı: ${} .. ${}",
                    self.whale.min_mcap_usd,
                    self.whale.max_mcap_usd
                );
            }
            if !self.whale.trade_pump_bonding_curve && !self.whale.trade_pumpswap_amm {
                bail!(
                    "'whale.trade_pump_bonding_curve' veya 'whale.trade_pumpswap_amm' en az biri true olmalıdır!"
                );
            }
        }
        if self.mayhem.enabled {
            if self.mayhem.min_mcap_sol <= 0.0
                || self.mayhem.max_mcap_sol < self.mayhem.min_mcap_sol
            {
                bail!(
                    "Geçersiz Mayhem Market Cap (MCAP) aralığı: min_mcap_sol ({}) .. max_mcap_sol ({})",
                    self.mayhem.min_mcap_sol,
                    self.mayhem.max_mcap_sol
                );
            }
            if self.mayhem.min_mayhem_buy_sol < 0.0 {
                bail!("'mayhem.min_mayhem_buy_sol' negatif olamaz.");
            }
            if self.mayhem.mayhem_agent_wallets.is_empty() {
                bail!("'mayhem.mayhem_agent_wallets' listesi boş olamaz.");
            }
            for w in &self.mayhem.mayhem_agent_wallets {
                Pubkey::from_str(w)
                    .with_context(|| format!("Geçersiz Mayhem Agent cüzdan adresi: {}", w))?;
            }
        }

        Ok(())
    }

    pub fn parsed_tip_accounts(&self) -> Result<Vec<Pubkey>> {
        self.jito
            .tip_accounts
            .iter()
            .map(|s| Pubkey::from_str(s).with_context(|| format!("Geçersiz tip pubkey: {}", s)))
            .collect()
    }

    pub fn parsed_mayhem_wallets(&self) -> Result<Vec<Pubkey>> {
        self.mayhem
            .mayhem_agent_wallets
            .iter()
            .map(|s| {
                Pubkey::from_str(s).with_context(|| format!("Geçersiz Mayhem pubkey: {}", s))
            })
            .collect()
    }
}

pub fn expand_tilde_path(path: &Path) -> PathBuf {
    let raw = path.to_string_lossy();
    if let Some(stripped) = raw.strip_prefix("~/").or_else(|| raw.strip_prefix("~\\")) {
        if let Some(home) = std::env::var_os("HOME").or_else(|| std::env::var_os("USERPROFILE")) {
            return PathBuf::from(home).join(stripped);
        }
    }
    path.to_path_buf()
}

pub fn load_wallet_keypair(configured_path: &str) -> Result<Keypair> {
    if let Ok(secret_raw) = std::env::var("SOLANA_PRIVATE_KEY") {
        let trimmed = secret_raw.trim();
        if !trimmed.is_empty() {
            return parse_keypair_str(trimmed)
                .context("SOLANA_PRIVATE_KEY ortam değişkeninden cüzdan okunamadı");
        }
    }

    let effective_path = std::env::var("SOLANA_KEYPAIR_PATH")
        .ok()
        .filter(|s| !s.trim().is_empty())
        .unwrap_or_else(|| configured_path.to_string());

    let full_path = expand_tilde_path(Path::new(&effective_path));
    let content = fs::read_to_string(&full_path).with_context(|| {
        format!(
            "Cüzdan keypair dosyası okunamadı: {} (SOLANA_PRIVATE_KEY tanımlayabilir veya dosyayı oluşturabilirsiniz)",
            full_path.to_string_lossy()
        )
    })?;

    parse_keypair_str(&content)
        .with_context(|| format!("Geçersiz cüzdan dosyası: {}", full_path.to_string_lossy()))
}

pub fn parse_keypair_str(raw: &str) -> Result<Keypair> {
    let trimmed = raw.trim();
    if trimmed.starts_with('[') {
        let bytes: Vec<u8> = serde_json::from_str(trimmed)
            .context("JSON keypair dizisi ayrıştırılamadı ([u8; 64] bekleniyor)")?;
        if bytes.len() != 64 {
            bail!(
                "JSON keypair 64 byte olmalıdır, okunan uzunluk: {}",
                bytes.len()
            );
        }
        let arr: [u8; 64] = bytes.try_into().expect("checked 64 bytes");
        Keypair::try_from(&arr[..]).context("64-byte diziden geçerli Ed25519 Keypair üretilemedi")
    } else {
        let decoded = bs58::decode(trimmed)
            .into_vec()
            .context("Base58 private key çözümlenemedi")?;
        if decoded.len() != 64 {
            bail!(
                "Base58 keypair çözümlendiğinde 64 byte olmalıdır, okunan: {} byte",
                decoded.len()
            );
        }
        Keypair::try_from(decoded.as_slice())
            .context("Base58 verisinden geçerli Ed25519 Keypair üretilemedi")
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use solana_signer::Signer;

    #[test]
    fn test_parse_keypair_json_and_base58() {
        let original = Keypair::new();
        let bytes = original.to_bytes();

        let json_str = serde_json::to_string(&bytes.to_vec()).unwrap();
        let from_json = parse_keypair_str(&json_str).unwrap();
        assert_eq!(original.pubkey(), from_json.pubkey());

        let b58_str = bs58::encode(&bytes).into_string();
        let from_b58 = parse_keypair_str(&b58_str).unwrap();
        assert_eq!(original.pubkey(), from_b58.pubkey());
    }

    #[test]
    fn test_default_10k_50k_5sol_whale_config_validates() {
        let mut cfg = AppConfig::default();
        cfg.network.rpc_http = "https://api.mainnet-beta.solana.com".into();
        cfg.validate().unwrap();
        assert!((cfg.strategy.position_sol - 0.001).abs() < 1e-9);
        assert!(cfg.whale.enabled);
        assert!((cfg.whale.min_whale_buy_sol - 5.0).abs() < 1e-9);
        assert!((cfg.whale.min_mcap_usd - 10_000.0).abs() < 1e-9);
        assert!((cfg.whale.max_mcap_usd - 50_000.0).abs() < 1e-9);
        assert_eq!(cfg.whale.min_buy_lamports(), 5_000_000_000);
        assert!(cfg.whale.trade_pump_bonding_curve);
        assert!(cfg.whale.trade_pumpswap_amm);
        assert!(!cfg.mayhem.enabled);
        // Mayhem yardımcı metotları da hala sağlam çalışmalı
        assert!(cfg.mayhem.is_mcap_in_window(550_000_000));
    }
}
