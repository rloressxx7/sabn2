use anyhow::{bail, Context, Result};
use base64::Engine;
use futures_util::future::join_all;
use rand::seq::SliceRandom;
use serde_json::{json, Value};
use solana_compute_budget_interface::ComputeBudgetInstruction;
use solana_hash::Hash;
use solana_instruction::{AccountMeta, Instruction};
use solana_keypair::Keypair;
use solana_message::{v0, VersionedMessage};
use solana_pubkey::Pubkey;
use solana_signer::Signer;
use solana_transaction::versioned::VersionedTransaction;
use std::str::FromStr;
use std::time::Duration;
use tracing::{warn};

use crate::pump::jitodontfront_pubkey;

/// Resmi AllenHark 0.1ms Relay Tip Cüzdanları (`https://allenhark.com/infrastructure/allenhark-relay`)
pub const ALLENHARK_RELAY_TIP_WALLETS: [&str; 11] = [
    "hark1zxc5Rz3K8Kquz79WPWFEgNCFeJnsMJ16f22uNP",
    "harkm2BTWxZuszoNpZnfe84jRbQTg6KGHaQBmWzDGQQ",
    "hark4CwtTnN2y9FaxjcFBAJdJqQrpouu5pgEixfqdEz",
    "harkoJfnM6dxrJydx5eVmDVwAgwC94KbhuxF69UbXwP",
    "hark6hUDUTekc1DGxWdJcuyDZwf6pJdCxd4SXAVtta6",
    "harkoTvFpKSrEQduYrNHXCurARVT19Ud3BnFhVxabos",
    "harkEpXoJv5qVzHaN7HSuUAd6PHjyMcFMcDYBMDJCEQ",
    "harkyXDdZSoJGyCxa24t2QXx1poPyp8YfghbtpzGSzK",
    "harkR2YJ4Dpt4UDJTcBirjnSPBhNpQFcoFkNpCkVqNk",
    "harkRBygM8pHYe4K8eBjfxyEX19oJn3LepFjvNbLbyi",
    "harkYFxB6DuUFNwDLvA5CQ66KpfRvFgUoVypMagNcmd",
];

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum JitoBundleState {
    Pending,
    Landed { slot: u64 },
    Failed(String),
}

#[derive(Debug, Clone)]
pub struct AtomicDispatchReceipt {
    pub bundle_id: Option<String>,
    pub accepted_any: bool,
}

#[derive(Clone)]
pub struct JitoClient {
    http: reqwest::Client,
    bundle_endpoints: Vec<String>,
    tx_bundle_only_endpoints: Vec<String>,
    uuid: Option<String>,
    tip_accounts: Vec<Pubkey>,
    allenhark_relay_url: Option<String>,
    allenhark_relay_key: Option<String>,
    allenhark_tip_accounts: Vec<Pubkey>,
}

impl JitoClient {
    pub fn new(
        endpoints: Vec<String>,
        uuid: Option<String>,
        tip_accounts: Vec<Pubkey>,
        allenhark_relay_url: Option<String>,
        allenhark_relay_key: Option<String>,
    ) -> Result<Self> {
        if endpoints.is_empty() {
            bail!("JitoClient için en az bir block_engine_url gereklidir");
        }
        if tip_accounts.is_empty() {
            bail!("JitoClient için en az bir tip_account gereklidir");
        }

        let http = reqwest::Client::builder()
            .timeout(Duration::from_millis(3500))
            .connect_timeout(Duration::from_millis(1500))
            .pool_idle_timeout(Duration::from_secs(90))
            .pool_max_idle_per_host(16)
            .tcp_nodelay(true)
            .http2_keep_alive_interval(Some(Duration::from_secs(12)))
            .http2_keep_alive_timeout(Duration::from_secs(4))
            .http2_keep_alive_while_idle(true)
            .build()
            .context("Jito HTTP/2 istemcisi oluşturulamadı")?;

        // Her bölgesel `/api/v1/bundles` adresinden eşlenik `/api/v1/transactions?bundleOnly=true`
        // adresini otomatik türet (Ayrı rate-limit havuzu + %100 Atomik Revert Koruması!)
        let tx_bundle_only_endpoints: Vec<String> = endpoints
            .iter()
            .map(|ep| {
                let base = if ep.contains("/api/v1/bundles") {
                    ep.replace("/api/v1/bundles", "/api/v1/transactions")
                } else {
                    format!("{}/api/v1/transactions", ep.trim_end_matches('/'))
                };
                if base.contains('?') {
                    format!("{}&bundleOnly=true", base)
                } else {
                    format!("{}?bundleOnly=true", base)
                }
            })
            .collect();

        let allenhark_tip_accounts = ALLENHARK_RELAY_TIP_WALLETS
            .iter()
            .filter_map(|s| Pubkey::from_str(s).ok())
            .collect();

        Ok(Self {
            http,
            bundle_endpoints: endpoints,
            tx_bundle_only_endpoints,
            uuid,
            tip_accounts,
            allenhark_relay_url,
            allenhark_relay_key,
            allenhark_tip_accounts,
        })
    }

    /// İlk alım anında 80-150ms TCP + TLS 1.3 el sıkışması gecikmesi yaşanmaması için
    /// tüm bölgesel Jito HTTP/2 bağlantılarını arka planda sürekli sıcak tutar!
    pub fn spawn_connection_warmer(&self) -> tokio::task::JoinHandle<()> {
        let client = self.clone();
        tokio::spawn(async move {
            let body = json!({
                "jsonrpc": "2.0",
                "id": 1,
                "method": "getTipAccounts",
                "params": []
            });
            loop {
                for ep in &client.bundle_endpoints {
                    let url = client.with_uuid_query(ep);
                    let _ = client.http.post(&url).json(&body).send().await;
                }
                tokio::time::sleep(Duration::from_secs(12)).await;
            }
        })
    }

    pub fn has_allenhark_relay(&self) -> bool {
        self.allenhark_relay_url.is_some() && self.allenhark_relay_key.is_some()
    }

    #[inline]
    pub fn pick_random_tip_account(&self) -> Pubkey {
        let mut rng = rand::thread_rng();
        *self
            .tip_accounts
            .choose(&mut rng)
            .unwrap_or(&self.tip_accounts[0])
    }

    /// Standart Jito bahşiş komutu (`Tx3` gibi son işlemde kullanılır).
    #[inline]
    pub fn build_tip_ix(&self, payer: &Pubkey, tip_lamports: u64) -> Instruction {
        let tip_account = self.pick_random_tip_account();
        solana_system_interface::instruction::transfer(payer, &tip_account, tip_lamports)
    }

    /// Tekil işlemlerde (1-Tx Atomik Bundle) resmi Solana Cookbook deseniyle `jitodontfront`
    /// salt-okunur hesabını doğrudan Jito tip transfer komutuna ekler (0 ekstra instruction,
    /// %100 anti-sandwich koruması — kimse bizim işlemimizin önüne geçemez!).
    #[inline]
    pub fn build_tip_ix_with_dontfront(&self, payer: &Pubkey, tip_lamports: u64) -> Instruction {
        let mut ix = self.build_tip_ix(payer, tip_lamports);
        ix.accounts
            .push(AccountMeta::new_readonly(jitodontfront_pubkey(), false));
        ix
    }

    pub fn build_allenhark_relay_tip_ix(&self, payer: &Pubkey, tip_lamports: u64) -> Instruction {
        let mut rng = rand::thread_rng();
        let tip_wallet = *self
            .allenhark_tip_accounts
            .choose(&mut rng)
            .unwrap_or(&self.allenhark_tip_accounts[0]);
        solana_system_interface::instruction::transfer(
            payer,
            &tip_wallet,
            tip_lamports.max(1_000_000),
        )
    }

    pub async fn send_via_allenhark_relay(&self, tx: &VersionedTransaction) -> Result<String> {
        let (Some(url), Some(api_key)) = (&self.allenhark_relay_url, &self.allenhark_relay_key)
        else {
            bail!("AllenHark Relay yapılandırılmamış");
        };
        let mut raw = Vec::with_capacity(512);
        bincode::serialize_into(&mut raw, tx)?;
        let b64 = base64::engine::general_purpose::STANDARD.encode(&raw);

        let resp = self
            .http
            .post(url)
            .header("x-api-key", api_key)
            .json(&json!({ "tx": b64, "simulate": false }))
            .send()
            .await?;

        let val: Value = resp.json().await?;
        if val.get("status").and_then(|s| s.as_str()) == Some("accepted") {
            Ok(val
                .get("signature")
                .and_then(|s| s.as_str())
                .unwrap_or("accepted")
                .to_string())
        } else {
            bail!("AllenHark Relay reddetti: {}", val)
        }
    }

    #[inline]
    pub fn compile_v0_tx(
        payer: &Keypair,
        compute_unit_limit: u32,
        compute_unit_price_micro_lamports: u64,
        body_instructions: Vec<Instruction>,
        recent_blockhash: Hash,
    ) -> Result<VersionedTransaction> {
        Self::compile_v0_tx_with_options(
            payer,
            compute_unit_limit,
            compute_unit_price_micro_lamports,
            body_instructions,
            recent_blockhash,
            false,
        )
    }

    /// 3-Tx Sandwich `Tx1` (index 0) veya özel anti-frontrun gereken işlemler için
    /// `inject_dontfront_on_cu = true` verildiğinde `ComputeBudget::set_compute_unit_limit`
    /// komutuna salt-okunur `jitodontfront` hesabını 0 ekstra komut maliyetiyle ekler.
    #[inline]
    pub fn compile_v0_tx_with_options(
        payer: &Keypair,
        compute_unit_limit: u32,
        compute_unit_price_micro_lamports: u64,
        mut body_instructions: Vec<Instruction>,
        recent_blockhash: Hash,
        inject_dontfront_on_cu: bool,
    ) -> Result<VersionedTransaction> {
        let mut all_ixs = Vec::with_capacity(body_instructions.len() + 2);
        if compute_unit_limit > 0 {
            let mut cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(compute_unit_limit);
            if inject_dontfront_on_cu {
                cu_ix
                    .accounts
                    .push(AccountMeta::new_readonly(jitodontfront_pubkey(), false));
            }
            all_ixs.push(cu_ix);
        } else if inject_dontfront_on_cu {
            if let Some(first) = body_instructions.first_mut() {
                first
                    .accounts
                    .push(AccountMeta::new_readonly(jitodontfront_pubkey(), false));
            }
        }
        if compute_unit_price_micro_lamports > 0 {
            all_ixs.push(ComputeBudgetInstruction::set_compute_unit_price(
                compute_unit_price_micro_lamports,
            ));
        }
        all_ixs.append(&mut body_instructions);

        let v0_msg = v0::Message::try_compile(&payer.pubkey(), &all_ixs, &[], recent_blockhash)
            .context("V0 işlem mesajı derlenemedi")?;

        VersionedTransaction::try_new(VersionedMessage::V0(v0_msg), &[payer])
            .context("VersionedTransaction imzalanamadı")
    }

    /// TEKİL ATOMİK İŞLEM ATEŞLEYİCİ (%100 REVERT KORUMALI — SIFIR BAŞARISIZ İŞLEM!):
    /// İşlemi tek seferde Base64'e çevirir ve AYNI MİKROSANİYEDE hem:
    ///   1) Tüm bölgesel `/api/v1/bundles` (`sendBundle`) uçlarına, HEM DE
    ///   2) Tüm bölgesel `/api/v1/transactions?bundleOnly=true` (`sendTransaction`) uçlarına
    /// paralel gönderir!
    /// Her iki kanal da Jito Atomik Bundle motorunda çalışır: işlem revert edecekse (slippage / mezuniyet)
    /// ZİNCİRE HİÇ GİRMEZ -> 0 SOL gas kaybı, 0 SOL tip kaybı, Solscan'de 0 hata!
    pub async fn send_single_atomic_tx(
        &self,
        tx: &VersionedTransaction,
    ) -> Result<AtomicDispatchReceipt> {
        let mut raw = Vec::with_capacity(512);
        bincode::serialize_into(&mut raw, tx).context("Atomik işlem serialize edilemedi")?;
        let b64 = base64::engine::general_purpose::STANDARD.encode(&raw);

        let bundle_payload = json!({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "sendBundle",
            "params": [[&b64], { "encoding": "base64" }]
        });

        let tx_bundle_only_payload = json!({
            "jsonrpc": "2.0",
            "id": 2,
            "method": "sendTransaction",
            "params": [&b64, { "encoding": "base64" }]
        });

        let bundle_futs = self.bundle_endpoints.iter().map(|endpoint| {
            let client = self.http.clone();
            let url = self.with_uuid_query(endpoint);
            let uuid_hdr = self.uuid.clone();
            let body = bundle_payload.clone();
            async move {
                let mut req = client.post(&url).json(&body);
                if let Some(u) = uuid_hdr {
                    req = req.header("x-jito-auth", u);
                }
                let resp = req.send().await?;
                let status = resp.status();
                let txt = resp.text().await?;
                if !status.is_success() {
                    bail!("HTTP {} ({}): {}", status, endpoint, txt);
                }
                let val: Value = serde_json::from_str(&txt)?;
                if let Some(err) = val.get("error") {
                    bail!("Jito sendBundle hatası ({}): {}", endpoint, err);
                }
                Ok::<Option<String>, anyhow::Error>(
                    val.get("result")
                        .and_then(|r| r.as_str())
                        .map(|s| s.to_string()),
                )
            }
        });

        let tx_futs = self.tx_bundle_only_endpoints.iter().map(|endpoint| {
            let client = self.http.clone();
            let url = self.with_uuid_query(endpoint);
            let uuid_hdr = self.uuid.clone();
            let body = tx_bundle_only_payload.clone();
            async move {
                let mut req = client.post(&url).json(&body);
                if let Some(u) = uuid_hdr {
                    req = req.header("x-jito-auth", u);
                }
                let resp = req.send().await?;
                let status = resp.status();
                let txt = resp.text().await?;
                if !status.is_success() {
                    bail!("HTTP {} ({}): {}", status, endpoint, txt);
                }
                let val: Value = serde_json::from_str(&txt)?;
                if let Some(err) = val.get("error") {
                    bail!("Jito bundleOnly tx hatası ({}): {}", endpoint, err);
                }
                Ok::<(), anyhow::Error>(())
            }
        });

        let (bundle_results, tx_results) = tokio::join!(join_all(bundle_futs), join_all(tx_futs));

        let mut first_bundle_id = None;
        let mut accepted_any = false;
        let mut last_err = None;

        for res in bundle_results {
            match res {
                Ok(bid) => {
                    accepted_any = true;
                    if first_bundle_id.is_none() {
                        first_bundle_id = bid;
                    }
                }
                Err(e) => last_err = Some(e),
            }
        }
        for res in tx_results {
            match res {
                Ok(()) => accepted_any = true,
                Err(e) => last_err = Some(e),
            }
        }

        if accepted_any {
            Ok(AtomicDispatchReceipt {
                bundle_id: first_bundle_id,
                accepted_any: true,
            })
        } else {
            Err(last_err.unwrap_or_else(|| anyhow::anyhow!("Hiçbir Jito atomik kanalı kabul etmedi")))
        }
    }

    pub async fn send_bundle(&self, txs: &[VersionedTransaction]) -> Result<String> {
        if txs.is_empty() {
            bail!("Boş Jito bundle gönderilemez");
        }
        if txs.len() > 5 {
            bail!(
                "Jito bundle en fazla 5 işlem içerebilir (verilen: {})",
                txs.len()
            );
        }

        let mut encoded_txs = Vec::with_capacity(txs.len());
        let mut buf = Vec::with_capacity(512);
        for tx in txs {
            buf.clear();
            bincode::serialize_into(&mut buf, tx).context("Bundle işlemi serialize edilemedi")?;
            encoded_txs.push(base64::engine::general_purpose::STANDARD.encode(&buf));
        }

        let req_id: u64 = rand::random();
        let body = json!({
            "jsonrpc": "2.0",
            "id": req_id,
            "method": "sendBundle",
            "params": [
                encoded_txs,
                { "encoding": "base64" }
            ]
        });

        let futures = self.bundle_endpoints.iter().map(|endpoint| {
            let client = self.http.clone();
            let url = self.with_uuid_query(endpoint);
            let uuid_hdr = self.uuid.clone();
            let payload = body.clone();
            async move {
                let mut req = client.post(&url).json(&payload);
                if let Some(u) = uuid_hdr {
                    req = req.header("x-jito-auth", u);
                }
                let resp = req.send().await?;
                let status = resp.status();
                let txt = resp.text().await?;
                if !status.is_success() {
                    bail!("HTTP {} ({}): {}", status, endpoint, txt);
                }
                let val: Value = serde_json::from_str(&txt)?;
                if let Some(err) = val.get("error") {
                    bail!("Jito RPC hatası ({}): {}", endpoint, err);
                }
                val.get("result")
                    .and_then(|r| r.as_str())
                    .map(|s| s.to_string())
                    .ok_or_else(|| anyhow::anyhow!("Yanıtta bundle_id yok ({})", endpoint))
            }
        });

        let results = join_all(futures).await;
        let mut last_err = None;
        for res in results {
            match res {
            Ok(bundle_id) => return Ok(bundle_id),
            Err(e) => {
                warn!("⚠️ JITO ENDPOINT REDDETTI: {}", e);
                last_err = Some(e);
            }
            }
        }

        Err(last_err.unwrap_or_else(|| anyhow::anyhow!("Jito bundle hiçbir uç noktaya iletilemedi")))
    }

    pub async fn check_bundle_state(&self, bundle_id: &str) -> Result<JitoBundleState> {
        let endpoint = &self.bundle_endpoints[0];
        let url = self.with_uuid_query(endpoint);

        let inflight_body = json!({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getInflightBundleStatuses",
            "params": [[bundle_id]]
        });

        let mut req = self.http.post(&url).json(&inflight_body);
        if let Some(u) = &self.uuid {
            req = req.header("x-jito-auth", u);
        }

        if let Ok(resp) = req.send().await {
            if let Ok(val) = resp.json::<Value>().await {
                if let Some(first) = val
                    .get("result")
                    .and_then(|r| r.get("value"))
                    .and_then(|v| v.as_array())
                    .and_then(|a| a.first())
                {
                    if let Some(status_str) = first.get("status").and_then(|s| s.as_str()) {
                        match status_str {
                            "Landed" => {
                                let slot = first
                                    .get("landed_slot")
                                    .and_then(|s| s.as_u64())
                                    .unwrap_or(0);
                                return Ok(JitoBundleState::Landed { slot });
                            }
                            "Failed" | "Invalid" => {
                                return Ok(JitoBundleState::Failed(format!(
                                    "Inflight durum: {}",
                                    status_str
                                )));
                            }
                            "Pending" => return Ok(JitoBundleState::Pending),
                            _ => {}
                        }
                    }
                }
            }
        }

        let landed_body = json!({
            "jsonrpc": "2.0",
            "id": 2,
            "method": "getBundleStatuses",
            "params": [[bundle_id]]
        });

        let mut req2 = self.http.post(&url).json(&landed_body);
        if let Some(u) = &self.uuid {
            req2 = req2.header("x-jito-auth", u);
        }

        let resp2 = req2.send().await.context("getBundleStatuses HTTP hatası")?;
        let val2: Value = resp2.json().await.context("getBundleStatuses JSON hatası")?;

        if let Some(first) = val2
            .get("result")
            .and_then(|r| r.get("value"))
            .and_then(|v| v.as_array())
            .and_then(|a| a.first())
        {
            if let Some(err_obj) = first.get("err") {
                if !err_obj.is_null() && err_obj.get("Ok").is_none() {
                    return Ok(JitoBundleState::Failed(err_obj.to_string()));
                }
            }
            let slot = first.get("slot").and_then(|s| s.as_u64()).unwrap_or(0);
            return Ok(JitoBundleState::Landed { slot });
        }

        Ok(JitoBundleState::Pending)
    }

    pub async fn wait_for_bundle(
        &self,
        bundle_id: &str,
        timeout_duration: Duration,
    ) -> Result<JitoBundleState> {
        let deadline = tokio::time::Instant::now() + timeout_duration;
        while tokio::time::Instant::now() < deadline {
            match self.check_bundle_state(bundle_id).await {
                Ok(state @ JitoBundleState::Landed { .. }) => return Ok(state),
                Ok(state @ JitoBundleState::Failed(_)) => return Ok(state),
                Ok(JitoBundleState::Pending) => {}
                Err(e) => warn!("Jito durum sorgu uyarısı ({}): {}", bundle_id, e),
            }
            tokio::time::sleep(Duration::from_millis(250)).await;
        }
        Ok(JitoBundleState::Failed("Zaman aşımı (slot kaçırıldı)".into()))
    }

    fn with_uuid_query(&self, base_url: &str) -> String {
        match &self.uuid {
            Some(u) if !u.is_empty() && !base_url.contains("uuid=") => {
                if base_url.contains('?') {
                    format!("{}&uuid={}", base_url, u)
                } else {
                    format!("{}?uuid={}", base_url, u)
                }
            }
            _ => base_url.to_string(),
        }
    }
}
