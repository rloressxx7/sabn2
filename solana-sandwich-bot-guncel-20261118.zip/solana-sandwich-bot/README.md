# Solana Pump.fun + PumpSwap [`$10,000 – $50,000` MCAP | `>= 5 SOL` Balina] Atomik Kâr Motoru (v5.0 — Rust)

Bu proje, **DigitalOcean Frankfurt (`FRA1` — `142.93.102.109`)** Ubuntu 24.04 LTS sunucunuz için saf **Rust** ile geliştirilmiş; Market Cap değeri tam **`$10,000` ile `$50,000` USD** aralığındaki tokenlarda **en az `5.0 SOL` alım yapan balinaları** hem **Pump.fun Bonding Curve (`$10k – ~$29.5k`)** hem de **mezun olmuş PumpSwap AMM (`~$29.5k – $50k`)** üzerinde `<40 µs` içinde yakalayan **%100 Atomik, Sıfır On-Chain Hata (`0 SOL` boşa gas) ve Tam Kira İadeli** HFT motorudur.

---

## Neden Hem Pump.fun Eğrisi Hem PumpSwap AMM (`Dual-Venue`) Şart?

Canlı Solana Mainnet verilerine göre (`SOL ≈ $71.85`):
- **Pump.fun Bonding Curve (`6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P`)** başlangıçta `~$2,009` MCAP ile açılır ve **`~$29,522` MCAP (`410.88 SOL`)** seviyesinde **%100 dolup mezun olur**!
- Mezun olan her token anında **PumpSwap AMM (`pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA`)** havuzuna geçer (`$29,522 – $50,000` MCAP aralığı buradadır!).
- **v5.0** tek bir AllenHark Frankfurt Geyser gRPC bağlantısı üzerinden **her iki programı da aynı anda dinler**:
  1. **`$10,000 – $29,522` MCAP (`Pump.fun Bonding Curve`)**: `>= 5 SOL` alım geldiğinde 18-hesap `BuyExactSolIn` ile 0-RPC girer, çıkışta `Sell + CloseAccount` ile Token ATA kirasını geri alır.
  2. **`$29,522 – $50,000` MCAP (`PumpSwap AMM`)**: `>= 5 SOL` alım geldiğinde `CreateWSOL + Transfer + SyncNative + CreateBaseATA + BuyExactQuoteIn + CloseWSOL` ile aynı işlemde WSOL kirasını geri alarak girer; çıkışta hem WSOL hem Token ATA'sını kapatıp **%100 kira iadesiyle** native SOL olarak çıkar!

---

## AllenHark Kayıt Bilgileriniz (`FRA1` Sunucunuz İçin Hazır)

| Alan | Değer |
|---|---|
| **Server IP Address (Whitelist IP)** | **`142.93.102.109`** |
| **Auth Public Key (Ed25519 Pubkey)** | **`4ndFSgy8wqimG9ZwiTrK1GwkpULMotSQK63jPQXDt5Eq`** |
| **Auth Keypair Dosyası** | `keys/allenhark-auth-keypair.json` |
| **AllenHark Frankfurt Geyser gRPC** | `http://88.216.36.108:10001` |

---

## Ubuntu 24.04 (`142.93.102.109`) Hızlı Kurulum

```bash
unzip solana-sandwich-bot-v5-whale-10k-50k.zip -d ~/bot
cd ~/bot/solana-sandwich-bot
chmod +x deploy_ubuntu_fra1.sh
./deploy_ubuntu_fra1.sh
```
