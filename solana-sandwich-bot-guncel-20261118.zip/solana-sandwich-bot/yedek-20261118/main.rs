use anyhow::{bail, Context, Result};
use clap::Parser;
use solana_commitment_config::CommitmentConfig;
use solana_compute_budget_interface::ComputeBudgetInstruction;
use solana_instruction::AccountMeta;
use solana_keypair::Keypair;
use solana_message::{v0, VersionedMessage};
use solana_pubkey::Pubkey;
use solana_signature::Signature;
use solana_signer::Signer;
use solana_transaction::versioned::VersionedTransaction;
use std::fs;
use std::path::PathBuf;
use std::str::FromStr;
use std::time::Instant;
use tracing::info;
use tracing_appender::non_blocking::WorkerGuard;
use tracing_subscriber::{fmt, layer::SubscriberExt, util::SubscriberInitExt, EnvFilter};

use solana_sandwich_bot::config::{load_wallet_keypair, AppConfig, BotMode};
use solana_sandwich_bot::engine::BotEngine;
use solana_sandwich_bot::grpc_streams::run_geyser_live_probe;
use solana_sandwich_bot::jito::JitoClient;
use solana_sandwich_bot::oracle::SolUsdOracle;
use solana_sandwich_bot::pump::{
    build_buy_exact_sol_in_fast_ix, build_buy_exact_tokens_out_fast_ix,
    build_close_token_account_ix, build_sell_fast_ix, create_ata_idempotent_with_ata_ix,
    default_buyback_fee_recipient, derive_creator_vault_pda, derive_event_authority_pda,
    derive_fee_config_pda, derive_global_pda, derive_global_volume_accumulator_pda,
    derive_user_volume_accumulator_pda, jitodontfront_pubkey, mayhem_agent_wallet,
    mayhem_program_id, mayhem_reserved_fee_recipient, pump_program_id, quote_buy_exact_sol_in,
    token_2022_program_id, tx_has_jitodontfront, BondingCurveState, GlobalConfigState,
    MintDerivedPdas,
};
use solana_sandwich_bot::pumpswap::{
    build_pumpswap_atomic_buy_ixs, pumpswap_event_authority_pda, pumpswap_fee_config_pda,
    pumpswap_global_config_pda, pumpswap_global_volume_pda, pumpswap_program_id, PumpSwapPoolMeta,
};
use solana_sandwich_bot::rpc::SolanaRpcClient;

#[derive(Parser, Debug)]
#[command(
    name = "solana-sandwich-bot",
    version = "5.0.0",
    about = "Pump.fun + PumpSwap [$10k-$50k MCAP | >=5 SOL Whale] + Jito Atomic Profit Engine (v5.0)"
)]
struct Cli {
    /// Yapılandırma dosyası yolu
    #[arg(short, long, default_value = "config.toml")]
    config: PathBuf,

    /// Çalışma modunu komut satırından ezmek için: momentum | sandwich | hybrid
    #[arg(short, long)]
    mode: Option<String>,

    /// Cüzdan gerektirmeden canlı Solana Mainnet SVM (Pump + PumpSwap) doğrulaması ve mikrosaniye hız testi yapar
    #[arg(long)]
    self_test: bool,

    /// AllenHark Frankfurt Yellowstone Geyser gRPC (`http://88.216.36.108:10001`) bağlantısını 5 sn canlı test eder
    #[arg(long)]
    test_grpc: bool,

    /// Yeni bir Ed25519 Solana keypair JSON dosyası üretir ve Public Key'ini ekrana basar
    #[arg(long)]
    gen_keypair: Option<PathBuf>,
    /// Manuel satış yapmak için mint adresi
    #[arg(long)]
    sell_mint: Option<String>,
}

#[tokio::main]
async fn main() -> Result<()> {
    let cli = Cli::parse();

    if let Some(out_path) = cli.gen_keypair {
        return generate_keypair_file(&out_path);
    }

    if cli.test_grpc {
        let _guard = init_logging("info", "logs")?;
        let ep = AppConfig::load(&cli.config)
            .ok()
            .and_then(|c| c.network.geyser_grpc_url)
            .unwrap_or_else(|| "http://88.216.36.108:10001".to_string());
        let tok = AppConfig::load(&cli.config)
            .ok()
            .and_then(|c| c.network.geyser_x_token);
        return run_geyser_live_probe(&ep, tok).await;
    }

    if cli.self_test {
        let _guard = init_logging("info", "logs")?;
        return run_mainnet_self_test().await;
    }

    let mut cfg = AppConfig::load(&cli.config)?;
    if let Some(mode_override) = cli.mode {
        cfg.mode.strategy = BotMode::from_str(&mode_override)?;
    }

    let _guard = init_logging(&cfg.logging.level, &cfg.logging.log_dir)?;
    let wallet = load_wallet_keypair(&cfg.wallet.keypair_path)?;

    let engine = BotEngine::initialize(cfg, wallet).await?;
    \
    // Manuel satış modu
    if let Some(mint_str) = cli.sell_mint {
        let mint = Pubkey::from_str(&mint_str).context("Geçersiz mint adresi")?;
        info!("[MANUEL SATIŞ] Mint={}", mint);
        return engine.manual_sell(mint).await;
    }
    engine.run().await
}

fn generate_keypair_file(out_path: &PathBuf) -> Result<()> {
    if let Some(parent) = out_path.parent() {
        if !parent.as_os_str().is_empty() {
            fs::create_dir_all(parent)?;
        }
    }
    let kp = Keypair::new();
    let json_bytes = serde_json::to_string(&kp.to_bytes().to_vec())?;
    fs::write(out_path, format!("{}\n", json_bytes))?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let _ = fs::set_permissions(out_path, fs::Permissions::from_mode(0o600));
    }
    println!("Keypair kaydedildi : {}", out_path.display());
    println!("Public Key (Base58): {}", kp.pubkey());
    Ok(())
}

fn init_logging(level: &str, log_dir: &str) -> Result<WorkerGuard> {
    fs::create_dir_all(log_dir).context("Log klasörü oluşturulamadı")?;
    let file_appender = tracing_appender::rolling::daily(log_dir, "sandwich-bot.log");
    let (non_blocking_file, guard) = tracing_appender::non_blocking(file_appender);

    let env_filter =
        EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new(level.trim()));

    let stdout_layer = fmt::layer().with_target(false);
    let file_layer = fmt::layer()
        .with_ansi(false)
        .with_target(true)
        .with_writer(non_blocking_file);

    tracing_subscriber::registry()
        .with(env_filter)
        .with(stdout_layer)
        .with(file_layer)
        .init();

    Ok(guard)
}

async fn run_mainnet_self_test() -> Result<()> {
    info!("=== Pump.fun + PumpSwap [$10k–$50k MCAP | >=5 SOL WHALE] v5.0 Mainnet Doğrulaması ===");
    let _ = (
        derive_global_pda(),
        derive_event_authority_pda(),
        derive_global_volume_accumulator_pda(),
        derive_fee_config_pda(),
        jitodontfront_pubkey(),
        mayhem_program_id(),
        mayhem_agent_wallet(),
        mayhem_reserved_fee_recipient(),
        default_buyback_fee_recipient(),
        pumpswap_program_id(),
        pumpswap_global_config_pda(),
        pumpswap_event_authority_pda(),
        pumpswap_fee_config_pda(),
        pumpswap_global_volume_pda(),
    );

    let oracle = SolUsdOracle::new(71.85);
    let sol_usd = oracle.warm_up().await;

    info!("Pump Program ID         : {}", pump_program_id());
    info!("PumpSwap AMM Program ID : {}", pumpswap_program_id());
    info!(
        "Canlı SOL/USD Kuru      : ${:.2} -> $10k-$50k MCAP = {:.1} SOL .. {:.1} SOL MCAP",
        sol_usd,
        10_000.0 / sol_usd,
        50_000.0 / sol_usd
    );

    let rpc_urls: Vec<String> = std::env::var("RPC_HTTP")
        .unwrap_or_else(|_| "https://api.mainnet-beta.solana.com".to_string())
        .split(',')
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .collect();
    let rpc = SolanaRpcClient::new(rpc_urls, CommitmentConfig::processed());

    let bh = rpc
        .get_latest_blockhash()
        .await
        .context("Mainnet getLatestBlockhash çağrısı başarısız")?;
    info!("Canlı Mainnet Blockhash : {}", bh);

    let global_acc = rpc
        .get_account_info(&derive_global_pda())
        .await?
        .context("Pump.fun Global PDA zincirde bulunamadı")?;
    let fees = GlobalConfigState::from_account_data(&global_acc.data)?;
    info!(
        "Canlı Global PDA ({}B) -> StandartFee: {} | Buyback: {} alıcı ({} bps)",
        global_acc.data.len(),
        fees.fee_recipient,
        fees.buyback_fee_recipients.len(),
        fees.buyback_basis_points
    );

    // 1) Canlı Solana Mainnet SVM üzerinde GERÇEK PUMPSWAP AMM (`GHE2bpQk...`) Atomik Alım + WSOL Close Simülasyonu!
    let live_pool_pk = Pubkey::from_str("GHE2bpQkN9DKyCyiCdt9QdDs9iFJY8TbjzXXjeUYQkTt")?;
    let funded_payer = fees.fee_recipient;
    if let Some(pool_acc) = rpc.get_account_info(&live_pool_pk).await? {
        let mut live_meta = PumpSwapPoolMeta::from_pool_account_data(
            live_pool_pk,
            token_2022_program_id(),
            177_914_379_851_004,
            81_338_889_838,
            &pool_acc.data,
        )?;
        live_meta.buyback_fee_recipient =
            Pubkey::from_str("5eHhjP8JaYkz83CWwvGU2uMUXefd3AazWGx4gpcuEEYD")?;

        let t_ps = Instant::now();
        let mut ps_ixs = vec![ComputeBudgetInstruction::set_compute_unit_limit(240_000)];
        ps_ixs.extend(build_pumpswap_atomic_buy_ixs(
            &funded_payer,
            &live_meta,
            1_000_000, // 0.001 SOL
            1,
        ));
        let ps_build_us = t_ps.elapsed().as_micros();

        let ps_msg = v0::Message::try_compile(&funded_payer, &ps_ixs, &[], bh)?;
        let ps_tx = VersionedTransaction {
            signatures: vec![Signature::default()],
            message: VersionedMessage::V0(ps_msg),
        };
        let ps_sim = rpc.simulate_transaction(&ps_tx).await?;
        if !ps_sim.success {
            bail!(
                "Canlı Mainnet PumpSwap SVM simülasyonu başarısız: {:?} | Loglar: {:?}",
                ps_sim.error,
                ps_sim.logs
            );
        }
        info!(
            "Canlı Mainnet PUMPSWAP AMM Simülasyonu BAŞARILI! (Hata = YOK, CU = {}, Derleme = {} µs, HavuzMCAP = ${:.0})",
            ps_sim.units_consumed,
            ps_build_us,
            oracle.lamports_to_usd(live_meta.market_cap_lamports())
        );
    }

    // 2) Pump.fun Bonding Curve ($10k-$29.5k) 18-Hesap Atomik Hız Kıyaslaması:
    let dummy_wallet = Keypair::new();
    let wallet_pk = dummy_wallet.pubkey();
    let wallet_user_vol = derive_user_volume_accumulator_pda(&wallet_pk);
    let dummy_mint = Keypair::new().pubkey();
    let creator_vault = derive_creator_vault_pda(&wallet_pk);
    let std_fee = fees.effective_fee_recipient(false);
    let buyback_rec = fees.effective_buyback_recipient(None);
    let token_2022 = token_2022_program_id();

    let pdas = MintDerivedPdas::derive(&dummy_mint, None, &token_2022, &wallet_pk);
    // ~$15,000 USD MCAP (~208 SOL MCAP) örnek Bonding Curve:
    let sample_curve = BondingCurveState {
        mint: dummy_mint,
        bonding_curve: pdas.bonding_curve,
        virtual_token_reserves: 393_000_000_000_000,
        virtual_sol_reserves: 81_850_000_000,
        real_token_reserves: 113_100_000_000_000,
        real_sol_reserves: 51_850_000_000,
        token_total_supply: 1_000_000_000_000_000,
        complete: false,
        creator: wallet_pk,
        is_mayhem_mode: false,
        is_cashback_coin: false,
        quote_mint: Pubkey::default(),
        creator_fee_bps: 0,
        is_holder_reward: false,
        depth: 0,
        protocol_fees: 0,
        initial_virtual_quote_reserves: 0,
        post_complete_base_out: 0,
        post_complete_quote_in: 0,
        creator_fee_bps_override: None,
    };
    let quote = quote_buy_exact_sol_in(
        &sample_curve,
        1_000_000,
        fees.fee_basis_points,
        fees.creator_fee_basis_points,
    )
    .expect("valid curve quote");

    let mut tip_ix =
        solana_system_interface::instruction::transfer(&wallet_pk, &fees.fee_recipient, 10_000);
    tip_ix
        .accounts
        .push(AccountMeta::new_readonly(jitodontfront_pubkey(), false));

    let t_warm = Instant::now();
    let ata_ix = create_ata_idempotent_with_ata_ix(
        &wallet_pk,
        &wallet_pk,
        &pdas.user_ata,
        &dummy_mint,
        &token_2022,
    );
    let buy_ix = build_buy_exact_sol_in_fast_ix(
        &wallet_pk,
        &wallet_user_vol,
        &dummy_mint,
        &pdas,
        &std_fee,
        &creator_vault,
        &token_2022,
        buyback_rec.as_ref(),
        1_000_000,
        quote.tokens_out * 9_750 / 10_000,
        false,
    );
    let v0_buy_tx = JitoClient::compile_v0_tx(
        &dummy_wallet,
        240_000,
        1_000,
        vec![ata_ix, buy_ix.clone(), tip_ix.clone()],
        bh,
    )?;
    let warm_buy_us = t_warm.elapsed().as_micros();

    let t_exit = Instant::now();
    let sell_ix = build_sell_fast_ix(
        &wallet_pk,
        &wallet_user_vol,
        &dummy_mint,
        &pdas,
        &std_fee,
        &creator_vault,
        &token_2022,
        buyback_rec.as_ref(),
        false,
        quote.tokens_out,
        1_025_000,
    );
    let close_ix =
        build_close_token_account_ix(&token_2022, &pdas.user_ata, &wallet_pk, &wallet_pk);
    let v0_exit_tx = JitoClient::compile_v0_tx(
        &dummy_wallet,
        240_000,
        1_000,
        vec![sell_ix.clone(), close_ix.clone(), tip_ix],
        bh,
    )?;
    let hot_exit_us = t_exit.elapsed().as_micros();

    let exact_buy_ix = build_buy_exact_tokens_out_fast_ix(
        &wallet_pk,
        &wallet_user_vol,
        &dummy_mint,
        &pdas,
        &std_fee,
        &creator_vault,
        &token_2022,
        buyback_rec.as_ref(),
        quote.tokens_out,
        1_000_000,
        false,
    );

    assert_eq!(buy_ix.accounts.len(), 18);
    assert_eq!(exact_buy_ix.accounts.len(), 18);
    assert_eq!(sell_ix.accounts.len(), 16);
    assert!(tx_has_jitodontfront(&v0_buy_tx));
    assert!(tx_has_jitodontfront(&v0_exit_tx));

    info!(
        "HIZ SONUCU -> PumpCurve Alım (MCAP=${:.0}): {} µs | Atomik Satış+CloseATA: {} µs!",
        oracle.lamports_to_usd(sample_curve.market_cap_lamports(false)),
        warm_buy_us,
        hot_exit_us
    );
    info!("=== v5.0 [$10k–$50k MCAP | >=5 SOL WHALE | PUMP + PUMPSWAP] SELF-TEST BAŞARIYLA TAMAMLANDI ===");
    Ok(())
}
